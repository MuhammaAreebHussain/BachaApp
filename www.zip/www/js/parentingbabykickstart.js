function fillParentingBabyKickTrackerP3(babykicktrackerp3testloop){
    
    var parentingbabykickstartp3 = "";
    for(var a = 1; a <= babykicktrackerp3testloop ; a++){
        parentingbabykickstartp3+='<div id="fillParentingBabyKickTrackerP3Content">';
        parentingbabykickstartp3+='<div style="border: 2px soldi; width: 100%; background-color: white;">';
        parentingbabykickstartp3+='<div style="text-align: center; margin-bottom: 3%;">';
        parentingbabykickstartp3+='<img src="img/parenting/pregnancytool/babykickstart/img1.jpg" width="100%">';
        parentingbabykickstartp3+='</div>';
        parentingbabykickstartp3+='<p style="font-size: 14px; margin-left: 5%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';          
        parentingbabykickstartp3+='<div style="border: 1px solid; width: 100%; margin-top: 5%;border-left: none; border-right: none; border-bottom: none;">';
        parentingbabykickstartp3+='<div class="container">';
        parentingbabykickstartp3+='<div class="row">';
        parentingbabykickstartp3+='<div class="col-6">';
        parentingbabykickstartp3+='<div class="row">';
        parentingbabykickstartp3+='<div class="col-4 icon" style="font-size: 20px;">';
        parentingbabykickstartp3+='<i class="fas fa-thumbs-up"></i>';
        parentingbabykickstartp3+='</div>';
        parentingbabykickstartp3+='<div class="col-8" style="font-size: 20px; margin-left: -15%;">';
        parentingbabykickstartp3+='<p>72 Likes</p>';
        parentingbabykickstartp3+='</div>';
        parentingbabykickstartp3+='</div>';
        parentingbabykickstartp3+='</div>';
        parentingbabykickstartp3+='<div class="col-6" style="font-size: 25px;">';
        parentingbabykickstartp3+='<div class="row">';

        parentingbabykickstartp3+='<a style="margin-left: 50%; color:  #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        parentingbabykickstartp3+='<a style="margin-left: 5%; color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        parentingbabykickstartp3+='</div>';
        parentingbabykickstartp3+='</div>';
        parentingbabykickstartp3+='</div>';
        parentingbabykickstartp3+='</div>';
        parentingbabykickstartp3+='</div>';
        parentingbabykickstartp3+='</div>';
        parentingbabykickstartp3+='</div>';
    }

    document.getElementById('fillParentingBabyKickTrackerP3Content').innerHTML = parentingbabykickstartp3;
}