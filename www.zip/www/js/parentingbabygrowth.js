// breastend
function fillParentingBabyGrowthMonth1(babygrowthmonth1testloop){
    
    var babygrowthmonth1 = "";
    for(var a = 1; a <= babygrowthmonth1testloop ; a++){
        babygrowthmonth1+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
        babygrowthmonth1+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth1+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth1+= '<div>';
        babygrowthmonth1+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth1+= '</div>';
        babygrowthmonth1+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth1+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth1+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth1+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth1+= '<div class="row">';
        babygrowthmonth1+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth1+= '<div class="row">';
        babygrowthmonth1+= '<div class="col-4 icon">';
        babygrowthmonth1+= '<i class="far fa-eye"></i>';
        babygrowthmonth1+= '</div>';
        babygrowthmonth1+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth1+= '<p>5.9KViews</p>';
        babygrowthmonth1+= '</div>';
        babygrowthmonth1+= '</div>';
        babygrowthmonth1+= '</div>';
        babygrowthmonth1+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth1+= '<div class="row">';
        babygrowthmonth1+= '<div class="col-4 icon">';
        babygrowthmonth1+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth1+= '</div>';
        babygrowthmonth1+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth1+= '<p>72 Likes</p>';
        babygrowthmonth1+= '</div>';
        babygrowthmonth1+= '</div>';
        babygrowthmonth1+= '</div>';
        babygrowthmonth1+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth1+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth1+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth1+= '<a style="color: black;">Share</a>';
        babygrowthmonth1+= '</div>';
        babygrowthmonth1+= '</div>';
        babygrowthmonth1+= '</div>';
        babygrowthmonth1+= '</div>';
        babygrowthmonth1+= '</div>';
        babygrowthmonth1+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth1Content').innerHTML = babygrowthmonth1;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth2(babygrowthmonth2testloop){
    
    var babygrowthmonth2 = "";
    for(var a = 1; a <= babygrowthmonth2testloop ; a++){
        babygrowthmonth2+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
        babygrowthmonth2+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth2+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth2+= '<div>';
        babygrowthmonth2+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth2+= '</div>';
        babygrowthmonth2+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth2+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth2+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth2+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth2+= '<div class="row">';
        babygrowthmonth2+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth2+= '<div class="row">';
        babygrowthmonth2+= '<div class="col-4 icon">';
        babygrowthmonth2+= '<i class="far fa-eye"></i>';
        babygrowthmonth2+= '</div>';
        babygrowthmonth2+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth2+= '<p>5.9KViews</p>';
        babygrowthmonth2+= '</div>';
        babygrowthmonth2+= '</div>';
        babygrowthmonth2+= '</div>';
        babygrowthmonth2+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth2+= '<div class="row">';
        babygrowthmonth2+= '<div class="col-4 icon">';
        babygrowthmonth2+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth2+= '</div>';
        babygrowthmonth2+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth2+= '<p>72 Likes</p>';
        babygrowthmonth2+= '</div>';
        babygrowthmonth2+= '</div>';
        babygrowthmonth2+= '</div>';
        babygrowthmonth2+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth2+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth2+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth2+= '<a style="color: black;">Share</a>';
        babygrowthmonth2+= '</div>';
        babygrowthmonth2+= '</div>';
        babygrowthmonth2+= '</div>';
        babygrowthmonth2+= '</div>';
        babygrowthmonth2+= '</div>';
        babygrowthmonth2+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth2Content').innerHTML = babygrowthmonth2;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth3(babygrowthmonth3testloop){
    
    var babygrowthmonth3 = "";
    for(var a = 1; a <= babygrowthmonth3testloop ; a++){
        babygrowthmonth3+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
        babygrowthmonth3+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth3+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth3+= '<div>';
        babygrowthmonth3+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth3+= '</div>';
        babygrowthmonth3+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth3+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth3+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth3+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth3+= '<div class="row">';
        babygrowthmonth3+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth3+= '<div class="row">';
        babygrowthmonth3+= '<div class="col-4 icon">';
        babygrowthmonth3+= '<i class="far fa-eye"></i>';
        babygrowthmonth3+= '</div>';
        babygrowthmonth3+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth3+= '<p>5.9KViews</p>';
        babygrowthmonth3+= '</div>';
        babygrowthmonth3+= '</div>';
        babygrowthmonth3+= '</div>';
        babygrowthmonth3+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth3+= '<div class="row">';
        babygrowthmonth3+= '<div class="col-4 icon">';
        babygrowthmonth3+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth3+= '</div>';
        babygrowthmonth3+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth3+= '<p>72 Likes</p>';
        babygrowthmonth3+= '</div>';
        babygrowthmonth3+= '</div>';
        babygrowthmonth3+= '</div>';
        babygrowthmonth3+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth3+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth3+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth3+= '<a style="color: black;">Share</a>';
        babygrowthmonth3+= '</div>';
        babygrowthmonth3+= '</div>';
        babygrowthmonth3+= '</div>';
        babygrowthmonth3+= '</div>';
        babygrowthmonth3+= '</div>';
        babygrowthmonth3+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth3Content').innerHTML = babygrowthmonth3;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth4(babygrowthmonth4testloop){
    
    var babygrowthmonth4 = "";
    for(var a = 1; a <= babygrowthmonth4testloop ; a++){
        babygrowthmonth4+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
        babygrowthmonth4+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth4+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth4+= '<div>';
        babygrowthmonth4+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth4+= '</div>';
        babygrowthmonth4+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth4+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth4+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth4+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth4+= '<div class="row">';
        babygrowthmonth4+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth4+= '<div class="row">';
        babygrowthmonth4+= '<div class="col-4 icon">';
        babygrowthmonth4+= '<i class="far fa-eye"></i>';
        babygrowthmonth4+= '</div>';
        babygrowthmonth4+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth4+= '<p>5.9KViews</p>';
        babygrowthmonth4+= '</div>';
        babygrowthmonth4+= '</div>';
        babygrowthmonth4+= '</div>';
        babygrowthmonth4+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth4+= '<div class="row">';
        babygrowthmonth4+= '<div class="col-4 icon">';
        babygrowthmonth4+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth4+= '</div>';
        babygrowthmonth4+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth4+= '<p>72 Likes</p>';
        babygrowthmonth4+= '</div>';
        babygrowthmonth4+= '</div>';
        babygrowthmonth4+= '</div>';
        babygrowthmonth4+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth4+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth4+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth4+= '<a style="color: black;">Share</a>';
        babygrowthmonth4+= '</div>';
        babygrowthmonth4+= '</div>';
        babygrowthmonth4+= '</div>';
        babygrowthmonth4+= '</div>';
        babygrowthmonth4+= '</div>';
        babygrowthmonth4+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth4Content').innerHTML = babygrowthmonth4;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth5(babygrowthmonth5testloop){
    
    var babygrowthmonth5 = "";
    for(var a = 1; a <= babygrowthmonth5testloop ; a++){
        babygrowthmonth5+= '<div id="fillParentingBabyGrowthMonth1Content" style="margin-bottom: 5%;">';
        babygrowthmonth5+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth5+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth5+= '<div>';
        babygrowthmonth5+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth5+= '</div>';
        babygrowthmonth5+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth5+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth5+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth5+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth5+= '<div class="row">';
        babygrowthmonth5+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth5+= '<div class="row">';
        babygrowthmonth5+= '<div class="col-4 icon">';
        babygrowthmonth5+= '<i class="far fa-eye"></i>';
        babygrowthmonth5+= '</div>';
        babygrowthmonth5+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth5+= '<p>5.9KViews</p>';
        babygrowthmonth5+= '</div>';
        babygrowthmonth5+= '</div>';
        babygrowthmonth5+= '</div>';
        babygrowthmonth5+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth5+= '<div class="row">';
        babygrowthmonth5+= '<div class="col-4 icon">';
        babygrowthmonth5+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth5+= '</div>';
        babygrowthmonth5+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth5+= '<p>72 Likes</p>';
        babygrowthmonth5+= '</div>';
        babygrowthmonth5+= '</div>';
        babygrowthmonth5+= '</div>';
        babygrowthmonth5+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth5+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth5+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth5+= '<a style="color: black;">Share</a>';
        babygrowthmonth5+= '</div>';
        babygrowthmonth5+= '</div>';
        babygrowthmonth5+= '</div>';
        babygrowthmonth5+= '</div>';
        babygrowthmonth5+= '</div>';
        babygrowthmonth5+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth5Content').innerHTML = babygrowthmonth5;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth6(babygrowthmonth6testloop){
    
    var babygrowthmonth6 = "";
    for(var a = 1; a <= babygrowthmonth6testloop ; a++){
        babygrowthmonth6+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
        babygrowthmonth6+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth6+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth6+= '<div>';
        babygrowthmonth6+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth6+= '</div>';
        babygrowthmonth6+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth6+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth6+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth6+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth6+= '<div class="row">';
        babygrowthmonth6+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth6+= '<div class="row">';
        babygrowthmonth6+= '<div class="col-4 icon">';
        babygrowthmonth6+= '<i class="far fa-eye"></i>';
        babygrowthmonth6+= '</div>';
        babygrowthmonth6+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth6+= '<p>5.9KViews</p>';
        babygrowthmonth6+= '</div>';
        babygrowthmonth6+= '</div>';
        babygrowthmonth6+= '</div>';
        babygrowthmonth6+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth6+= '<div class="row">';
        babygrowthmonth6+= '<div class="col-4 icon">';
        babygrowthmonth6+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth6+= '</div>';
        babygrowthmonth6+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth6+= '<p>72 Likes</p>';
        babygrowthmonth6+= '</div>';
        babygrowthmonth6+= '</div>';
        babygrowthmonth6+= '</div>';
        babygrowthmonth6+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth6+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth6+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth6+= '<a style="color: black;">Share</a>';
        babygrowthmonth6+= '</div>';
        babygrowthmonth6+= '</div>';
        babygrowthmonth6+= '</div>';
        babygrowthmonth6+= '</div>';
        babygrowthmonth6+= '</div>';
        babygrowthmonth6+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth6Content').innerHTML = babygrowthmonth6;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth7(babygrowthmonth7testloop){
    
    var babygrowthmonth7 = "";
    for(var a = 1; a <= babygrowthmonth7testloop ; a++){
        babygrowthmonth7+= '<div id="fillParentingBabyGrowthMonth1Content" style="margin-bottom: 5%;">';
        babygrowthmonth7+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth7+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth7+= '<div>';
        babygrowthmonth7+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth7+= '</div>';
        babygrowthmonth7+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth7+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth7+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth7+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth7+= '<div class="row">';
        babygrowthmonth7+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth7+= '<div class="row">';
        babygrowthmonth7+= '<div class="col-4 icon">';
        babygrowthmonth7+= '<i class="far fa-eye"></i>';
        babygrowthmonth7+= '</div>';
        babygrowthmonth7+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth7+= '<p>5.9KViews</p>';
        babygrowthmonth7+= '</div>';
        babygrowthmonth7+= '</div>';
        babygrowthmonth7+= '</div>';
        babygrowthmonth7+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth7+= '<div class="row">';
        babygrowthmonth7+= '<div class="col-4 icon">';
        babygrowthmonth7+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth7+= '</div>';
        babygrowthmonth7+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth7+= '<p>72 Likes</p>';
        babygrowthmonth7+= '</div>';
        babygrowthmonth7+= '</div>';
        babygrowthmonth7+= '</div>';
        babygrowthmonth7+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth7+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth7+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth7+= '<a style="color: black;">Share</a>';
        babygrowthmonth7+= '</div>';
        babygrowthmonth7+= '</div>';
        babygrowthmonth7+= '</div>';
        babygrowthmonth7+= '</div>';
        babygrowthmonth7+= '</div>';
        babygrowthmonth7+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth7Content').innerHTML = babygrowthmonth7;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth8(babygrowthmonth8testloop){
    
    var babygrowthmonth8 = "";
    for(var a = 1; a <= babygrowthmonth8testloop ; a++){
        babygrowthmonth8+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
        babygrowthmonth8+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth8+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth8+= '<div>';
        babygrowthmonth8+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth8+= '</div>';
        babygrowthmonth8+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth8+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth8+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth8+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth8+= '<div class="row">';
        babygrowthmonth8+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth8+= '<div class="row">';
        babygrowthmonth8+= '<div class="col-4 icon">';
        babygrowthmonth8+= '<i class="far fa-eye"></i>';
        babygrowthmonth8+= '</div>';
        babygrowthmonth8+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth8+= '<p>5.9KViews</p>';
        babygrowthmonth8+= '</div>';
        babygrowthmonth8+= '</div>';
        babygrowthmonth8+= '</div>';
        babygrowthmonth8+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth8+= '<div class="row">';
        babygrowthmonth8+= '<div class="col-4 icon">';
        babygrowthmonth8+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth8+= '</div>';
        babygrowthmonth8+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth8+= '<p>72 Likes</p>';
        babygrowthmonth8+= '</div>';
        babygrowthmonth8+= '</div>';
        babygrowthmonth8+= '</div>';
        babygrowthmonth8+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth8+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth8+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth8+= '<a style="color: black;">Share</a>';
        babygrowthmonth8+= '</div>';
        babygrowthmonth8+= '</div>';
        babygrowthmonth8+= '</div>';
        babygrowthmonth8+= '</div>';
        babygrowthmonth8+= '</div>';
        babygrowthmonth8+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth8Content').innerHTML = babygrowthmonth8;
}
// babygrowth

// breastend
 function fillParentingBabyGrowthMonth9(babygrowthmonth9testloop){
    
    var babygrowthmonth9 = "";
     for(var a = 1; a <= babygrowthmonth9testloop ; a++){
         babygrowthmonth9+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
         babygrowthmonth9+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
         babygrowthmonth9+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
         babygrowthmonth9+= '<div>';
         babygrowthmonth9+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
         babygrowthmonth9+= '</div>';
         babygrowthmonth9+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
         babygrowthmonth9+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
         babygrowthmonth9+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
         babygrowthmonth9+= '<div class="container" style="margin-top: 3%;">';
         babygrowthmonth9+= '<div class="row">';
         babygrowthmonth9+= '<div class="col-4" style="font-size: 16px;">';
         babygrowthmonth9+= '<div class="row">';
         babygrowthmonth9+= '<div class="col-4 icon">';
         babygrowthmonth9+= '<i class="far fa-eye"></i>';
         babygrowthmonth9+= '</div>';
         babygrowthmonth9+= '<div class="col-8" style="margin-left: -15%;">';
         babygrowthmonth9+= '<p>5.9KViews</p>';
         babygrowthmonth9+= '</div>';
         babygrowthmonth9+= '</div>';
        babygrowthmonth9+= '</div>';
         babygrowthmonth9+= '<div style="font-size: 16px;" class="col-4">';
         babygrowthmonth9+= '<div class="row">';
         babygrowthmonth9+= '<div class="col-4 icon">';
         babygrowthmonth9+= '<i class="fas fa-thumbs-up"></i>';
         babygrowthmonth9+= '</div>';
         babygrowthmonth9+= '<div class="col-8" style="margin-left: -15%;">';
         babygrowthmonth9+= '<p>72 Likes</p>';
         babygrowthmonth9+= '</div>';
         babygrowthmonth9+= '</div>';
         babygrowthmonth9+= '</div>';
         babygrowthmonth9+= '<div class="col-4" style="font-size: 16px;">';
         babygrowthmonth9+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
         babygrowthmonth9+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
         babygrowthmonth9+= '<a style="color: black;">Share</a>';
         babygrowthmonth9+= '</div>';
         babygrowthmonth9+= '</div>';
         babygrowthmonth9+= '</div>';
         babygrowthmonth9+= '</div>';
         babygrowthmonth9+= '</div>';
         babygrowthmonth9+= '</div>';               
     }

     document.getElementById('fillParentingBabyGrowthMonth9Content').innerHTML = babygrowthmonth9;
 }
// babygrowth

// breastend
function fillParentingBabyGrowthMonth10(babygrowthmonth10testloop){
    
    var babygrowthmonth10 = "";
    for(var a = 1; a <= babygrowthmonth10testloop ; a++){
        babygrowthmonth10+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
        babygrowthmonth10+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth10+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth10+= '<div>';
        babygrowthmonth10+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth10+= '</div>';
        babygrowthmonth10+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth10+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth10+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth10+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth10+= '<div class="row">';
        babygrowthmonth10+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth10+= '<div class="row">';
        babygrowthmonth10+= '<div class="col-4 icon">';
        babygrowthmonth10+= '<i class="far fa-eye"></i>';
        babygrowthmonth10+= '</div>';
        babygrowthmonth10+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth10+= '<p>5.9KViews</p>';
        babygrowthmonth10+= '</div>';
        babygrowthmonth10+= '</div>';
        babygrowthmonth10+= '</div>';
        babygrowthmonth10+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth10+= '<div class="row">';
        babygrowthmonth10+= '<div class="col-4 icon">';
        babygrowthmonth10+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth10+= '</div>';
        babygrowthmonth10+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth10+= '<p>72 Likes</p>';
        babygrowthmonth10+= '</div>';
        babygrowthmonth10+= '</div>';
        babygrowthmonth10+= '</div>';
        babygrowthmonth10+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth10+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth10+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth10+= '<a style="color: black;">Share</a>';
        babygrowthmonth10+= '</div>';
        babygrowthmonth10+= '</div>';
        babygrowthmonth10+= '</div>';
        babygrowthmonth10+= '</div>';
        babygrowthmonth10+= '</div>';
        babygrowthmonth10+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth10Content').innerHTML = babygrowthmonth10;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth11(babygrowthmonth11testloop){
    
    var babygrowthmonth11 = "";
    for(var a = 1; a <= babygrowthmonth11testloop ; a++){
        babygrowthmonth11+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
        babygrowthmonth11+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth11+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth11+= '<div>';
        babygrowthmonth11+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth11+= '</div>';
        babygrowthmonth11+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth11+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth11+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth11+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth11+= '<div class="row">';
        babygrowthmonth11+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth11+= '<div class="row">';
        babygrowthmonth11+= '<div class="col-4 icon">';
        babygrowthmonth11+= '<i class="far fa-eye"></i>';
        babygrowthmonth11+= '</div>';
        babygrowthmonth11+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth11+= '<p>5.9KViews</p>';
        babygrowthmonth11+= '</div>';
        babygrowthmonth11+= '</div>';
        babygrowthmonth11+= '</div>';
        babygrowthmonth11+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth11+= '<div class="row">';
        babygrowthmonth11+= '<div class="col-4 icon">';
        babygrowthmonth11+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth11+= '</div>';
        babygrowthmonth11+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth11+= '<p>72 Likes</p>';
        babygrowthmonth11+= '</div>';
        babygrowthmonth11+= '</div>';
        babygrowthmonth11+= '</div>';
        babygrowthmonth11+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth11+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth11+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth11+= '<a style="color: black;">Share</a>';
        babygrowthmonth11+= '</div>';
        babygrowthmonth11+= '</div>';
        babygrowthmonth11+= '</div>';
        babygrowthmonth11+= '</div>';
        babygrowthmonth11+= '</div>';
        babygrowthmonth11+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth11Content').innerHTML = babygrowthmonth11;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth12(babygrowthmonth12testloop){
    
    var babygrowthmonth12 = "";
    for(var a = 1; a <= babygrowthmonth12testloop ; a++){
        babygrowthmonth12+= '<div id="fillParentingBabyGrowthMonth1Content" style="margin-bottom: 5%;">';
        babygrowthmonth12+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth12+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth12+= '<div>';
        babygrowthmonth12+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth12+= '</div>';
        babygrowthmonth12+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth12+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth12+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth12+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth12+= '<div class="row">';
        babygrowthmonth12+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth12+= '<div class="row">';
        babygrowthmonth12+= '<div class="col-4 icon">';
        babygrowthmonth12+= '<i class="far fa-eye"></i>';
        babygrowthmonth12+= '</div>';
        babygrowthmonth12+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth12+= '<p>5.9KViews</p>';
        babygrowthmonth12+= '</div>';
        babygrowthmonth12+= '</div>';
        babygrowthmonth12+= '</div>';
        babygrowthmonth12+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth12+= '<div class="row">';
        babygrowthmonth12+= '<div class="col-4 icon">';
        babygrowthmonth12+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth12+= '</div>';
        babygrowthmonth12+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth12+= '<p>72 Likes</p>';
        babygrowthmonth12+= '</div>';
        babygrowthmonth12+= '</div>';
        babygrowthmonth12+= '</div>';
        babygrowthmonth12+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth12+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth12+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth12+= '<a style="color: black;">Share</a>';
        babygrowthmonth12+= '</div>';
        babygrowthmonth12+= '</div>';
        babygrowthmonth12+= '</div>';
        babygrowthmonth12+= '</div>';
        babygrowthmonth12+= '</div>';
        babygrowthmonth12+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth12Content').innerHTML = babygrowthmonth12;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth13(babygrowthmonth13testloop){
    
    var babygrowthmonth13 = "";
    for(var a = 1; a <= babygrowthmonth13testloop ; a++){
        babygrowthmonth13+= '<div id="fillParentingBabyGrowthMonth1Content" style="margin-bottom: 5%;">';
        babygrowthmonth13+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth13+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth13+= '<div>';
        babygrowthmonth13+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth13+= '</div>';
        babygrowthmonth13+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth13+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth13+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth13+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth13+= '<div class="row">';
        babygrowthmonth13+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth13+= '<div class="row">';
        babygrowthmonth13+= '<div class="col-4 icon">';
        babygrowthmonth13+= '<i class="far fa-eye"></i>';
        babygrowthmonth13+= '</div>';
        babygrowthmonth13+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth13+= '<p>5.9KViews</p>';
        babygrowthmonth13+= '</div>';
        babygrowthmonth13+= '</div>';
        babygrowthmonth13+= '</div>';
        babygrowthmonth13+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth13+= '<div class="row">';
        babygrowthmonth13+= '<div class="col-4 icon">';
        babygrowthmonth13+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth13+= '</div>';
        babygrowthmonth13+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth13+= '<p>72 Likes</p>';
        babygrowthmonth13+= '</div>';
        babygrowthmonth13+= '</div>';
        babygrowthmonth13+= '</div>';
        babygrowthmonth13+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth13+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth13+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth13+= '<a style="color: black;">Share</a>';
        babygrowthmonth13+= '</div>';
        babygrowthmonth13+= '</div>';
        babygrowthmonth13+= '</div>';
        babygrowthmonth13+= '</div>';
        babygrowthmonth13+= '</div>';
        babygrowthmonth13+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth13Content').innerHTML = babygrowthmonth13;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth14(babygrowthmonth14testloop){
    
    var babygrowthmonth14 = "";
    for(var a = 1; a <= babygrowthmonth14testloop ; a++){
        babygrowthmonth14+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
        babygrowthmonth14+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth14+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth14+= '<div>';
        babygrowthmonth14+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth14+= '</div>';
        babygrowthmonth14+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth14+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth14+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth14+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth14+= '<div class="row">';
        babygrowthmonth14+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth14+= '<div class="row">';
        babygrowthmonth14+= '<div class="col-4 icon">';
        babygrowthmonth14+= '<i class="far fa-eye"></i>';
        babygrowthmonth14+= '</div>';
        babygrowthmonth14+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth14+= '<p>5.9KViews</p>';
        babygrowthmonth14+= '</div>';
        babygrowthmonth14+= '</div>';
        babygrowthmonth14+= '</div>';
        babygrowthmonth14+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth14+= '<div class="row">';
        babygrowthmonth14+= '<div class="col-4 icon">';
        babygrowthmonth14+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth14+= '</div>';
        babygrowthmonth14+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth14+= '<p>72 Likes</p>';
        babygrowthmonth14+= '</div>';
        babygrowthmonth14+= '</div>';
        babygrowthmonth14+= '</div>';
        babygrowthmonth14+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth14+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth14+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth14+= '<a style="color: black;">Share</a>';
        babygrowthmonth14+= '</div>';
        babygrowthmonth14+= '</div>';
        babygrowthmonth14+= '</div>';
        babygrowthmonth14+= '</div>';
        babygrowthmonth14+= '</div>';
        babygrowthmonth14+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth14Content').innerHTML = babygrowthmonth14;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth15(babygrowthmonth15testloop){
    
    var babygrowthmonth15 = "";
    for(var a = 1; a <= babygrowthmonth15testloop ; a++){
        babygrowthmonth15+= '<div id="fillParentingBabyGrowthMonth1Content" style="margin-bottom: 5%;">';
        babygrowthmonth15+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth15+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth15+= '<div>';
        babygrowthmonth15+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth15+= '</div>';
        babygrowthmonth15+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth15+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth15+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth15+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth15+= '<div class="row">';
        babygrowthmonth15+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth15+= '<div class="row">';
        babygrowthmonth15+= '<div class="col-4 icon">';
        babygrowthmonth15+= '<i class="far fa-eye"></i>';
        babygrowthmonth15+= '</div>';
        babygrowthmonth15+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth15+= '<p>5.9KViews</p>';
        babygrowthmonth15+= '</div>';
        babygrowthmonth15+= '</div>';
        babygrowthmonth15+= '</div>';
        babygrowthmonth15+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth15+= '<div class="row">';
        babygrowthmonth15+= '<div class="col-4 icon">';
        babygrowthmonth15+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth15+= '</div>';
        babygrowthmonth15+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth15+= '<p>72 Likes</p>';
        babygrowthmonth15+= '</div>';
        babygrowthmonth15+= '</div>';
        babygrowthmonth15+= '</div>';
        babygrowthmonth15+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth15+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth15+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth15+= '<a style="color: black;">Share</a>';
        babygrowthmonth15+= '</div>';
        babygrowthmonth15+= '</div>';
        babygrowthmonth15+= '</div>';
        babygrowthmonth15+= '</div>';
        babygrowthmonth15+= '</div>';
        babygrowthmonth15+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth15Content').innerHTML = babygrowthmonth15;
}
// babygrowth
// breastend
function fillParentingBabyGrowthMonth16(babygrowthmonth16testloop){
    
    var babygrowthmonth16 = "";
    for(var a = 1; a <= babygrowthmonth16testloop ; a++){
        babygrowthmonth16+= '<div id="fillParentingBabyGrowthMonth1Content" style="margin-bottom: 5%;">';
        babygrowthmonth16+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth16+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth16+= '<div>';
        babygrowthmonth16+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth16+= '</div>';
        babygrowthmonth16+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth16+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth16+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth16+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth16+= '<div class="row">';
        babygrowthmonth16+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth16+= '<div class="row">';
        babygrowthmonth16+= '<div class="col-4 icon">';
        babygrowthmonth16+= '<i class="far fa-eye"></i>';
        babygrowthmonth16+= '</div>';
        babygrowthmonth16+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth16+= '<p>5.9KViews</p>';
        babygrowthmonth16+= '</div>';
        babygrowthmonth16+= '</div>';
        babygrowthmonth16+= '</div>';
        babygrowthmonth16+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth16+= '<div class="row">';
        babygrowthmonth16+= '<div class="col-4 icon">';
        babygrowthmonth16+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth16+= '</div>';
        babygrowthmonth16+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth16+= '<p>72 Likes</p>';
        babygrowthmonth16+= '</div>';
        babygrowthmonth16+= '</div>';
        babygrowthmonth16+= '</div>';
        babygrowthmonth16+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth16+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth16+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth16+= '<a style="color: black;">Share</a>';
        babygrowthmonth16+= '</div>';
        babygrowthmonth16+= '</div>';
        babygrowthmonth16+= '</div>';
        babygrowthmonth16+= '</div>';
        babygrowthmonth16+= '</div>';
        babygrowthmonth16+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth16Content').innerHTML = babygrowthmonth16;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth17(babygrowthmonth17testloop){
    
    var babygrowthmonth17 = "";
    for(var a = 1; a <= babygrowthmonth17testloop ; a++){
        babygrowthmonth17+= '<div id="fillParentingBabyGrowthMonth1Content" style="margin-bottom: 5%;">';
        babygrowthmonth17+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth17+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth17+= '<div>';
        babygrowthmonth17+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth17+= '</div>';
        babygrowthmonth17+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth17+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth17+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth17+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth17+= '<div class="row">';
        babygrowthmonth17+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth17+= '<div class="row">';
        babygrowthmonth17+= '<div class="col-4 icon">';
        babygrowthmonth17+= '<i class="far fa-eye"></i>';
        babygrowthmonth17+= '</div>';
        babygrowthmonth17+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth17+= '<p>5.9KViews</p>';
        babygrowthmonth17+= '</div>';
        babygrowthmonth17+= '</div>';
        babygrowthmonth17+= '</div>';
        babygrowthmonth17+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth17+= '<div class="row">';
        babygrowthmonth17+= '<div class="col-4 icon">';
        babygrowthmonth17+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth17+= '</div>';
        babygrowthmonth17+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth17+= '<p>72 Likes</p>';
        babygrowthmonth17+= '</div>';
        babygrowthmonth17+= '</div>';
        babygrowthmonth17+= '</div>';
        babygrowthmonth17+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth17+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth17+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth17+= '<a style="color: black;">Share</a>';
        babygrowthmonth17+= '</div>';
        babygrowthmonth17+= '</div>';
        babygrowthmonth17+= '</div>';
        babygrowthmonth17+= '</div>';
        babygrowthmonth17+= '</div>';
        babygrowthmonth17+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth17Content').innerHTML = babygrowthmonth17;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth18(babygrowthmonth18testloop){
    
    var babygrowthmonth18 = "";
    for(var a = 1; a <= babygrowthmonth18testloop ; a++){
        babygrowthmonth18+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
        babygrowthmonth18+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth18+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth18+= '<div>';
        babygrowthmonth18+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth18+= '</div>';
        babygrowthmonth18+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth18+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth18+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth18+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth18+= '<div class="row">';
        babygrowthmonth18+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth18+= '<div class="row">';
        babygrowthmonth18+= '<div class="col-4 icon">';
        babygrowthmonth18+= '<i class="far fa-eye"></i>';
        babygrowthmonth18+= '</div>';
        babygrowthmonth18+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth18+= '<p>5.9KViews</p>';
        babygrowthmonth18+= '</div>';
        babygrowthmonth18+= '</div>';
        babygrowthmonth18+= '</div>';
        babygrowthmonth18+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth18+= '<div class="row">';
        babygrowthmonth18+= '<div class="col-4 icon">';
        babygrowthmonth18+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth18+= '</div>';
        babygrowthmonth18+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth18+= '<p>72 Likes</p>';
        babygrowthmonth18+= '</div>';
        babygrowthmonth18+= '</div>';
        babygrowthmonth18+= '</div>';
        babygrowthmonth18+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth18+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth18+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth18+= '<a style="color: black;">Share</a>';
        babygrowthmonth18+= '</div>';
        babygrowthmonth18+= '</div>';
        babygrowthmonth18+= '</div>';
        babygrowthmonth18+= '</div>';
        babygrowthmonth18+= '</div>';
        babygrowthmonth18+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth18Content').innerHTML = babygrowthmonth18;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth19(babygrowthmonth19testloop){
    
    var babygrowthmonth19 = "";
    for(var a = 1; a <= babygrowthmonth19testloop ; a++){
        babygrowthmonth19+= '<div id="fillParentingBabyGrowthMonth1Content" style="margin-bottom: 5%;">';
        babygrowthmonth19+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth19+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth19+= '<div>';
        babygrowthmonth19+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth19+= '</div>';
        babygrowthmonth19+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth19+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth19+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth19+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth19+= '<div class="row">';
        babygrowthmonth19+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth19+= '<div class="row">';
        babygrowthmonth19+= '<div class="col-4 icon">';
        babygrowthmonth19+= '<i class="far fa-eye"></i>';
        babygrowthmonth19+= '</div>';
        babygrowthmonth19+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth19+= '<p>5.9KViews</p>';
        babygrowthmonth19+= '</div>';
        babygrowthmonth19+= '</div>';
        babygrowthmonth19+= '</div>';
        babygrowthmonth19+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth19+= '<div class="row">';
        babygrowthmonth19+= '<div class="col-4 icon">';
        babygrowthmonth19+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth19+= '</div>';
        babygrowthmonth19+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth19+= '<p>72 Likes</p>';
        babygrowthmonth19+= '</div>';
        babygrowthmonth19+= '</div>';
        babygrowthmonth19+= '</div>';
        babygrowthmonth19+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth19+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth19+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth19+= '<a style="color: black;">Share</a>';
        babygrowthmonth19+= '</div>';
        babygrowthmonth19+= '</div>';
        babygrowthmonth19+= '</div>';
        babygrowthmonth19+= '</div>';
        babygrowthmonth19+= '</div>';
        babygrowthmonth19+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth19Content').innerHTML = babygrowthmonth19;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth20(babygrowthmonth20testloop){
    
    var babygrowthmonth20 = "";
    for(var a = 1; a <= babygrowthmonth20testloop ; a++){
        babygrowthmonth20+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
        babygrowthmonth20+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth20+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth20+= '<div>';
        babygrowthmonth20+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth20+= '</div>';
        babygrowthmonth20+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth20+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth20+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth20+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth20+= '<div class="row">';
        babygrowthmonth20+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth20+= '<div class="row">';
        babygrowthmonth20+= '<div class="col-4 icon">';
        babygrowthmonth20+= '<i class="far fa-eye"></i>';
        babygrowthmonth20+= '</div>';
        babygrowthmonth20+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth20+= '<p>5.9KViews</p>';
        babygrowthmonth20+= '</div>';
        babygrowthmonth20+= '</div>';
        babygrowthmonth20+= '</div>';
        babygrowthmonth20+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth20+= '<div class="row">';
        babygrowthmonth20+= '<div class="col-4 icon">';
        babygrowthmonth20+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth20+= '</div>';
        babygrowthmonth20+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth20+= '<p>72 Likes</p>';
        babygrowthmonth20+= '</div>';
        babygrowthmonth20+= '</div>';
        babygrowthmonth20+= '</div>';
        babygrowthmonth20+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth20+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth20+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth20+= '<a style="color: black;">Share</a>';
        babygrowthmonth20+= '</div>';
        babygrowthmonth20+= '</div>';
        babygrowthmonth20+= '</div>';
        babygrowthmonth20+= '</div>';
        babygrowthmonth20+= '</div>';
        babygrowthmonth20+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth20Content').innerHTML = babygrowthmonth20;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth21(babygrowthmonth21testloop){
    
    var babygrowthmonth21 = "";
    for(var a = 1; a <= babygrowthmonth21testloop ; a++){
        babygrowthmonth21+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
        babygrowthmonth21+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth21+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth21+= '<div>';
        babygrowthmonth21+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth21+= '</div>';
        babygrowthmonth21+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth21+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth21+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth21+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth21+= '<div class="row">';
        babygrowthmonth21+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth21+= '<div class="row">';
        babygrowthmonth21+= '<div class="col-4 icon">';
        babygrowthmonth21+= '<i class="far fa-eye"></i>';
        babygrowthmonth21+= '</div>';
        babygrowthmonth21+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth21+= '<p>5.9KViews</p>';
        babygrowthmonth21+= '</div>';
        babygrowthmonth21+= '</div>';
        babygrowthmonth21+= '</div>';
        babygrowthmonth21+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth21+= '<div class="row">';
        babygrowthmonth21+= '<div class="col-4 icon">';
        babygrowthmonth21+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth21+= '</div>';
        babygrowthmonth21+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth21+= '<p>72 Likes</p>';
        babygrowthmonth21+= '</div>';
        babygrowthmonth21+= '</div>';
        babygrowthmonth21+= '</div>';
        babygrowthmonth21+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth21+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth21+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth21+= '<a style="color: black;">Share</a>';
        babygrowthmonth21+= '</div>';
        babygrowthmonth21+= '</div>';
        babygrowthmonth21+= '</div>';
        babygrowthmonth21+= '</div>';
        babygrowthmonth21+= '</div>';
        babygrowthmonth21+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth21Content').innerHTML = babygrowthmonth21;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth22(babygrowthmonth22testloop){
    
    var babygrowthmonth22 = "";
    for(var a = 1; a <= babygrowthmonth22testloop ; a++){
        babygrowthmonth22+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
        babygrowthmonth22+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth22+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth22+= '<div>';
        babygrowthmonth22+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth22+= '</div>';
        babygrowthmonth22+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth22+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth22+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth22+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth22+= '<div class="row">';
        babygrowthmonth22+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth22+= '<div class="row">';
        babygrowthmonth22+= '<div class="col-4 icon">';
        babygrowthmonth22+= '<i class="far fa-eye"></i>';
        babygrowthmonth22+= '</div>';
        babygrowthmonth22+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth22+= '<p>5.9KViews</p>';
        babygrowthmonth22+= '</div>';
        babygrowthmonth22+= '</div>';
        babygrowthmonth22+= '</div>';
        babygrowthmonth22+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth22+= '<div class="row">';
        babygrowthmonth22+= '<div class="col-4 icon">';
        babygrowthmonth22+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth22+= '</div>';
        babygrowthmonth22+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth22+= '<p>72 Likes</p>';
        babygrowthmonth22+= '</div>';
        babygrowthmonth22+= '</div>';
        babygrowthmonth22+= '</div>';
        babygrowthmonth22+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth22+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth22+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth22+= '<a style="color: black;">Share</a>';
        babygrowthmonth22+= '</div>';
        babygrowthmonth22+= '</div>';
        babygrowthmonth22+= '</div>';
        babygrowthmonth22+= '</div>';
        babygrowthmonth22+= '</div>';
        babygrowthmonth22+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth22Content').innerHTML = babygrowthmonth22;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth23(babygrowthmonth23testloop){
    
    var babygrowthmonth23 = "";
    for(var a = 1; a <= babygrowthmonth23testloop ; a++){
        babygrowthmonth23+= '<div id="fillParentingBabyGrowthMonth1Content" style="margin-bottom: 5%;">';
        babygrowthmonth23+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth23+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth23+= '<div>';
        babygrowthmonth23+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth23+= '</div>';
        babygrowthmonth23+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth23+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth23+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth23+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth23+= '<div class="row">';
        babygrowthmonth23+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth23+= '<div class="row">';
        babygrowthmonth23+= '<div class="col-4 icon">';
        babygrowthmonth23+= '<i class="far fa-eye"></i>';
        babygrowthmonth23+= '</div>';
        babygrowthmonth23+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth23+= '<p>5.9KViews</p>';
        babygrowthmonth23+= '</div>';
        babygrowthmonth23+= '</div>';
        babygrowthmonth23+= '</div>';
        babygrowthmonth23+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth23+= '<div class="row">';
        babygrowthmonth23+= '<div class="col-4 icon">';
        babygrowthmonth23+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth23+= '</div>';
        babygrowthmonth23+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth23+= '<p>72 Likes</p>';
        babygrowthmonth23+= '</div>';
        babygrowthmonth23+= '</div>';
        babygrowthmonth23+= '</div>';
        babygrowthmonth23+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth23+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth23+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth23+= '<a style="color: black;">Share</a>';
        babygrowthmonth23+= '</div>';
        babygrowthmonth23+= '</div>';
        babygrowthmonth23+= '</div>';
        babygrowthmonth23+= '</div>';
        babygrowthmonth23+= '</div>';
        babygrowthmonth23+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth23Content').innerHTML = babygrowthmonth23;
}
// babygrowth

// breastend
function fillParentingBabyGrowthMonth24(babygrowthmonth24testloop){
    
    var babygrowthmonth24 = "";
    for(var a = 1; a <= babygrowthmonth24testloop ; a++){
        babygrowthmonth24+= '<div id="fillParentingBabyGrowthMonth1Content" style=" margin-bottom: 5%;">';
        babygrowthmonth24+= '<div style="border: 2px soldi; width: 98%; background-color: white;">';
        babygrowthmonth24+= '<p style="font-size: 22px;">Your 1 week Old Baby-Development</p>';
        babygrowthmonth24+= '<div>';
        babygrowthmonth24+= '<img src="img/parenting/getting preganant/dietplan/img3.jpg" width="100%">';
        babygrowthmonth24+= '</div>';
        babygrowthmonth24+= '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, </p>';
        babygrowthmonth24+= '<a style="text-decoration: underline; color: #007bff">Read More</a>';
        babygrowthmonth24+= '<div style="border: 1px solid gray; width: 100%; margin-top: 5%; border-left: none; border-right: none; border-bottom: none;">';
        babygrowthmonth24+= '<div class="container" style="margin-top: 3%;">';
        babygrowthmonth24+= '<div class="row">';
        babygrowthmonth24+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth24+= '<div class="row">';
        babygrowthmonth24+= '<div class="col-4 icon">';
        babygrowthmonth24+= '<i class="far fa-eye"></i>';
        babygrowthmonth24+= '</div>';
        babygrowthmonth24+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth24+= '<p>5.9KViews</p>';
        babygrowthmonth24+= '</div>';
        babygrowthmonth24+= '</div>';
        babygrowthmonth24+= '</div>';
        babygrowthmonth24+= '<div style="font-size: 16px;" class="col-4">';
        babygrowthmonth24+= '<div class="row">';
        babygrowthmonth24+= '<div class="col-4 icon">';
        babygrowthmonth24+= '<i class="fas fa-thumbs-up"></i>';
        babygrowthmonth24+= '</div>';
        babygrowthmonth24+= '<div class="col-8" style="margin-left: -15%;">';
        babygrowthmonth24+= '<p>72 Likes</p>';
        babygrowthmonth24+= '</div>';
        babygrowthmonth24+= '</div>';
        babygrowthmonth24+= '</div>';
        babygrowthmonth24+= '<div class="col-4" style="font-size: 16px;">';
        babygrowthmonth24+= '<a style="color: #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        babygrowthmonth24+= '<a style="color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        babygrowthmonth24+= '<a style="color: black;">Share</a>';
        babygrowthmonth24+= '</div>';
        babygrowthmonth24+= '</div>';
        babygrowthmonth24+= '</div>';
        babygrowthmonth24+= '</div>';
        babygrowthmonth24+= '</div>';
        babygrowthmonth24+= '</div>';               
    }

    document.getElementById('fillParentingBabyGrowthMonth24Content').innerHTML = babygrowthmonth24;
}
// babygrowth
