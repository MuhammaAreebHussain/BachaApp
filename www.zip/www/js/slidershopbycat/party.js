// dropdowns

// boyfashiob
//var testLoop = 10;
function fillSliderShopByCatPartyDropDown1(partydropdown1testLoop){
    
    var shopbycatpartydropdown1contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < partydropdown1testLoop ; a++){
            shopbycatpartydropdown1contentd += '<p href="#" style="color: black; margin-left: 2%;">Face Mask</p>';
    }

    document.getElementById('fillSliderShopByCatPartyDropDown1Content').innerHTML = shopbycatpartydropdown1contentd;

}

//var testLoop = 10;
function fillSliderShopByCatPartyDropDown2(partydropdown2testLoop){
    
    var shopbycatpartydropdown2contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < partydropdown2testLoop ; a++){
            shopbycatpartydropdown2contentd += '<p href="#" style="color: black; margin-left: 2%;">Face Mask</p>';
    }

    document.getElementById('fillSliderShopByCatPartyDropDown2Content').innerHTML = shopbycatpartydropdown2contentd;

}

//var testLoop = 10;
function fillSliderShopByCatPartyDropDown3(partydropdown3testLoop){
    
    var shopbycatpartydropdown3contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < partydropdown3testLoop ; a++){
            shopbycatpartydropdown3contentd += '<p href="#" style="color: black; margin-left: 2%;">Face Mask</p>';
    }

    document.getElementById('fillSliderShopByCatPartyDropDown3Content').innerHTML = shopbycatpartydropdown3contentd;

}



//var testLoop = 10;
function fillSliderShopByCatPartyBtns(partybtnstestLoop){
    
    var shopbycatpartybtnscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < partybtnstestLoop ; a++){
            shopbycatpartybtnscontentd += '<div id="fillSliderShopByCatOutdoorBtnsContent" style="background-color: white; border: 1px solid gray; border-right: none; border-left: none; border-top: none;">';
            shopbycatpartybtnscontentd += '<div style="padding-top: 3%; padding-left: 4%; height: 45px">';
            shopbycatpartybtnscontentd += '<p style="font-size: 18px; ">Party Supplies</p>';
            shopbycatpartybtnscontentd += '</div>';
            shopbycatpartybtnscontentd += '</div>';
    }

    document.getElementById('fillSliderShopByCatPartyBtnsContent').innerHTML = shopbycatpartybtnscontentd;

}
//  dropdownend

// slider
function fillPartySliderLoop(partyslidertestloop){
    
    var partyslider = "";
    for(var a = 1; a <= partyslidertestloop ; a++){
        partyslider += '<div class="carousel-item">';
        partyslider += '<img src="img/shopingportion/gifts/sliderimg'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        partyslider += '</div>';                 
    }

    document.getElementById('fillPartySliderLoopContent').innerHTML = partyslider;
}
// sliderend


