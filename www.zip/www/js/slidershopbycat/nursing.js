// dropdowns

// boyfashiob
//var testLoop = 10;
function fillSliderShopByCatNursingDropDown1(nursingdropdown1testLoop){
    
    var shopbycatnursingdropdown1contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < nursingdropdown1testLoop ; a++){
            shopbycatnursingdropdown1contentd += '<p href="#" style="color: black; margin-left: 2%;">Baby Bed Sets</p>';
    }

    document.getElementById('fillSliderShopByCatNursingDropDown1Content').innerHTML = shopbycatnursingdropdown1contentd;

}

//var testLoop = 10;
function fillSliderShopByCatNursingDropDown2(nursingdropdown2testLoop){
    
    var shopbycatnursingdropdown2contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < nursingdropdown2testLoop ; a++){
            shopbycatnursingdropdown2contentd += '<p href="#" style="color: black; margin-left: 2%;">Baby Bed Sets</p>';
    }

    document.getElementById('fillSliderShopByCatNursingDropDown2Content').innerHTML = shopbycatnursingdropdown2contentd;

}

//var testLoop = 10;
function fillSliderShopByCatNursingDropDown3(nursingdropdown3testLoop){
    
    var shopbycatnursingdropdown3contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < nursingdropdown3testLoop ; a++){
            shopbycatnursingdropdown3contentd += '<p href="#" style="color: black; margin-left: 2%;">Baby Bed Sets</p>';
    }

    document.getElementById('fillSliderShopByCatNursingDropDown3Content').innerHTML = shopbycatnursingdropdown3contentd;

}

//var testLoop = 10;
function fillSliderShopByCatNursingDropDown4(nursingdropdown4testLoop){
    
    var shopbycatnursingdropdown4contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < nursingdropdown4testLoop ; a++){
            shopbycatnursingdropdown4contentd += '<p href="#" style="color: black; margin-left: 2%;">Baby Bed Sets</p>';
    }

    document.getElementById('fillSliderShopByCatNursingDropDown4Content').innerHTML = shopbycatnursingdropdown4contentd;

}

//var testLoop = 10;
function fillSliderShopByCatNursingDropDown5(nursingdropdown5testLoop){
    
    var shopbycatnursingdropdown5contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < nursingdropdown5testLoop ; a++){
            shopbycatnursingdropdown5contentd += '<p href="#" style="color: black; margin-left: 2%;">Baby Bed Sets</p>';
    }

    document.getElementById('fillSliderShopByCatNursingDropDown5Content').innerHTML = shopbycatnursingdropdown5contentd;

}

//var testLoop = 10;
function fillSliderShopByCatNursingDropDown6(nursingdropdown6testLoop){
    
    var shopbycatnursingdropdown6contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < nursingdropdown6testLoop ; a++){
            shopbycatnursingdropdown6contentd += '<p href="#" style="color: black; margin-left: 2%;">Baby Bed Sets</p>';
    }

    document.getElementById('fillSliderShopByCatNursingDropDown6Content').innerHTML = shopbycatnursingdropdown6contentd;

}

//var testLoop = 10;
function fillSliderShopByCatNursingDropDown7(nursingdropdown7testLoop){
    
    var shopbycatnursingdropdown7contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < nursingdropdown7testLoop ; a++){
            shopbycatnursingdropdown7contentd += '<p href="#" style="color: black; margin-left: 2%;">Baby Bed Sets</p>';
    }

    document.getElementById('fillSliderShopByCatNursingDropDown7Content').innerHTML = shopbycatnursingdropdown7contentd;

}

//var testLoop = 10;
function fillSliderShopByCatNursingBtns(nursingbtnstestLoop){
    
    var shopbycatnursingbtnscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < nursingbtnstestLoop ; a++){
            shopbycatnursingbtnscontentd += '<div id="fillSliderShopByCatOutdoorBtnsContent" style="background-color: white; border: 1px solid gray; border-right: none; border-left: none; border-top: none;">';
            shopbycatnursingbtnscontentd += '<div style="padding-top: 3%; padding-left: 4%; height: 45px">';
            shopbycatnursingbtnscontentd += '<p style="font-size: 18px; ">Bath Toys</p>';
            shopbycatnursingbtnscontentd += '</div>';
            shopbycatnursingbtnscontentd += '</div>';
    }

    document.getElementById('fillSliderShopByCatNursingBtnsContent').innerHTML = shopbycatnursingbtnscontentd;

}
//  dropdownend

//var NursingImagesLoop = 10;
function fillSliderNursingNursingImage1(nursingimages1testLoop){
    var shopbycatnursingimages1contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < nursingimages1testLoop ; a++){
            shopbycatnursingimages1contentd += '<img src="img/shopingportion/nursery/banner5.jpg" style="width: 100%; margin-top:5%;">';
        
    }

    document.getElementById('fillSliderNursingNursingImage1Content').innerHTML = shopbycatnursingimages1contentd;

}

//var NursingImagesLoop = 10;
function fillSliderNursingNursingImage2(nursingimages2testLoop){
    var shopbycatnursingimages2contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < nursingimages2testLoop ; a++){
            shopbycatnursingimages2contentd += '<img src="img/shopingportion/nursery/banner12.jpg" style="width: 100%; margin-top:5%;">';
        
    }

    document.getElementById('fillSliderNursingNursingImage2Content').innerHTML = shopbycatnursingimages2contentd;

}



// slider
function fillNurserySliderLoop(nurseryslidertestloop){
    
    var nurseryslider = "";
    for(var a = 1; a <= nurseryslidertestloop ; a++){
        nurseryslider += '<div class="carousel-item">';
        nurseryslider += '<img src="img/shopingportion/nursery/sliderimg'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        nurseryslider += '</div>';                 
    }

    document.getElementById('fillNurserySliderLoopContent').innerHTML = nurseryslider;
}
// sliderend