// dropdowns

//var testLoop = 10;
function fillSliderShopByCatBabyBoyFashionDropDown(testLoop){
    
    var shopbycatbabyboyfashiondropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < testLoop ; a++){
            shopbycatbabyboyfashiondropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Summer Collection upto 40% off'+ a +'</p>';
    }

    document.getElementById('fillSliderShopByCatBabyBoyFashionDropDownContent').innerHTML = shopbycatbabyboyfashiondropdowncontentd;

}

// babyboycloths

//var babyboyclothsLoop = 10;
function fillSliderShopByCatBabyBoyClothsDropDownTill6Months(babyboyclothstill6monthsLoop){
    
    var shopbycatbabyboyclothsdropdowntill6monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babyboyclothstill6monthsLoop ; a++){
            shopbycatbabyboyclothsdropdowntill6monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBabyBoyClothsDropDownTill6MonthsContent').innerHTML = shopbycatbabyboyclothsdropdowntill6monthscontentd;
}
function fillSliderShopByCatBabyBoyClothsDropDownTill9Months(babyboyclothstill9monthsLoop){
    
    var shopbycatbabyboyclothsdropdowntill9monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babyboyclothstill9monthsLoop ; a++){
            shopbycatbabyboyclothsdropdowntill9monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBabyBoyClothsDropDownTill9MonthsContent').innerHTML = shopbycatbabyboyclothsdropdowntill9monthscontentd;
}
function fillSliderShopByCatBabyBoyClothsDropDownTill12Months(babyboyclothstill12monthsLoop){
    
    var shopbycatbabyboyclothsdropdowntill12monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babyboyclothstill12monthsLoop ; a++){
            shopbycatbabyboyclothsdropdowntill12monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBabyBoyClothsDropDownTill12MonthsContent').innerHTML = shopbycatbabyboyclothsdropdowntill12monthscontentd;
}
function fillSliderShopByCatBabyBoyClothsDropDownTill15Months(babyboyclothstill15monthsLoop){
    
    var shopbycatbabyboyclothsdropdowntill15monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babyboyclothstill15monthsLoop ; a++){
            shopbycatbabyboyclothsdropdowntill15monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBabyBoyClothsDropDownTill15MonthsContent').innerHTML = shopbycatbabyboyclothsdropdowntill15monthscontentd;
}
function fillSliderShopByCatBabyBoyClothsDropDownTill18Months(babyboyclothstill18monthsLoop){
    
    var shopbycatbabyboyclothsdropdowntill18monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babyboyclothstill18monthsLoop ; a++){
            shopbycatbabyboyclothsdropdowntill18monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBabyBoyClothsDropDownTill18MonthsContent').innerHTML = shopbycatbabyboyclothsdropdowntill18monthscontentd;
}

// babyboyclothsend

// footwear

//var footwearLoop = 10;
function fillSliderShopByCatFootwearDropDownShopByCat(footwearLoopCat){
    
    var shopbycatfootweardropdowncatcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footwearLoopCat ; a++){
            shopbycatfootweardropdowncatcontentd += '<p href="#" style="color: black; margin-left: 2%;">Casual Shoes</p>';
    }
    document.getElementById('fillSliderShopByCatFootwearDropDownContentCat').innerHTML = shopbycatfootweardropdowncatcontentd;
}
//var footwearLoop = 10;
function fillSliderShopByCatFootwearDropDownShopByAge(footwearLoopAge){
    
    var shopbycatfootweardropdownagecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footwearLoopAge ; a++){
            shopbycatfootweardropdownagecontentd += '<p href="#" style="color: black; margin-left: 2%;">0-3 Months</p>';
    }
    document.getElementById('fillSliderShopByCatFootwearDropDownContentAge').innerHTML = shopbycatfootweardropdownagecontentd;
}
//var footwearLoop = 10;
function fillSliderShopByCatFootwearDropDownShopBySpecialOffer(footwearLoopOffer){
    
    var shopbycatfootweardropdownoffercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footwearLoopOffer ; a++){
            shopbycatfootweardropdownoffercontentd += '<p href="#" style="color: black; margin-left: 2%;">Upto 30% off</p>';
    }
    document.getElementById('fillSliderShopByCatFootwearDropDownContentOffer').innerHTML = shopbycatfootweardropdownoffercontentd;
}
// footwearend

// popularbrands
//var popularbrandsLoop = 10;
function fillSliderShopByCatPopularBrandsDropDown(popularbrandsLoop){
    
    var shopbycatpopularbrandsdropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < popularbrandsLoop ; a++){
            shopbycatpopularbrandsdropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Carters</p>';
    }

    document.getElementById('fillSliderShopByCatPopularBrandsDropDownContent').innerHTML = shopbycatpopularbrandsdropdowncontentd;

}
// popularbrandsend

// boyfashiob
//var testLoop = 10;
function fillSliderShopByCatBoyFashionDropDown(testLoop){
    
    var shopbycatboyfashiondropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < testLoop ; a++){
            shopbycatboyfashiondropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Summer Collection upto 40% off'+ a +'</p>';
    }

    document.getElementById('fillSliderShopByCatBoyFashionDropDownContent').innerHTML = shopbycatboyfashiondropdowncontentd;

}

// babyboycloths

//var babyboyclothsLoop = 10;
function fillSliderShopByCatBoyClothsDropDownTill6Months(boyclothstill6monthsLoop){
    
    var shopbycatboyclothsdropdowntill6monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < boyclothstill6monthsLoop ; a++){
            shopbycatboyclothsdropdowntill6monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBoyClothsDropDownTill6MonthsContent').innerHTML = shopbycatboyclothsdropdowntill6monthscontentd;
}
function fillSliderShopByCatBoyClothsDropDownTill9Months(boyclothstill9monthsLoop){
    
    var shopbycatboyclothsdropdowntill9monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < boyclothstill9monthsLoop ; a++){
            shopbycatboyclothsdropdowntill9monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBoyClothsDropDownTill9MonthsContent').innerHTML = shopbycatboyclothsdropdowntill9monthscontentd;
}
function fillSliderShopByCatBoyClothsDropDownTill12Months(boyclothstill12monthsLoop){
    
    var shopbycatboyclothsdropdowntill12monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < boyclothstill12monthsLoop ; a++){
            shopbycatboyclothsdropdowntill12monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBoyClothsDropDownTill12MonthsContent').innerHTML = shopbycatboyclothsdropdowntill12monthscontentd;
}
function fillSliderShopByCatBoyClothsDropDownTill15Months(boyclothstill15monthsLoop){
    
    var shopbycatboyclothsdropdowntill15monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < boyclothstill15monthsLoop ; a++){
            shopbycatboyclothsdropdowntill15monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBoyClothsDropDownTill15MonthsContent').innerHTML = shopbycatboyclothsdropdowntill15monthscontentd;
}
function fillSliderShopByCatBoyClothsDropDownTill18Months(boyclothstill18monthsLoop){
    
    var shopbycatboyclothsdropdowntill18monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < boyclothstill18monthsLoop ; a++){
            shopbycatboyclothsdropdowntill18monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBoyClothsDropDownTill18MonthsContent').innerHTML = shopbycatboyclothsdropdowntill18monthscontentd;
}

// babyboyclothsend

// footwear

//var footwearLoop = 10;
function fillSliderShopByCatFootwearDropDownShopByCat(footwearLoopCat){
    
    var shopbycatfootweardropdowncatcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footwearLoopCat ; a++){
            shopbycatfootweardropdowncatcontentd += '<p href="#" style="color: black; margin-left: 2%;">Casual Shoes</p>';
    }
    document.getElementById('fillSliderShopByCatFootwearDropDownContentCat').innerHTML = shopbycatfootweardropdowncatcontentd;
}
//var footwearLoop = 10;
function fillSliderShopByCatFootwearDropDownShopByAge(footwearLoopAge){
    
    var shopbycatfootweardropdownagecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footwearLoopAge ; a++){
            shopbycatfootweardropdownagecontentd += '<p href="#" style="color: black; margin-left: 2%;">0-3 Months</p>';
    }
    document.getElementById('fillSliderShopByCatFootwearDropDownContentAge').innerHTML = shopbycatfootweardropdownagecontentd;
}
//var footwearLoop = 10;
function fillSliderShopByCatFootwearDropDownShopBySpecialOffer(footwearLoopOffer){
    
    var shopbycatfootweardropdownoffercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footwearLoopOffer ; a++){
            shopbycatfootweardropdownoffercontentd += '<p href="#" style="color: black; margin-left: 2%;">Upto 30% off</p>';
    }
    document.getElementById('fillSliderShopByCatFootwearDropDownContentOffer').innerHTML = shopbycatfootweardropdownoffercontentd;
}
// footwearend

// fashionassec
//var fashionassecoriesLoop = 10;
function fillSliderShopByCatFashionAssecoriesDropDown(fashionassecoriesLoop){
    
    var shopbycatfashionassecoriesdropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < fashionassecoriesLoop ; a++){
            shopbycatfashionassecoriesdropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Sun Glasses</p>';
    }

    document.getElementById('fillSliderShopByCatFashionAssecoriesDropDownContent').innerHTML = shopbycatfashionassecoriesdropdowncontentd;

}
// fashionsend

// popularbrands
//var popularbrandsLoop = 10;
function fillSliderShopByCatPopularBrandsDropDown(popularbrandsLoop){
    
    var shopbycatpopularbrandsdropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < popularbrandsLoop ; a++){
            shopbycatpopularbrandsdropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Carters</p>';
    }

    document.getElementById('fillSliderShopByCatPopularBrandsDropDownContent').innerHTML = shopbycatpopularbrandsdropdowncontentd;

}
// popularbrandsend
// botfashionend
// dropdownsend

// images

//var boutiqueLoop = 10;
function fillSliderShopByCatBoyFashionBoutique(boyfashionboutiqueLoop){
    
    var shopbycatboyfashionboutiquecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < boyfashionboutiqueLoop ; a++){
            shopbycatboyfashionboutiquecontentd += '<img src="img/shopingportion/babyboyfashion/boutiques/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatBoyFashionBoutiqueContent').innerHTML = shopbycatboyfashionboutiquecontentd;

}

//var carterLoop = 10;
function fillSliderShopByBoyFashionCatCarter(boyfashioncarterLoop){
    
    var shopbycatboyfashioncartercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < boyfashioncarterLoop ; a++){
            shopbycatboyfashioncartercontentd += '<img src="img/home/carters/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatBoyFashionCarterContent').innerHTML = shopbycatboyfashioncartercontentd;

}

//var summerLoop = 10;
function fillSliderShopByBoyFashionCatSummer(boyfashionsummerLoop){
    
    var shopbyboyfashioncatsummercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < boyfashionsummerLoop ; a++){
            shopbyboyfashioncatsummercontentd += '<img src="img/home/summerarivial/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByBoyFashionCatSummerContent').innerHTML = shopbyboyfashioncatsummercontentd;

}

//var swimwearLoop = 10;
function fillSliderShopByBoyFashionCatSwimwear(boyfashionswimwearLoop){
    
    var shopbyboyfashioncatswimwearcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < boyfashionswimwearLoop ; a++){
            shopbyboyfashioncatswimwearcontentd += '<img src="img/shopingportion/babyboyfashion/swiminhbrands/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByBoyFashionCatSwimwearContent').innerHTML = shopbyboyfashioncatswimwearcontentd;

}

//var acesummerlookLoop = 10;
function fillSliderShopByBoyFashionCatDayNight(boyfashiondaynightLoop){
    
    var shopbyboyfashioncatdaydaynightcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < boyfashiondaynightLoop ; a++){
            shopbyboyfashioncatdaydaynightcontentd += '<img src="img/home/nightwear/img2.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByBoyFashionCatDayNightContent').innerHTML = shopbyboyfashioncatdaydaynightcontentd;

}

//var acesummerlookLoop = 10;
function fillSliderShopByBoyFashionCatAceSummerLook(boyfashionacesummerlookLoop){
    
    var shopbyboyfashioncatdayacesummerlookcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < boyfashionacesummerlookLoop ; a++){
            shopbyboyfashioncatdayacesummerlookcontentd += '<img src="img/shopingportion/babyboyfashion/acesummerlook/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByBoyFashionCatAceSummerLookContent').innerHTML = shopbyboyfashioncatdayacesummerlookcontentd;

}

//var brandsweloveLoop = 10;
function fillSliderShopByBoyFashionCatBrandsWeLove(boyfashionbrandsweloveLoop){
    
    var shopbyboyfashioncatbrandswelovecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < boyfashionbrandsweloveLoop ; a++){
            shopbyboyfashioncatbrandswelovecontentd += '<img src="img/home/brandimages/img3.jpg" style="width: 100%; margin-top:5%;">';
            shopbyboyfashioncatbrandswelovecontentd += '<p style="font-weight: bold; font-size: 20px; text-align: center; text-decoration: underline;">Shop Now</p>';
    }

    document.getElementById('fillSliderShopByBoyFashionCatBrandsWeLoveContent').innerHTML = shopbyboyfashioncatbrandswelovecontentd;

}

// imagesend

// slider
function fillBoySliderLoop(boyslidertestloop){
    
    var boyslider = "";
    for(var a = 1; a <= boyslidertestloop ; a++){
        boyslider += '<div class="carousel-item">';
        boyslider += '<img src="img/shopingportion/babyboyfashion/sliderimages/img'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        boyslider += '</div>';                 
    }

    document.getElementById('fillBoySliderLoopContent').innerHTML = boyslider;
}
// sliderend