// dropdowns

// boyfashiob
//var testLoop = 10;
function fillSliderShopByCatHealthDropDown1(healthdropdown1testLoop){
    
    var shopbycathealthdropdown1contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < healthdropdown1testLoop ; a++){
            shopbycathealthdropdown1contentd += '<p href="#" style="color: black; margin-left: 2%;">Face Mask</p>';
    }

    document.getElementById('fillSliderShopByCatHealthDropDown1Content').innerHTML = shopbycathealthdropdown1contentd;

}

//var testLoop = 10;
function fillSliderShopByCatHealthDropDown2(healthdropdown2testLoop){
    
    var shopbycathealthdropdown2contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < healthdropdown2testLoop ; a++){
            shopbycathealthdropdown2contentd += '<p href="#" style="color: black; margin-left: 2%;">Face Mask</p>';
    }

    document.getElementById('fillSliderShopByCatHealthDropDown2Content').innerHTML = shopbycathealthdropdown2contentd;

}

//var testLoop = 10;
function fillSliderShopByCatHealthDropDown3(healthdropdown3testLoop){
    
    var shopbycathealthdropdown3contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < healthdropdown3testLoop ; a++){
            shopbycathealthdropdown3contentd += '<p href="#" style="color: black; margin-left: 2%;">Face Mask</p>';
    }

    document.getElementById('fillSliderShopByCatHealthDropDown3Content').innerHTML = shopbycathealthdropdown3contentd;

}

//var testLoop = 10;
function fillSliderShopByCatHealthDropDown4(healthdropdown4testLoop){
    
    var shopbycathealthdropdown4contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < healthdropdown4testLoop ; a++){
            shopbycathealthdropdown4contentd += '<p href="#" style="color: black; margin-left: 2%;">Face Mask</p>';
    }

    document.getElementById('fillSliderShopByCatHealthDropDown4Content').innerHTML = shopbycathealthdropdown4contentd;

}

//var testLoop = 10;
function fillSliderShopByCatHealthDropDown5(healthdropdown5testLoop){
    
    var shopbycathealthdropdown5contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < healthdropdown5testLoop ; a++){
            shopbycathealthdropdown5contentd += '<p href="#" style="color: black; margin-left: 2%;">Face Mask</p>';
    }

    document.getElementById('fillSliderShopByCatHealthDropDown5Content').innerHTML = shopbycathealthdropdown5contentd;

}


//var testLoop = 10;
function fillSliderShopByCatHealthBtns(healthbtnstestLoop){
    
    var shopbycathealthbtnscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < healthbtnstestLoop ; a++){
            shopbycathealthbtnscontentd += '<div id="fillSliderShopByCatOutdoorBtnsContent" style="background-color: white; border: 1px solid gray; border-right: none; border-left: none; border-top: none;">';
            shopbycathealthbtnscontentd += '<div style="padding-top: 3%; padding-left: 4%; height: 45px">';
            shopbycathealthbtnscontentd += '<p style="font-size: 18px; ">Heath Safety</p>';
            shopbycathealthbtnscontentd += '</div>';
            shopbycathealthbtnscontentd += '</div>';
    }

    document.getElementById('fillSliderShopByCatHealthBtnsContent').innerHTML = shopbycathealthbtnscontentd;

}
//  dropdownend

//var NursingImagesLoop = 10;
function fillSliderNursingHealthImage1(healthimages1testLoop){
    var shopbycathealthimages1contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < healthimages1testLoop ; a++){
            shopbycathealthimages1contentd += '<img src="img/shopingportion/healthsafety/banner2.jpg" style="width: 100%; margin-top:5%;">';
        
    }

    document.getElementById('fillSliderNursingHealthImage1Content').innerHTML = shopbycathealthimages1contentd;

}


// slider
function fillHealthSliderLoop(healthslidertestloop){
    
    var healthslider = "";
    for(var a = 1; a <= healthslidertestloop ; a++){
        healthslider += '<div class="carousel-item">';
        healthslider += '<img src="img/shopingportion/healthsafety/sliderimg'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        healthslider += '</div>';                 
    }

    document.getElementById('fillHealthSliderLoopContent').innerHTML = healthslider;
}
// sliderend