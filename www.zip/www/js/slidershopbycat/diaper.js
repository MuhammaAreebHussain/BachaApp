// dropdown

//var shopbydiapersizeLoop = 10;
function fillSliderShopByDiaperSizeDropDown(shopbydiapersizetestLoop){
    
    var shopbydiapersizedropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < shopbydiapersizetestLoop ; a++){
            shopbydiapersizedropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Size 3 (0-7 kgs)</p>';
    }
    document.getElementById('fillSliderShopByDiaperSizeDropDownContent').innerHTML = shopbydiapersizedropdowncontentd;
}

//var shopbydiaperweightLoop = 10;
function fillSliderShopByDiaperWeightDropDown(shopbydiaperweighttestLoop){
    
    var shopbydiaperweightdropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < shopbydiaperweighttestLoop ; a++){
            shopbydiaperweightdropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Size 3 (0-7 kgs)</p>';
    }

    document.getElementById('fillSliderShopByDiaperWeightDropDownContent').innerHTML = shopbydiaperweightdropdowncontentd;
}

//var shopbydiaperbrandsLoop = 10;
function fillSliderShopByDiaperBrandsDropDown(shopbydiaperbrandstestLoop){
    
    var shopbydiaperbrandsdropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < shopbydiaperbrandstestLoop ; a++){
            shopbydiaperbrandsdropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Size 3 (0-7 kgs)</p>';
    }

    document.getElementById('fillSliderShopByDiaperBrandsDropDownContent').innerHTML = shopbydiaperbrandsdropdowncontentd;
}

//var diapernappieLoop = 10;
function fillSliderDiaperNappieDropDown(diapernappietestLoop){
    
    var diapernappiedropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < diapernappietestLoop ; a++){
            diapernappiedropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Size 3 (0-7 kgs)</p>';
    }

    document.getElementById('fillSliderDiaperNappieDropDownContent').innerHTML = diapernappiedropdowncontentd;
}

//var pottytrainingLoop = 10;
function fillSliderPottyTrainingDropDown(pottytrainingtestLoop){
    
    var pottytrainingdropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < pottytrainingtestLoop ; a++){
            pottytrainingdropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Size 3 (0-7 kgs)</p>';
    }

    document.getElementById('fillSliderPottyTrainingDropDownContent').innerHTML = pottytrainingdropdowncontentd;
}

//var DiapertestLoop = 10;
function fillSliderDiaperBtns(diaperbtnstestLoop){
    var shopbycatdiaperbtnscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < diaperbtnstestLoop ; a++){

            shopbycatdiaperbtnscontentd += '<div id="fillSliderShopByCatOutdoorBtnsContent" style="background-color: white; border: 1px solid gray; border-right: none; border-left: none; border-top: none;">';
            shopbycatdiaperbtnscontentd += '<div style="padding-top: 3%; padding-left: 4%; height: 45px">';
            shopbycatdiaperbtnscontentd += '<p style="font-size: 18px; ">Combo Packs</p>';
            shopbycatdiaperbtnscontentd += '</div>';
            shopbycatdiaperbtnscontentd += '</div>';
    }

    document.getElementById('fillSliderDiaperBtnsContent').innerHTML = shopbycatdiaperbtnscontentd;

}

// dropdownends

// images

//var brandsweloveLoop = 10;
function fillSliderBrandsWeLove(brandsweloveimagestestLoop){
    var shopbycatbrandsweloveimagescontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < brandsweloveimagestestLoop ; a++){
            shopbycatbrandsweloveimagescontentd += '<div class="col-4">';
            shopbycatbrandsweloveimagescontentd += '<img src="img/shopingportion/diapering/banner1.jpg" style="width: 100%; margin-top:8%;">';
            shopbycatbrandsweloveimagescontentd += '</div>';
    }

    document.getElementById('fillSliderBrandsWeLoveImages').innerHTML = shopbycatbrandsweloveimagescontentd;

}

//var DiaperImagesLoop = 10;
function Diaper(diaperimagestestLoop){
    var shopbycatdiaperimagescontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < diaperimagestestLoop ; a++){
            shopbycatdiaperimagescontentd += '<img src="img/shopingportion/diapering/banner7.jpg" style="width: 100%;">';
        
    }

    document.getElementById('DiaperImages').innerHTML = shopbycatdiaperimagescontentd;

}

//var PottyTrainingLoop = 10;
function fillSliderPottyTraining(pottytrainingimagestestLoop){
    var shopbycatpottytrainingimagescontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < pottytrainingimagestestLoop ; a++){
            shopbycatpottytrainingimagescontentd += '<div class="col-4">';
            shopbycatpottytrainingimagescontentd += '<img src="img/shopingportion/diapering/banner8.jpg" style="width: 100%; margin-top:8%;">';
            shopbycatpottytrainingimagescontentd += '</div>';
    }

    document.getElementById('fillSliderPottyTrainingImages').innerHTML = shopbycatpottytrainingimagescontentd;

}


// slider
function fillDiaperingSliderLoop(diaperingslidertestloop){
    
    var diaperingslider = "";
    for(var a = 1; a <= diaperingslidertestloop ; a++){
        diaperingslider += '<div class="carousel-item">';
        diaperingslider += '<img src="img/shopingportion/diapering/sliderimg'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        diaperingslider += '</div>';                 
    }

    document.getElementById('fillDiaperingSliderLoopContent').innerHTML = diaperingslider;
}
// sliderend