// dropdowns

// boyfashiob
//var testLoop = 10;
function fillSliderShopByCatOutdoorDropDown1(outdoordropdown1testLoop){
    
    var shopbycatoutdoordropdown1contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < outdoordropdown1testLoop ; a++){
            shopbycatoutdoordropdown1contentd += '<p href="#" style="color: black; margin-left: 2%;">Slides</p>';
    }

    document.getElementById('fillSliderShopByCatOutdoorDropDown1Content').innerHTML = shopbycatoutdoordropdown1contentd;

}

//var testLoop = 10;
function fillSliderShopByCatOutdoorDropDown2(outdoordropdown2testLoop){
    
    var shopbycatoutdoordropdown2contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < outdoordropdown2testLoop ; a++){
            shopbycatoutdoordropdown2contentd += '<p href="#" style="color: black; margin-left: 2%;">Swimming Goggles</p>';
    }

    document.getElementById('fillSliderShopByCatOutdoorDropDown2Content').innerHTML = shopbycatoutdoordropdown2contentd;

}

//var testLoop = 10;
function fillSliderShopByCatOutdoorDropDown3(outdoordropdown3testLoop){
    
    var shopbycatoutdoordropdown3contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < outdoordropdown3testLoop ; a++){
            shopbycatoutdoordropdown3contentd += '<p href="#" style="color: black; margin-left: 2%;">Beach Ball</p>';
    }

    document.getElementById('fillSliderShopByCatOutdoorDropDown3Content').innerHTML = shopbycatoutdoordropdown3contentd;

}

//var testLoop = 10;
function fillSliderShopByCatOutdoorDropDown4(outdoordropdown4testLoop){
    
    var shopbycatoutdoordropdown4contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < outdoordropdown4testLoop ; a++){
            shopbycatoutdoordropdown4contentd += '<p href="#" style="color: black; margin-left: 2%;">Beach Ball</p>';
    }

    document.getElementById('fillSliderShopByCatOutdoorDropDown4Content').innerHTML = shopbycatoutdoordropdown4contentd;

}

//var testLoop = 10;
function fillSliderShopByCatOutdoorDropDown5(outdoordropdown5testLoop){
    
    var shopbycatoutdoordropdown5contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < outdoordropdown5testLoop ; a++){
            shopbycatoutdoordropdown5contentd += '<p href="#" style="color: black; margin-left: 2%;">Beach Ball</p>';
    }

    document.getElementById('fillSliderShopByCatOutdoorDropDown5Content').innerHTML = shopbycatoutdoordropdown5contentd;

}

//var testLoop = 10;
function fillSliderShopByCatOutdoorDropDown6(outdoordropdown6testLoop){
    
    var shopbycatoutdoordropdown6contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < outdoordropdown6testLoop ; a++){
            shopbycatoutdoordropdown6contentd += '<p href="#" style="color: black; margin-left: 2%;">Beach Ball</p>';
    }

    document.getElementById('fillSliderShopByCatOutdoorDropDown6Content').innerHTML = shopbycatoutdoordropdown6contentd;

}

//var testLoop = 10;
function fillSliderShopByCatOutdoorBtns(outdoorbtnstestLoop){
    
    var shopbycatoutdoorbtnscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < outdoorbtnstestLoop ; a++){
            shopbycatoutdoorbtnscontentd += '<div id="fillSliderShopByCatOutdoorBtnsContent" style="background-color: white; border: 1px solid gray; border-right: none; border-left: none; border-top: none;">';
            shopbycatoutdoorbtnscontentd += '<div style="padding-top: 3%; padding-left: 4%; height: 45px">';
            shopbycatoutdoorbtnscontentd += '<p style="font-size: 18px; ">Sports Games</p>';
            shopbycatoutdoorbtnscontentd += '</div>';
            shopbycatoutdoorbtnscontentd += '</div>';
    }

    document.getElementById('fillSliderShopByCatOutdoorBtnsContent').innerHTML = shopbycatoutdoorbtnscontentd;

}
//  dropdownend


// images


//var boutiqueLoop = 10;
function fillSliderShopByOutdoorPoolAccessories(outdoorpoolaccessoriesLoop){
    
    var shopbycatfootwearoutdoorpoolaccessoriescontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < outdoorpoolaccessoriesLoop ; a++){
            shopbycatfootwearoutdoorpoolaccessoriescontentd += '<img src="img/shopingportion/outdoor/banners/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByOutdoorPoolAccessoriesContent').innerHTML = shopbycatfootwearoutdoorpoolaccessoriescontentd;

}


// slider
function fillOutdoorSliderLoop(outdoorslidertestloop){
    
    var outdoorslider = "";
    for(var a = 1; a <= outdoorslidertestloop ; a++){
        outdoorslider += '<div class="carousel-item">';
        outdoorslider += '<img src="img/shopingportion/toys/sliderimg'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        outdoorslider += '</div>';                 
    }

    document.getElementById('fillOutdoorSliderLoopContent').innerHTML = outdoorslider;
}
// sliderend