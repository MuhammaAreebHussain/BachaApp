// dropdowns

// boyfashiob
//var testLoop = 10;
function fillSliderShopByCatCharacterShopDropDown1(charactershopdropdown1testLoop){
    
    var shopbycatcharactershopdropdown1contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < charactershopdropdown1testLoop ; a++){
            shopbycatcharactershopdropdown1contentd += '<p href="#" style="color: black; margin-left: 2%;">Spider Man</p>';
    }

    document.getElementById('fillSliderShopByCatCharacterShopDropDown1Content').innerHTML = shopbycatcharactershopdropdown1contentd;

}

//var testLoop = 10;
function fillSliderShopByCatCharacterShopDropDown2(charactershopdropdown2testLoop){
    
    var shopbycatcharactershopdropdown2contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < charactershopdropdown2testLoop ; a++){
            shopbycatcharactershopdropdown2contentd += '<p href="#" style="color: black; margin-left: 2%;">Boy</p>';
    }

    document.getElementById('fillSliderShopByCatCharacterShopDropDown2Content').innerHTML = shopbycatcharactershopdropdown2contentd;

}

//var testLoop = 10;
function fillSliderShopByCatCharacterShopDropDown3(charactershopdropdown3testLoop){
    
    var shopbycatcharactershopdropdown3contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < charactershopdropdown3testLoop ; a++){
            shopbycatcharactershopdropdown3contentd += '<p href="#" style="color: black; margin-left: 2%;">1-6 Months</p>';
    }

    document.getElementById('fillSliderShopByCatCharacterShopDropDown3Content').innerHTML = shopbycatcharactershopdropdown3contentd;

}

//var testLoop = 10;
function fillSliderShopByCatCharacterShopDropDown4(charactershopdropdown4testLoop){
    
    var shopbycatcharactershopdropdown4contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < charactershopdropdown4testLoop ; a++){
            shopbycatcharactershopdropdown4contentd += '<p href="#" style="color: black; margin-left: 2%;">Super Heroes</p>';
    }

    document.getElementById('fillSliderShopByCatCharacterShopDropDown4Content').innerHTML = shopbycatcharactershopdropdown4contentd;

}


//var testLoop = 10;
function fillSliderShopByCatCharacterShopDropDown5(charactershopdropdown5testLoop){
    
    var shopbycatcharactershopdropdown5contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < charactershopdropdown5testLoop ; a++){
            shopbycatcharactershopdropdown5contentd += '<p href="#" style="color: black; margin-left: 2%;">Super Heroes</p>';
    }

    document.getElementById('fillSliderShopByCatCharacterShopDropDown5Content').innerHTML = shopbycatcharactershopdropdown5contentd;

}

//  dropdownend


//var boutiqueLoop = 10;
function fillSliderShopByCharacterShopDisneyShop(charactershopdisneyshopLoop){
    
    var shopbycatfootwearcharactershopdisneyshopcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < charactershopdisneyshopLoop ; a++){
            shopbycatfootwearcharactershopdisneyshopcontentd += '<img src="img/shopingportion/characyershop/banner1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCharacterShopDisneyShopContent').innerHTML = shopbycatfootwearcharactershopdisneyshopcontentd;

}


//var boutiqueLoop = 10;
function fillSliderShopByCharacterShopSuperHero(charactershopsuperheroLoop){
    
    var shopbycatfootwearcharactershopsuperherocontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < charactershopsuperheroLoop ; a++){
            shopbycatfootwearcharactershopsuperherocontentd += '<img src="img/shopingportion/characyershop/banner2.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCharacterShopSuperHeroContent').innerHTML = shopbycatfootwearcharactershopsuperherocontentd;

}

//var boutiqueLoop = 10;
// function fillSliderShopByCharacterShopPrincessCharacter(charactershopprincesscharacterLoop){
    
//     var shopbycatfootwearcharactershopprincesscharactercontentd = "";
//     // $.each(testLoop, function(index,value){
//         for(var a = 0; a < charactershopprincesscharacterLoop ; a++){
//             shopbycatfootwearcharactershopprincesscharactercontentd += ' <div class="col-6">';
//             shopbycatfootwearcharactershopprincesscharactercontentd += '<img src="img/shopingportion/characyershop/banner3.jpg" style="width: 30%;">';
//             shopbycatfootwearcharactershopprincesscharactercontentd += ' </div>';
//     }


//     document.getElementById('fillSliderShopByCharacterShopPrincessCharacterContent').innerHTML = shopbycatfootwearcharactershopprincesscharactercontentd;

// }


// slider
function fillCharacterSliderLoop(characterslidertestloop){
    
    var characterslider = "";
    for(var a = 1; a <= characterslidertestloop ; a++){
        characterslider += '<div class="carousel-item">';
        characterslider += '<img src="img/shopingportion/characyershop/sliderimg'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        characterslider += '</div>';                 
    }

    document.getElementById('fillCharacterSliderLoopContent').innerHTML = characterslider;
}
// sliderend