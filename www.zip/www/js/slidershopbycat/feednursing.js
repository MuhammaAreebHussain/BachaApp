// dropdown

//var shopbydiapersizeLoop = 10;
function fillSliderFeedNursingDropDown1(feednursingdropdown1testLoop){
    
    var feednursingdropdown1contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < feednursingdropdown1testLoop ; a++){
            feednursingdropdown1contentd += '<p href="#" style="color: black; margin-left: 2%;">Size 3 (0-7 kgs)</p>';
    }
    document.getElementById('fillSliderFeedNursingDropDown1Content').innerHTML = feednursingdropdown1contentd;
}

//var shopbydiapersizeLoop = 10;
function fillSliderFeedNursingDropDown2(feednursingdropdown2testLoop){
    
    var feednursingdropdown2contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < feednursingdropdown2testLoop ; a++){
            feednursingdropdown2contentd += '<p href="#" style="color: black; margin-left: 2%;">Size 3 (0-7 kgs)</p>';
    }
    document.getElementById('fillSliderFeedNursingDropDown2Content').innerHTML = feednursingdropdown2contentd;
}

//var shopbydiapersizeLoop = 10;
function fillSliderFeedNursingDropDown3(feednursingdropdown3testLoop){
    
    var feednursingdropdown3contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < feednursingdropdown3testLoop ; a++){
            feednursingdropdown3contentd += '<p href="#" style="color: black; margin-left: 2%;">Size 3 (0-7 kgs)</p>';
    }
    document.getElementById('fillSliderFeedNursingDropDown3Content').innerHTML = feednursingdropdown3contentd;
}

//var shopbydiapersizeLoop = 10;
function fillSliderFeedNursingDropDown4(feednursingdropdown4testLoop){
    
    var feednursingdropdown4contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < feednursingdropdown4testLoop ; a++){
            feednursingdropdown4contentd += '<p href="#" style="color: black; margin-left: 2%;">Size 3 (0-7 kgs)</p>';
    }
    document.getElementById('fillSliderFeedNursingDropDown4Content').innerHTML = feednursingdropdown4contentd;
}

//var shopbydiapersizeLoop = 10;
function fillSliderFeedNursingDropDown5(feednursingdropdown5testLoop){
    
    var feednursingdropdown5contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < feednursingdropdown5testLoop ; a++){
            feednursingdropdown5contentd += '<p href="#" style="color: black; margin-left: 2%;">Size 3 (0-7 kgs)</p>';
    }
    document.getElementById('fillSliderFeedNursingDropDown5Content').innerHTML = feednursingdropdown5contentd;
}

//var shopbydiapersizeLoop = 10;
function fillSliderFeedNursingDropDown6(feednursingdropdown6testLoop){
    
    var feednursingdropdown6contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < feednursingdropdown6testLoop ; a++){
            feednursingdropdown6contentd += '<p href="#" style="color: black; margin-left: 2%;">Size 3 (0-7 kgs)</p>';
    }
    document.getElementById('fillSliderFeedNursingDropDown6Content').innerHTML = feednursingdropdown6contentd;
}

//var shopbydiapersizeLoop = 10;
function fillSliderFeedNursingDropDown7(feednursingdropdown7testLoop){
    
    var feednursingdropdown7contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < feednursingdropdown7testLoop ; a++){
            feednursingdropdown7contentd += '<p href="#" style="color: black; margin-left: 2%;">Size 3 (0-7 kgs)</p>';
    }
    document.getElementById('fillSliderFeedNursingDropDown7Content').innerHTML = feednursingdropdown7contentd;
}

//var shopbydiapersizeLoop = 10;
function fillSliderFeedNursingDropDown8(feednursingdropdown8testLoop){
    
    var feednursingdropdown8contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < feednursingdropdown8testLoop ; a++){
            feednursingdropdown8contentd += '<p href="#" style="color: black; margin-left: 2%;">Size 3 (0-7 kgs)</p>';
    }
    document.getElementById('fillSliderFeedNursingDropDown8Content').innerHTML = feednursingdropdown8contentd;
}

// dropdownend

// images
function  fillSliderNursingFeedingImage1(nursingfeedingimage1testLoop){
    
    var nursingfeedingimage1contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < nursingfeedingimage1testLoop ; a++){
            nursingfeedingimage1contentd += '<img src="img/shopingportion/feedingandnursing/banner1.jpg" style="width: 100%; margin-top:5%;">';
    }
    document.getElementById('fillSliderNursingFeedingImage1Content').innerHTML = nursingfeedingimage1contentd;
}

function  fillSliderNursingFeedingImage2(nursingfeedingimage2testLoop){
    
    var nursingfeedingimage2contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < nursingfeedingimage2testLoop ; a++){
            nursingfeedingimage2contentd += '<img src="img/shopingportion/feedingandnursing/banner5.jpg" style="width: 100%; margin-top:5%;">';
    }
    document.getElementById('fillSliderNursingFeedingImage2Content').innerHTML = nursingfeedingimage2contentd;
}

function  fillSliderNursingFeedingImage3(nursingfeedingimage3testLoop){
    
    var nursingfeedingimage3contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < nursingfeedingimage3testLoop ; a++){
            nursingfeedingimage3contentd += '<img src="img/shopingportion/feedingandnursing/banner10.jpg" style="width: 100%; margin-top:5%;">';
    }
    document.getElementById('fillSliderNursingFeedingImage3Content').innerHTML = nursingfeedingimage3contentd;
}





// slider
function fillNursingSliderLoop(nursingslidertestloop){
    
    var nursingslider = "";
    for(var a = 1; a <= nursingslidertestloop ; a++){
        nursingslider += '<div class="carousel-item">';
        nursingslider += '<img src="img/shopingportion/feedingandnursing/sliderimg'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        nursingslider += '</div>';                 
    }

    document.getElementById('fillNursingSliderLoopContent').innerHTML = nursingslider;
}
// sliderend