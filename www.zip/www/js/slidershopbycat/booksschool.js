// dropdown

//var booksschoolLoop = 10;
function fillSliderShopByCatBooksDropDownShopByCategory(booksshopbycategoryLoop){
    
    var shopbycatbooksdropdownshopbycategorycontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < booksshopbycategoryLoop ; a++){
            shopbycatbooksdropdownshopbycategorycontentd += '<p href="#" style="color: black; margin-left: 2%; font-size:12px">Lunch Box</p>';
    }
    document.getElementById('fillSliderShopByCatBooksDropDownShopByCategoryContent').innerHTML = shopbycatbooksdropdownshopbycategorycontentd;
}

//var booksschoolLoop = 10;
function fillSliderShopByCatSchoolDropDownStationary(schoolstationaryLoop){
    
    var shopbycatbooksdropdownstationarycontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < schoolstationaryLoop ; a++){
            shopbycatbooksdropdownstationarycontentd += '<p href="#" style="color: black; margin-left: 2%; font-size:12px">Pencil</p>';
    }
    document.getElementById('fillSliderShopByCatSchoolDropDownStationaryContent').innerHTML = shopbycatbooksdropdownstationarycontentd;
}

//var booksschoolLoop = 10;
function fillSliderShopByCatSchoolDropDownWatterBottles(schoolwatterbottlesLoop){
    
    var shopbycatbooksdropdownwaterbottlescontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < schoolwatterbottlesLoop ; a++){
            shopbycatbooksdropdownwaterbottlescontentd += '<p href="#" style="color: black; margin-left: 2%; font-size:12px">Pencil</p>';
    }
    document.getElementById('fillSliderShopByCatSchoolDropDownWatterBottlesContent').innerHTML = shopbycatbooksdropdownwaterbottlescontentd;
}




//var testLoop = 10;
function fillSliderBooksschoolBtns(booksschoolbtnstestLoop){
    var shopbycatbooksschoolbtnscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < booksschoolbtnstestLoop ; a++){

            shopbycatbooksschoolbtnscontentd += '<div id="fillSliderShopByCatOutdoorBtnsContent" style="background-color: white; border: 1px solid gray; border-right: none; border-left: none; border-top: none;">';
            shopbycatbooksschoolbtnscontentd += '<div style="padding-top: 3%; padding-left: 4%; height: 45px">';
            shopbycatbooksschoolbtnscontentd += '<p style="font-size: 18px; ">School Bags</p>';
            shopbycatbooksschoolbtnscontentd += '</div>';
            shopbycatbooksschoolbtnscontentd += '</div>';
    }

    document.getElementById('fillSliderBooksschoolBtnsContent').innerHTML = shopbycatbooksschoolbtnscontentd;

}

// bropdownend


// images

//var studymaterialLoop = 10;
function fillSliderShopByCatBookSchoolsStudyMaterial(studymaterialLoop){
    
    var shopbycatstudymaterialcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < studymaterialLoop ; a++){
            shopbycatstudymaterialcontentd += '<img src="img/shopingportion/boksandschool/banner1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatBookSchoolsStudyMaterialContent').innerHTML = shopbycatstudymaterialcontentd;

}

//var studymaterialLoop = 10;
function fillSliderShopByCatBookSchoolsLunchTime(lunchtimeLoop){
    
    var shopbycatlunchtimecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < lunchtimeLoop ; a++){
            shopbycatlunchtimecontentd += '<img src="img/shopingportion/boksandschool/banner9.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatBookSchoolsLunchTimeContent').innerHTML = shopbycatlunchtimecontentd;

}

//var colorLoop = 10;
function fillSliderShopByCatBookSchoolsColor(colorLoop){
    
    var shopbycatcolorcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < colorLoop ; a++){
            shopbycatcolorcontentd += '<img src="img/shopingportion/boksandschool/banner12.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatBookSchoolsColorContent').innerHTML = shopbycatcolorcontentd;

}

// slider
function fillBooksSliderLoop(booksslidertestloop){
    
    var booksslider = "";
    for(var a = 1; a <= booksslidertestloop ; a++){
        booksslider += '<div class="carousel-item">';
        booksslider += '<img src="img/shopingportion/boksandschool/sliderimg'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        booksslider += '</div>';                 
    }

    document.getElementById('fillBooksSliderLoopContent').innerHTML = booksslider;
}
// sliderend