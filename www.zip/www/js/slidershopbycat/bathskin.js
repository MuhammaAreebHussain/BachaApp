// dropdowns

// boyfashiob
//var testLoop = 10;
function fillSliderShopByCatBathSkinDropDown1(skincaredropdown1testLoop){
    
    var shopbycatskincaredropdown1contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < skincaredropdown1testLoop ; a++){
            shopbycatskincaredropdown1contentd += '<p href="#" style="color: black; margin-left: 2%;">Slides</p>';
    }

    document.getElementById('fillSliderShopByCatBathSkinDropDown1Content').innerHTML = shopbycatskincaredropdown1contentd;

}

//var testLoop = 10;
function fillSliderShopByCatBathSkinDropDown2(bathskindropdown2testLoop){
    
    var shopbycatbathskindropdown2contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < bathskindropdown2testLoop ; a++){
            shopbycatbathskindropdown2contentd += '<p href="#" style="color: black; margin-left: 2%;">Body Wash</p>';
    }

    document.getElementById('fillSliderShopByCatBathSkinDropDown2Content').innerHTML = shopbycatbathskindropdown2contentd;

}

//var testLoop = 10;
function fillSliderShopByCatBathSkinDropDown3(bathskindropdown3testLoop){
    
    var shopbycatbathskindropdown3contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < bathskindropdown3testLoop ; a++){
            shopbycatbathskindropdown3contentd += '<p href="#" style="color: black; margin-left: 2%;">Beach Ball</p>';
    }

    document.getElementById('fillSliderShopByCatBathSkinDropDown3Content').innerHTML = shopbycatbathskindropdown3contentd;

}
//var testLoop = 10;
function fillSliderShopByCatBathSkinDropDown4(bathskindropdown4testLoop){
    
    var shopbycatbathskindropdown4contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < bathskindropdown4testLoop ; a++){
            shopbycatbathskindropdown4contentd += '<p href="#" style="color: black; margin-left: 2%;">Beach Ball</p>';
    }

    document.getElementById('fillSliderShopByCatBathSkinDropDown4Content').innerHTML = shopbycatbathskindropdown4contentd;

}

//var testLoop = 10;
function fillSliderShopByCatBathSkinDropDown5(bathskindropdown5testLoop){
    
    var shopbycatbathskindropdown5contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < bathskindropdown5testLoop ; a++){
            shopbycatbathskindropdown5contentd += '<p href="#" style="color: black; margin-left: 2%;">Beach Ball</p>';
    }

    document.getElementById('fillSliderShopByCatBathSkinDropDown5Content').innerHTML = shopbycatbathskindropdown5contentd;

}

//var testLoop = 10;
function fillSliderShopByCatBathSkinDropDown6(bathskindropdown6testLoop){
    
    var shopbycatbathskindropdown6contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < bathskindropdown6testLoop ; a++){
            shopbycatbathskindropdown6contentd += '<p href="#" style="color: black; margin-left: 2%;">Beach Ball</p>';
    }

    document.getElementById('fillSliderShopByCatBathSkinDropDown6Content').innerHTML = shopbycatbathskindropdown6contentd;

}

//var testLoop = 10;
function fillSliderShopByCatBathSkinBtns(bathskinbtnstestLoop){
    
    var shopbycatbathskinbtnscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < bathskinbtnstestLoop ; a++){
            shopbycatbathskinbtnscontentd += '<div id="fillSliderShopByCatOutdoorBtnsContent" style="background-color: white; border: 1px solid gray; border-right: none; border-left: none; border-top: none;">';
            shopbycatbathskinbtnscontentd += '<div style="padding-top: 3%; padding-left: 4%; height: 45px">';
            shopbycatbathskinbtnscontentd += '<p style="font-size: 18px; ">Bath Toys</p>';
            shopbycatbathskinbtnscontentd += '</div>';
            shopbycatbathskinbtnscontentd += '</div>';
    }

    document.getElementById('fillSliderShopByCatBathSkinBtnsContent').innerHTML = shopbycatbathskinbtnscontentd;

}
//  dropdownend


// slider
function fillBathSliderLoop(bathslidertestloop){
    
    var bathslider = "";
    for(var a = 1; a <= bathslidertestloop ; a++){
        bathslider += '<div class="carousel-item">';
        bathslider += '<img src="img/shopingportion/bathskincare/sliderimg'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        bathslider += '</div>';                 
    }

    document.getElementById('fillBathSliderLoopContent').innerHTML = bathslider;
}
// sliderend