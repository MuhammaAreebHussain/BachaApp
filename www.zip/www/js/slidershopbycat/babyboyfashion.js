// dropdowns

//var testLoop = 10;
function fillSliderShopByCatBabyBoyFashionDropDown(testLoop){
    
    var shopbycatbabyboyfashiondropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < testLoop ; a++){
            shopbycatbabyboyfashiondropdowncontentd += '<p  href="#" style="color: black; margin-left: 2%;">Summer Collection upto 40% off'+ a +'</p>';
    }

    document.getElementById('fillSliderShopByCatBabyBoyFashionDropDownContent').innerHTML = shopbycatbabyboyfashiondropdowncontentd;

}

// babyboycloths

//var babyboyclothsLoop = 10;
function fillSliderShopByCatBabyBoyClothsDropDownTill6Months(babyboyclothstill6monthsLoop){
    
    var shopbycatbabyboyclothsdropdowntill6monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babyboyclothstill6monthsLoop ; a++){
            shopbycatbabyboyclothsdropdowntill6monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBabyBoyClothsDropDownTill6MonthsContent').innerHTML = shopbycatbabyboyclothsdropdowntill6monthscontentd;
}
function fillSliderShopByCatBabyBoyClothsDropDownTill9Months(babyboyclothstill9monthsLoop){
    
    var shopbycatbabyboyclothsdropdowntill9monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babyboyclothstill9monthsLoop ; a++){
            shopbycatbabyboyclothsdropdowntill9monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBabyBoyClothsDropDownTill9MonthsContent').innerHTML = shopbycatbabyboyclothsdropdowntill9monthscontentd;
}
function fillSliderShopByCatBabyBoyClothsDropDownTill12Months(babyboyclothstill12monthsLoop){
    
    var shopbycatbabyboyclothsdropdowntill12monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babyboyclothstill12monthsLoop ; a++){
            shopbycatbabyboyclothsdropdowntill12monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBabyBoyClothsDropDownTill12MonthsContent').innerHTML = shopbycatbabyboyclothsdropdowntill12monthscontentd;
}
function fillSliderShopByCatBabyBoyClothsDropDownTill15Months(babyboyclothstill15monthsLoop){
    
    var shopbycatbabyboyclothsdropdowntill15monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babyboyclothstill15monthsLoop ; a++){
            shopbycatbabyboyclothsdropdowntill15monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBabyBoyClothsDropDownTill15MonthsContent').innerHTML = shopbycatbabyboyclothsdropdowntill15monthscontentd;
}
function fillSliderShopByCatBabyBoyClothsDropDownTill18Months(babyboyclothstill18monthsLoop){
    
    var shopbycatbabyboyclothsdropdowntill18monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babyboyclothstill18monthsLoop ; a++){
            shopbycatbabyboyclothsdropdowntill18monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBabyBoyClothsDropDownTill18MonthsContent').innerHTML = shopbycatbabyboyclothsdropdowntill18monthscontentd;
}

// babyboyclothsend

// footwear

//var footwearLoop = 10;
function fillSliderShopByCatFootwearDropDownShopByCat(footwearLoopCat){
    
    var shopbycatfootweardropdowncatcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footwearLoopCat ; a++){
            shopbycatfootweardropdowncatcontentd += '<p href="#" style="color: black; margin-left: 2%;">Casual Shoes</p>';
    }
    document.getElementById('fillSliderShopByCatFootwearDropDownContentCat').innerHTML = shopbycatfootweardropdowncatcontentd;
}
//var footwearLoop = 10;
function fillSliderShopByCatFootwearDropDownShopByAge(footwearLoopAge){
    
    var shopbycatfootweardropdownagecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footwearLoopAge ; a++){
            shopbycatfootweardropdownagecontentd += '<p href="#" style="color: black; margin-left: 2%;">0-3 Months</p>';
    }
    document.getElementById('fillSliderShopByCatFootwearDropDownContentAge').innerHTML = shopbycatfootweardropdownagecontentd;
}
//var footwearLoop = 10;
function fillSliderShopByCatFootwearDropDownShopBySpecialOffer(footwearLoopOffer){
    
    var shopbycatfootweardropdownoffercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footwearLoopOffer ; a++){
            shopbycatfootweardropdownoffercontentd += '<p href="#" style="color: black; margin-left: 2%;">Upto 30% off</p>';
    }
    document.getElementById('fillSliderShopByCatFootwearDropDownContentOffer').innerHTML = shopbycatfootweardropdownoffercontentd;
}
// footwearend

// popularbrands
//var popularbrandsLoop = 10;
function fillSliderShopByCatPopularBrandsDropDown(popularbrandsLoop){
    
    var shopbycatpopularbrandsdropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < popularbrandsLoop ; a++){
            shopbycatpopularbrandsdropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Carters</p>';
    }

    document.getElementById('fillSliderShopByCatPopularBrandsDropDownContent').innerHTML = shopbycatpopularbrandsdropdowncontentd;

}
// popularbrandsend
// dropdownsend

// images

//var boutiqueLoop = 10;
function fillSliderShopByCatBoutique(boutiqueLoop){
    
    var shopbycatboutiquecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < boutiqueLoop ; a++){
            shopbycatboutiquecontentd += '<img src="img/shopingportion/babyboyfashion/boutiques/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatBoutiqueContent').innerHTML = shopbycatboutiquecontentd;

}

//var carterLoop = 10;
function fillSliderShopByCatCarter(carterLoop){
    
    var shopbycatcartercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < carterLoop ; a++){
            shopbycatcartercontentd += '<img src="img/home/carters/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatCarterContent').innerHTML = shopbycatcartercontentd;

}

//var summerLoop = 10;
function fillSliderShopByCatSummer(summerLoop){
    
    var shopbycatsummercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < summerLoop ; a++){
            shopbycatsummercontentd += '<img src="img/home/summerarivial/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatSummerContent').innerHTML = shopbycatsummercontentd;

}

//var swimwearLoop = 10;
function fillSliderShopByCatSwimwear(swimwearLoop){
    
    var shopbycatswimwearcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < swimwearLoop ; a++){
            shopbycatswimwearcontentd += '<img src="img/shopingportion/babyboyfashion/swiminhbrands/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatSwimwearContent').innerHTML = shopbycatswimwearcontentd;

}

//var acesummerlookLoop = 10;
function fillSliderShopByCatDayNight(daynightLoop){
    
    var shopbycatdaydaynightcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < daynightLoop ; a++){
            shopbycatdaydaynightcontentd += '<img src="img/shopingportion/babyboyfashion/acesummerlook/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatDayNightContent').innerHTML = shopbycatdaydaynightcontentd;

}

//var acesummerlookLoop = 10;
function fillSliderShopByCatAceSummerLook(acesummerlookLoop){
    
    var shopbycatdayacesummerlookcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < acesummerlookLoop ; a++){
            shopbycatdayacesummerlookcontentd += '<img src="img/shopingportion/babyboyfashion/acesummerlook/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatAceSummerLookContent').innerHTML = shopbycatdayacesummerlookcontentd;

}

//var brandsweloveLoop = 10;
function fillSliderShopByCatBrandsWeLove(brandsweloveLoop){
    
    var shopbycatbrandswelovecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < brandsweloveLoop ; a++){
            shopbycatbrandswelovecontentd += '<img src="img/home/brandimages/img3.jpg" style="width: 100%; margin-top:5%;">';
            shopbycatbrandswelovecontentd += '<p style="font-weight: bold; font-size: 20px; text-align: center; text-decoration: underline;">Shop Now</p>';
    }

    document.getElementById('fillSliderShopByCatBrandsWeLoveContent').innerHTML = shopbycatbrandswelovecontentd;

}

// imagesend

// slider
function fillBabyBoySliderLoop(babyboyslidertestloop){
    
    var babyboyslider = "";
    for(var a = 1; a <= babyboyslidertestloop ; a++){
        babyboyslider += '<div class="carousel-item">';
        babyboyslider += '<img src="img/shopingportion/babyboyfashion/sliderimages/img'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        babyboyslider += '</div>';                 
    }

    document.getElementById('fillBabyBoySliderLoopContent').innerHTML = babyboyslider;
}
// sliderend