
// dropdowns

// boyfashiob
//var testLoop = 10;
function fillSliderShopByCatMomsDropDown1(momsdropdown1testLoop){
    
    var shopbycatmomsdropdown1contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < momsdropdown1testLoop ; a++){
            shopbycatmomsdropdown1contentd += '<p href="#" style="color: black; margin-left: 2%;">Breast Feeding</p>';
    }

    document.getElementById('fillSliderShopByCatMomsDropDown1Content').innerHTML = shopbycatmomsdropdown1contentd;

}

//var testLoop = 10;
function fillSliderShopByCatMomsDropDown2(momsdropdown2testLoop){
    
    var shopbycatmomsdropdown2contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < momsdropdown2testLoop ; a++){
            shopbycatmomsdropdown2contentd += '<p href="#" style="color: black; margin-left: 2%;">Breast Feeding</p>';
    }

    document.getElementById('fillSliderShopByCatMomsDropDown2Content').innerHTML = shopbycatmomsdropdown2contentd;

}

//var testLoop = 10;
function fillSliderShopByCatMomsDropDown3(momsdropdown3testLoop){
    
    var shopbycatmomsdropdown3contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < momsdropdown3testLoop ; a++){
            shopbycatmomsdropdown3contentd += '<p href="#" style="color: black; margin-left: 2%;">Breast Feeding</p>';
    }

    document.getElementById('fillSliderShopByCatMomsDropDown3Content').innerHTML = shopbycatmomsdropdown3contentd;

}

//var testLoop = 10;
function fillSliderShopByCatMomsDropDown4(momsdropdown4testLoop){
    
    var shopbycatmomsdropdown4contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < momsdropdown4testLoop ; a++){
            shopbycatmomsdropdown4contentd += '<p href="#" style="color: black; margin-left: 2%;">Breast Feeding</p>';
    }

    document.getElementById('fillSliderShopByCatMomsDropDown4Content').innerHTML = shopbycatmomsdropdown4contentd;

}


//var testLoop = 10;
function fillSliderShopByCatMomsBtns(momsbtnstestLoop){
    
    var shopbycatmomsbtnscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < momsbtnstestLoop ; a++){
            shopbycatmomsbtnscontentd += '<div id="fillSliderShopByCatOutdoorBtnsContent" style="background-color: white; border: 1px solid gray; border-right: none; border-left: none; border-top: none;">';
            shopbycatmomsbtnscontentd += '<div style="padding-top: 3%; padding-left: 4%; height: 45px">';
            shopbycatmomsbtnscontentd += '<p style="font-size: 18px; ">Bath Toys</p>';
            shopbycatmomsbtnscontentd += '</div>';
            shopbycatmomsbtnscontentd += '</div>';
    }

    document.getElementById('fillSliderShopByCatMomsBtnsContent').innerHTML = shopbycatmomsbtnscontentd;

}
//  dropdownend


//var NursingImagesLoop = 10;
function fillSliderNursingMomsImage2(momsimages2testLoop){
    var shopbycatmomsimages2contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < momsimages2testLoop ; a++){
            shopbycatmomsimages2contentd += '<img src="img/shopingportion/diapering/moms/banner2.jpg" style="width: 100%; margin-top:5%;">';
        
    }

    document.getElementById('fillSliderMomsImage2Content').innerHTML = shopbycatmomsimages2contentd;

}



// slider
function fillMomSliderLoop(momslidertestloop){
    
    var momslider = "";
    for(var a = 1; a <= momslidertestloop ; a++){
        momslider += '<div class="carousel-item">';
        momslider += '<img src="img/shopingportion/nursery/sliderimg'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        momslider += '</div>';                 
    }

    document.getElementById('fillMomSliderLoopContent').innerHTML = momslider;
}
// sliderend