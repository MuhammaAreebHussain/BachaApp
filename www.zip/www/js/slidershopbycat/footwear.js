// dropdowns



// boyfashiob
//var testLoop = 10;
function fillSliderShopByCatFootwearDropDown1(footweardropdown1testLoop){
    
    var shopbycatfootweardropdown1contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footweardropdown1testLoop ; a++){
            shopbycatfootweardropdown1contentd += '<p href="#" style="color: black; margin-left: 2%;">Boy Footwear</p>';
    }

    document.getElementById('fillSliderShopByCatFootwearDropDown1Content').innerHTML = shopbycatfootweardropdown1contentd;

}

//var testLoop = 10;
function fillSliderShopByCatFootwearDropDown2(footweardropdown2testLoop){
    
    var shopbycatfootweardropdown2contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footweardropdown2testLoop ; a++){
            shopbycatfootweardropdown2contentd += '<p href="#" style="color: black; margin-left: 2%;">Sneakers</p>';
    }

    document.getElementById('fillSliderShopByCatFootwearDropDown2Content').innerHTML = shopbycatfootweardropdown2contentd;

}

//var testLoop = 10;
function fillSliderShopByCatFootwearDropDown3(footweardropdown3testLoop){
    
    var shopbycatfootweardropdown3contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footweardropdown3testLoop ; a++){
            shopbycatfootweardropdown3contentd += '<p href="#" style="color: black; margin-left: 2%;">Upto 40% Off</p>';
    }

    document.getElementById('fillSliderShopByCatFootwearDropDown3Content').innerHTML = shopbycatfootweardropdown3contentd;

}

//var testLoop = 10;
function fillSliderShopByCatFootwearDropDown4(footweardropdown4testLoop){
    
    var shopbycatfootweardropdown4contentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footweardropdown4testLoop ; a++){
            shopbycatfootweardropdown4contentd += '<p href="#" style="color: black; margin-left: 2%;">Pumas</p>';
    }

    document.getElementById('fillSliderShopByCatFootwearDropDown4Content').innerHTML = shopbycatfootweardropdown4contentd;

}
// dropdownemnd

//var boutiqueLoop = 10;
function fillSliderShopByFootwearCatBanners(footwearbannersLoop){
    
    var shopbycatfootwearbannerscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footwearbannersLoop ; a++){
            shopbycatfootwearbannerscontentd += '<img src="img/shopingportion/fotwear/banners/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByFootwearCatBannersContent').innerHTML = shopbycatfootwearbannerscontentd;

}

//var boutiqueLoop = 10;
function fillSliderShopByFootwearBrandsWeAdore(footwearbrandsweadoreLoop){
    
    var shopbycatfootwearfootwearbrandsweadorecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < footwearbrandsweadoreLoop ; a++){
            shopbycatfootwearfootwearbrandsweadorecontentd += '<img src="img/shopingportion/fotwear/banners2/img2.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByFootwearBrandsWeAdoreContent').innerHTML = shopbycatfootwearfootwearbrandsweadorecontentd;

}

// slider
function fillFootwearSliderLoop(footwearslidertestloop){
    
    var footwearslider = "";
    for(var a = 1; a <= footwearslidertestloop ; a++){
        footwearslider += '<div class="carousel-item">';
        footwearslider += '<img src="img/shopingportion/fotwear/sliderimg'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        footwearslider += '</div>';                 
    }

    document.getElementById('fillFootwearSliderLoopContent').innerHTML = footwearslider;
}
// sliderend