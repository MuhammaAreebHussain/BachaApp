// dropdowns

//var testLoop = 10;
function fillSliderShopByCatBabyGirlFashionDropDown(testLoop){
    
    var shopbycatbabygirlfashiondropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < testLoop ; a++){
            shopbycatbabygirlfashiondropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Summer Collection upto 40% off'+ a +'</p>';
    }

    document.getElementById('fillSliderShopByCatBabyGirlFashionDropDownContent').innerHTML = shopbycatbabygirlfashiondropdowncontentd;

}

// babyboycloths

//var babyboyclothsLoop = 10;
function fillSliderShopByCatBabyGirlClothsDropDownTill6Months(babygirlclothstill6monthsLoop){
    
    var shopbycatbabygirlclothsdropdowntill6monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirlclothstill6monthsLoop ; a++){
            shopbycatbabygirlclothsdropdowntill6monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBabyGirlClothsDropDownTill6MonthsContent').innerHTML = shopbycatbabygirlclothsdropdowntill6monthscontentd;
}
// function fillSliderShopByCatBabyGirlClothsDropDownTill9Months(babygirlclothstill9monthsLoop){
    
//     var shopbycatbabygirlclothsdropdowntill9monthscontentd = "";
//  $.each(testLoop, function(index,value){
//         for(var a = 0; a < babygirlclothstill9monthsLoop ; a++){
//             shopbycatbabygirlclothsdropdowntill9monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
//     }
//     document.getElementById('fillSliderShopByCatBabyGirlClothsDropDownTill9MonthsContent').innerHTML = shopbycatbabygirlclothsdropdowntill9monthscontentd;
// }
function fillSliderShopByCatBabyGirlClothsDropDownTill12Months(babygirlclothstill12monthsLoop){
    
    var shopbycatbabygirlclothsdropdowntill12monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirlclothstill12monthsLoop ; a++){
            shopbycatbabygirlclothsdropdowntill12monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBabyGirlClothsDropDownTill12MonthsContent').innerHTML = shopbycatbabygirlclothsdropdowntill12monthscontentd;
}
function fillSliderShopByCatBabyGirlClothsDropDownTill15Months(babygirlclothstill15monthsLoop){
    
    var shopbycatbabygirlclothsdropdowntill15monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirlclothstill15monthsLoop ; a++){
            shopbycatbabygirlclothsdropdowntill15monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBabyGirlClothsDropDownTill15MonthsContent').innerHTML = shopbycatbabygirlclothsdropdowntill15monthscontentd;
}
function fillSliderShopByCatBabyGirlClothsDropDownTill18Months(babygirlclothstill18monthsLoop){
    
    var shopbycatbabygirlclothsdropdowntill18monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirlclothstill18monthsLoop ; a++){
            shopbycatbabygirlclothsdropdowntill18monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatBabyGirlClothsDropDownTill18MonthsContent').innerHTML = shopbycatbabygirlclothsdropdowntill18monthscontentd;
}

// babyboyclothsend

// footwear

//var footwearLoop = 10;
function fillSliderShopByCatBabyGirlFashionFootwearDropDownShopByCat(babygirlfootwearLoopCat){
    
    var shopbycatbabygirlfootweardropdowncatcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirlfootwearLoopCat ; a++){
            shopbycatbabygirlfootweardropdowncatcontentd += '<p href="#" style="color: black; margin-left: 2%;">Casual Shoes</p>';
    }
    document.getElementById('fillSliderShopByCatBabyGirlFashionFootwearDropDownContentCat').innerHTML = shopbycatbabygirlfootweardropdowncatcontentd;
}
//var footwearLoop = 10;
function fillSliderShopByCatBabyGirlFashionFootwearDropDownShopByAge(babygirlfootwearLoopAge){
    
    var shopbycatbabygirlfootweardropdownagecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirlfootwearLoopAge ; a++){
            shopbycatbabygirlfootweardropdownagecontentd += '<p href="#" style="color: black; margin-left: 2%;">0-3 Months</p>';
    }
    document.getElementById('fillSliderShopByCatFootwearDropDownContentAge').innerHTML = shopbycatbabygirlfootweardropdownagecontentd;
}
//var footwearLoop = 10;
function fillSliderShopByCatBabyGirlFashionFootwearDropDownShopBySpecialOffer(babygirlfootwearLoopOffer){
    
    var shopbycatbabygirlfootweardropdownoffercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirlfootwearLoopOffer ; a++){
            shopbycatbabygirlfootweardropdownoffercontentd += '<p href="#" style="color: black; margin-left: 2%;">Upto 30% off</p>';
    }
    document.getElementById('fillSliderShopByCatBabyGirlFashionFootwearDropDownContentOffer').innerHTML = shopbycatbabygirlfootweardropdownoffercontentd;
}
// footwearend

// popularbrands
//var popularbrandsLoop = 10;
function fillSliderShopByCatBabyGirlFashionPopularBrandsDropDown(babygirlpopularbrandsLoop){
    
    var shopbycatbabygirlpopularbrandsdropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirlpopularbrandsLoop ; a++){
            shopbycatbabygirlpopularbrandsdropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Carters</p>';
    }

    document.getElementById('fillSliderShopByCatBabyGirlFashionPopularBrandsDropDownContent').innerHTML = shopbycatbabygirlpopularbrandsdropdowncontentd;

}
// popularbrandsend
// dropdownsend

// images

//var boutiqueLoop = 10;
function fillSliderShopByCatBabyGirlFashionBoutique(babygirlboutiqueLoop){
    
    var shopbycatbabygirlboutiquecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirlboutiqueLoop ; a++){
            shopbycatbabygirlboutiquecontentd += '<img src="img/shopingportion/babyboyfashion/boutiques/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatBabyGirlFashionBoutiqueContent').innerHTML = shopbycatbabygirlboutiquecontentd;

}

//var carterLoop = 10;
function fillSliderShopByCatBabyGirlFashionCarter(babygirlcarterLoop){
    
    var shopbycatbabygirlcartercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirlcarterLoop ; a++){
            shopbycatbabygirlcartercontentd += '<img src="img/home/carters/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatBabyGirlFashionCarterContent').innerHTML = shopbycatbabygirlcartercontentd;

}

//var summerLoop = 10;
function fillSliderShopByCatBabyGirlFashionSummer(babygirlsummerLoop){
    
    var shopbycatbabygirlsummercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirlsummerLoop ; a++){
            shopbycatbabygirlsummercontentd += '<img src="img/home/summerarivial/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatBabyGirlFashionSummerContent').innerHTML = shopbycatbabygirlsummercontentd;

}

//var swimwearLoop = 10;
function fillSliderShopByCatBabyGirlFashionSwimwear(babygirlswimwearLoop){
    
    var shopbycatbabygirlswimwearcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirlswimwearLoop ; a++){
            shopbycatbabygirlswimwearcontentd += '<img src="img/shopingportion/babyboyfashion/swiminhbrands/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatBabyGirlFashionSwimwearContent').innerHTML = shopbycatbabygirlswimwearcontentd;

}

//var acesummerlookLoop = 10;
function fillSliderShopByCatBabyGirlFashionDayNight(babygirldaynightLoop){
    
    var shopbycatbabygirldaydaynightcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirldaynightLoop ; a++){
            shopbycatbabygirldaydaynightcontentd += '<img src="img/shopingportion/babyboyfashion/acesummerlook/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatBabyGirlFashionDayNightContent').innerHTML = shopbycatbabygirldaydaynightcontentd;

}

//var acesummerlookLoop = 10;
function fillSliderShopByCatBabyGirlFashionAceSummerLook(babygirlacesummerlookLoop){
    
    var shopbycatbabygirldayacesummerlookcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirlacesummerlookLoop ; a++){
            shopbycatbabygirldayacesummerlookcontentd += '<img src="img/shopingportion/babyboyfashion/acesummerlook/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatBabyGirlFashionAceSummerLookContent').innerHTML = shopbycatbabygirldayacesummerlookcontentd;

}

//var brandsweloveLoop = 10;
function fillSliderShopByCatBabyGirlFashionBrandsWeLove(babygirlbrandsweloveLoop){
    
    var shopbycatbabygirlbrandswelovecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < babygirlbrandsweloveLoop ; a++){
            shopbycatbabygirlbrandswelovecontentd += '<img src="img/home/brandimages/img3.jpg" style="width: 100%; margin-top:5%;">';
            shopbycatbabygirlbrandswelovecontentd += '<p style="font-weight: bold; font-size: 20px; text-align: center; text-decoration: underline;">Shop Now</p>';
    }

    document.getElementById('fillSliderShopByCatBabyGirlFashionBrandsWeLoveContent').innerHTML = shopbycatbabygirlbrandswelovecontentd;

}

// imagesend

// slider
function fillBabyGirlSliderLoop(babygirlslidertestloop){
    
    var babygirlslider = "";
    for(var a = 1; a <= babygirlslidertestloop ; a++){
        babygirlslider += '<div class="carousel-item">';
        babygirlslider += '<img src="img/shopingportion/babyboyfashion/sliderimages/img'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        babygirlslider += '</div>';                 
    }

    document.getElementById('fillBabyGirlSliderLoopContent').innerHTML = babygirlslider;
}
// sliderend