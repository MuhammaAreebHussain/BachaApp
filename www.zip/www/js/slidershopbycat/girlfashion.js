// dropdowns



// boyfashiob
//var testLoop = 10;
function fillSliderShopByCatGirlFashionDropDown(girltestLoop){
    
    var shopbycatgirlfashiondropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girltestLoop ; a++){
            shopbycatgirlfashiondropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Summer Collection upto 40% off'+ a +'</p>';
    }

    document.getElementById('fillSliderShopByCatGirlFashionDropDownContent').innerHTML = shopbycatgirlfashiondropdowncontentd;

}

// babyboycloths

//var babyboyclothsLoop = 10;
function fillSliderShopByCatGirlClothsDropDownTill6Months(girlclothstill6monthsLoop){
    
    var shopbycatgirlclothsdropdowntill6monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlclothstill6monthsLoop ; a++){
            shopbycatgirlclothsdropdowntill6monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatGirlClothsDropDownTill6MonthsContent').innerHTML = shopbycatgirlclothsdropdowntill6monthscontentd;
}
function fillSliderShopByCatGirlClothsDropDownTill9Months(girlclothstill9monthsLoop){
    
    var shopbycatgirlclothsdropdowntill9monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlclothstill9monthsLoop ; a++){
            shopbycatgirlclothsdropdowntill9monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatGirlClothsDropDownTill9MonthsContent').innerHTML = shopbycatgirlclothsdropdowntill9monthscontentd;
}
function fillSliderShopByCatGirlClothsDropDownTill12Months(girlclothstill12monthsLoop){
    
    var shopbycatgirlclothsdropdowntill12monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlclothstill12monthsLoop ; a++){
            shopbycatgirlclothsdropdowntill12monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatGirlClothsDropDownTill12MonthsContent').innerHTML = shopbycatgirlclothsdropdowntill12monthscontentd;
}
function fillSliderShopByCatGirlClothsDropDownTill15Months(girlclothstill15monthsLoop){
    
    var shopbycatgirlclothsdropdowntill15monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlclothstill15monthsLoop ; a++){
            shopbycatgirlclothsdropdowntill15monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatGirlClothsDropDownTill15MonthsContent').innerHTML = shopbycatgirlclothsdropdowntill15monthscontentd;
}
function fillSliderShopByCatGirlClothsDropDownTill18Months(girlclothstill18monthsLoop){
    
    var shopbycatgirlclothsdropdowntill18monthscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlclothstill18monthsLoop ; a++){
            shopbycatgirlclothsdropdowntill18monthscontentd += '<p href="#" style="color: black; margin-left: 2%;">Bathwear</p>';
    }
    document.getElementById('fillSliderShopByCatGirlClothsDropDownTill18MonthsContent').innerHTML = shopbycatgirlclothsdropdowntill18monthscontentd;
}

// babyboyclothsend

// footwear

//var footwearLoop = 10;
function fillSliderShopByCatGirlFootwearDropDownShopByCat(girlfootwearLoopCat){
    
    var shopbycatgirlfootweardropdowncatcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlfootwearLoopCat ; a++){
            shopbycatgirlfootweardropdowncatcontentd += '<p href="#" style="color: black; margin-left: 2%;">Casual Shoes</p>';
    }
    document.getElementById('fillSliderShopByCatGirlFootwearDropDownContentCat').innerHTML = shopbycatgirlfootweardropdowncatcontentd;
}
//var footwearLoop = 10;
function fillSliderShopByCatGirlFootwearDropDownShopByAge(girlfootwearLoopAge){
    
    var shopbycatgirlfootweardropdownagecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlfootwearLoopAge ; a++){
            shopbycatgirlfootweardropdownagecontentd += '<p href="#" style="color: black; margin-left: 2%;">0-3 Months</p>';
    }
    document.getElementById('fillSliderShopByCatGirlFootwearDropDownContentAge').innerHTML = shopbycatgirlfootweardropdownagecontentd;
}
//var footwearLoop = 10;
function fillSliderShopByCatGirlFootwearDropDownShopBySpecialOffer(girlfootwearLoopOffer){
    
    var shopbycatgirlfootweardropdownoffercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlfootwearLoopOffer ; a++){
            shopbycatgirlfootweardropdownoffercontentd += '<p href="#" style="color: black; margin-left: 2%;">Upto 30% off</p>';
    }
    document.getElementById('fillSliderShopByCatGirlFootwearDropDownContentOffer').innerHTML = shopbycatgirlfootweardropdownoffercontentd;
}
// footwearend

// fashionassec
//var fashionassecoriesLoop = 10;
function fillSliderShopByCatGirlFashionAssecoriesDropDown(girlfashionassecoriesLoop){
    
    var shopbycatgirlfashionassecoriesdropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlfashionassecoriesLoop ; a++){
            shopbycatgirlfashionassecoriesdropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Sun Glasses</p>';
    }

    document.getElementById('fillSliderShopByCatGirlFashionAssecoriesDropDownContent').innerHTML = shopbycatgirlfashionassecoriesdropdowncontentd;

}
// fashionsend

// popularbrands
//var popularbrandsLoop = 10;
function fillSliderShopByCatGirlPopularBrandsDropDown(girlpopularbrandsLoop){
    
    var shopbycatgirlpopularbrandsdropdowncontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlpopularbrandsLoop ; a++){
            shopbycatgirlpopularbrandsdropdowncontentd += '<p href="#" style="color: black; margin-left: 2%;">Carters</p>';
    }

    document.getElementById('fillSliderShopByCatGirlPopularBrandsDropDownContent').innerHTML = shopbycatgirlpopularbrandsdropdowncontentd;

}
// popularbrandsend
// botfashionend

// dropdownsend

// images

//var boutiqueLoop = 10;
function fillSliderShopByCatGirlFashionBoutique(girlfashionboutiqueLoop){
    
    var shopbycatgirlfashionboutiquecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlfashionboutiqueLoop ; a++){
            shopbycatgirlfashionboutiquecontentd += '<img src="img/shopingportion/babyboyfashion/boutiques/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatGirlFashionBoutiqueContent').innerHTML = shopbycatgirlfashionboutiquecontentd;

}

//var carterLoop = 10;
function fillSliderShopByGirlFashionCatCarter(girlfashioncarterLoop){
    
    var shopbycatgirlfashioncartercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlfashioncarterLoop ; a++){
            shopbycatgirlfashioncartercontentd += '<img src="img/home/carters/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByCatGirlFashionCarterContent').innerHTML = shopbycatgirlfashioncartercontentd;

}

//var summerLoop = 10;
function fillSliderShopByGirlFashionCatSummer(girlfashionsummerLoop){
    
    var shopbygirlfashioncatsummercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlfashionsummerLoop ; a++){
            shopbygirlfashioncatsummercontentd += '<img src="img/home/summerarivial/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByGirlFashionCatSummerContent').innerHTML = shopbygirlfashioncatsummercontentd;

}

//var swimwearLoop = 10;
function fillSliderShopByGirlFashionCatSwimwear(girlfashionswimwearLoop){
    
    var shopbygirlfashioncatswimwearcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlfashionswimwearLoop ; a++){
            shopbygirlfashioncatswimwearcontentd += '<img src="img/shopingportion/babyboyfashion/swiminhbrands/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByGirlFashionCatSwimwearContent').innerHTML = shopbygirlfashioncatswimwearcontentd;

}

//var acesummerlookLoop = 10;
function fillSliderShopByGirlFashionCatDayNight(girlfashiondaynightLoop){
    
    var shopbygirlfashioncatdaydaynightcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlfashiondaynightLoop ; a++){
            shopbygirlfashioncatdaydaynightcontentd += '<img src="img/home/nightwear/img2.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByGirlFashionCatDayNightContent').innerHTML = shopbygirlfashioncatdaydaynightcontentd;

}

//var acesummerlookLoop = 10;
function fillSliderShopByGirlFashionCatAceSummerLook(girlfashionacesummerlookLoop){
    
    var shopbygirlfashioncatdayacesummerlookcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlfashionacesummerlookLoop ; a++){
            shopbygirlfashioncatdayacesummerlookcontentd += '<img src="img/shopingportion/babyboyfashion/acesummerlook/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillSliderShopByGirlFashionCatAceSummerLookContent').innerHTML = shopbygirlfashioncatdayacesummerlookcontentd;

}

//var brandsweloveLoop = 10;
function fillSliderShopByGirlFashionCatBrandsWeLove(girlfashionbrandsweloveLoop){
    
    var shopbygirlfashioncatbrandswelovecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < girlfashionbrandsweloveLoop ; a++){
            shopbygirlfashioncatbrandswelovecontentd += '<img src="img/home/brandimages/img3.jpg" style="width: 100%; margin-top:5%;">';
            shopbygirlfashioncatbrandswelovecontentd += '<p style="font-weight: bold; font-size: 20px; text-align: center; text-decoration: underline;">Shop Now</p>';
    }

    document.getElementById('fillSliderShopByGirlFashionCatBrandsWeLoveContent').innerHTML = shopbygirlfashioncatbrandswelovecontentd;

}

// imagesend

// slider
function fillGirlSliderLoop(girlslidertestloop){
    
    var girlslider = "";
    for(var a = 1; a <= girlslidertestloop ; a++){
        girlslider += '<div class="carousel-item">';
        girlslider += '<img src="img/shopingportion/babyboyfashion/sliderimages/img'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        girlslider += '</div>';                 
    }

    document.getElementById('fillGirlSliderLoopContent').innerHTML = girlslider;
}
// sliderend