function emptydiv(){
    document.getElementById('header').style.display="none";
    document.getElementById('footer').style.display="none";
    document.getElementById('mainhomepagediv').style.display="none";
    document.getElementById('mainloginpagediv').style.display="none";
    document.getElementById('mainregisterpagediv').style.display="none";
    document.getElementById('mainregister2pagediv').style.display="none";
     document.getElementById('mainnotificationpagediv').style.display="none";
    document.getElementById('mainsearchpagediv').style.display="none";
    document.getElementById('mainshortlistpagediv').style.display="none";
    
    document.getElementById('mainbrandspagediv').style.display="none";
    document.getElementById('mainofferpagediv').style.display="none";
    document.getElementById('mainshopingcartpagediv').style.display="none";
    document.getElementById('mainpolicypagediv').style.display="none";
    document.getElementById('mainpaymentpolicypagediv').style.display="none";
    document.getElementById('maintermspolicypagediv').style.display="none";
    document.getElementById('mainprivacypolicypagediv').style.display="none";
    document.getElementById('maincancellationpolicypagediv').style.display="none";
    document.getElementById('mainshipingpolicypagediv').style.display="none";
    document.getElementById('mainreturnpolicypagediv').style.display="none";
    document.getElementById('mainvaroompolicypagediv').style.display="none";
    document.getElementById('maingiftpagediv').style.display="none";
    document.getElementById('mainrecentlyviewedpagediv').style.display="none";
    document.getElementById('mainproductpagediv').style.display="none";
    document.getElementById('mainproductdetailpagediv').style.display="none";
    document.getElementById('mainproductdetailpart1pagediv').style.display="none"; 
    // slidershopbycategory
    document.getElementById('mainbabyboyfashionpagediv').style.display="none";
    document.getElementById('mainboyfashionpagediv').style.display="none";
    document.getElementById('mainbabygirlfashionpagediv').style.display="none";
    document.getElementById('maingirlfashionpagediv').style.display="none";
    document.getElementById('mainfootwearpagediv').style.display="none";
    document.getElementById('mainoutdoorpagediv').style.display="none";
    document.getElementById('maincharactershoppagediv').style.display="none";
    document.getElementById('mainbooksschoolpagediv').style.display="none";
    document.getElementById('maindiaperingpagediv').style.display="none";
    document.getElementById('mainfeedingandnursingoagediv').style.display="none";
    document.getElementById('mainbathskincarepagediv').style.display="none";
    document.getElementById('mainnurserypagediv').style.display="none";
    document.getElementById('moms').style.display="none";
    document.getElementById('health').style.display="none";
    document.getElementById('party').style.display="none";
    
}





function Parentingemptydiv(){
    document.getElementById('parentingheader').style.display="none";
    document.getElementById('parentingfooter').style.display="none";
    document.getElementById('mainparentinghomepagediv').style.display="none";
    document.getElementById('mainperiodcalculatorpagediv').style.display="none";
    // readcat
    // gettingpregpage   
    document.getElementById('maingettingpregnantpagediv').style.display="none";
    document.getElementById('maingettingpre1pagediv').style.display="none";
    document.getElementById('maingettingpre2pagediv').style.display="none";
    document.getElementById('maingettingpre3pagediv').style.display="none";
    document.getElementById('maingettingpre4pagediv').style.display="none";
        // pregnancypage   
        document.getElementById('mainpregnancypagediv').style.display="none";
        document.getElementById('mainpregnancy1pagediv').style.display="none";
        document.getElementById('mainpregnancy2pagediv').style.display="none";
        document.getElementById('mainpregnancy3pagediv').style.display="none";
        document.getElementById('mainpregnancy4pagediv').style.display="none";
        document.getElementById('mainpregnancy5pagediv').style.display="none";
        document.getElementById('mainpregnancy6pagediv').style.display="none";
        document.getElementById('mainpregnancy7pagediv').style.display="none";

        // babypage   
        document.getElementById('mainbabypagediv').style.display="none";
        document.getElementById('mainbaby1pagediv').style.display="none";
        document.getElementById('mainbaby2pagediv').style.display="none";
        document.getElementById('mainbaby3pagediv').style.display="none";
        document.getElementById('mainbaby4pagediv').style.display="none";
        document.getElementById('mainbaby5pagediv').style.display="none";
        document.getElementById('mainbaby6pagediv').style.display="none";
        document.getElementById('mainbaby7pagediv').style.display="none";
        document.getElementById('mainbaby8pagediv').style.display="none";
        // toddlerpage   
        document.getElementById('maintoddlerpagediv').style.display="none";
        document.getElementById('maintoddler2pagediv').style.display="none";
        document.getElementById('maintoddler3pagediv').style.display="none";
        document.getElementById('maintoddler4pagediv').style.display="none";
        document.getElementById('maintoddler5pagediv').style.display="none";
        // preschoolerpage   
        document.getElementById('mainpreschoolerpagediv').style.display="none";
        // bigkidpage   
        document.getElementById('mainbigkidpagediv').style.display="none";
        // magazinepage   
        document.getElementById('mainmagazinepagediv').style.display="none";

// PAREnting Tool Car
document.getElementById('maindietplanpagediv').style.display="none";
document.getElementById('mainbreastfeedingpagediv').style.display="none";
document.getElementById('mainbabygrowthpagediv').style.display="none";
document.getElementById('mainfaceadaypagediv').style.display="none";
document.getElementById('mainpregnancydietplanpagediv').style.display="none";
document.getElementById('mainexploretoolpagediv').style.display="none";

// Preganancy Tool Pages
document.getElementById('mainbabykickstartpagediv').style.display="none";
document.getElementById('mainduedatecalpagediv').style.display="none";
document.getElementById('mainmybumpiepagediv').style.display="none";
document.getElementById('mainmomdietplanpagediv').style.display="none";
}





