

function checkPassword(){
    var inputpassword = document.getElementById("showpass").value;
    var inputConfirmPassword = document.getElementById("showconpass").value;
    if(inputpassword != inputConfirmPassword ){
        //document.getElementById('invalidSingupID').innerHTML = 'Please Enter the required information';
        alert("check Password");
        return false;
    }
    else{
        return true;
    }
}

function checkFields(){
    var inputEmail = document.getElementById("txtSignUpInputEmail").value;
    var inputUserName = document.getElementById("txtSignUpUserName").value;
    var inputphoneNumber = document.getElementById("txtSignUpPhoneNumber").value;
    if (inputEmail == "" || inputUserName == "" || inputphoneNumber == "") {
        //document.getElementById('invalidSingupID').innerHTML = 'Please Enter the required information';
        alert("check fields");
        return false;
    }
    else{
        return true;
    }
}

    function checkNumber(){
    var inputEmail = document.getElementById("txtSignUpInputEmail").value;
    var inputphoneNumber = document.getElementById("txtSignUpPhoneNumber").value;
    var inputphoneNumber = document.getElementById("txtSignUpPhoneNumber").value;
        if (inputphoneNumber.length != 11) {
        //document.getElementById('invalidSingupID').innerHTML = 'Phone Number Incorrect';
        alert("check Number");
        return false;
    }
    else{
        document.getElementById("emailIDTextSignUp").innerHTML = inputEmail;
        document.getElementById("passTextSignUp").innerHTML = inputphoneNumber;
        document.getElementById('mainregister2pagediv').style.display="block"
        return true;
    }
}

function saveForm() { 
checkPassword();
var inputEmail = document.getElementById("txtSignUpInputEmail").value;
var inputUserName = document.getElementById("txtSignUpUserName").value;
var inputphoneNumber = document.getElementById("txtSignUpPhoneNumber").value;
var inputpassword = document.getElementById("showpass").value;
var inputConfirmPassword = document.getElementById("showconpass").value;
debugger;
var formData = {
email: inputEmail,
username: inputUserName,
first_name:"first21",
last_name:"last21",
password: inputpassword,
confirm_password:inputConfirmPassword,
gender:"F",
date_of_birth_day: 2,
date_of_birth_month: 3,
date_of_birth_year: 2000,
phone: inputphoneNumber,
subscribed_to_newsletter:true
};

    //var TokenTest = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYmYiOjE2MDM5MDcxMDEsImV4cCI6MTkxOTI2NzEwMSwiaXNzIjoiaHR0cDovL25hc2gucGs6ODkwIiwiYXVkIjpbImh0dHA6Ly9uYXNoLnBrOjg5MC9yZXNvdXJjZXMiLCJub3BfYXBpIl0sImNsaWVudF9pZCI6IjUyYjcxMmQ2LTc4NTgtNGQ1Yy04OTBiLTkwYzZhM2U3MzY0ZSIsInN1YiI6IjUyYjcxMmQ2LTc4NTgtNGQ1Yy04OTBiLTkwYzZhM2U3MzY0ZSIsImF1dGhfdGltZSI6MTYwMzkwNzA5OSwiaWRwIjoibG9jYWwiLCJzY29wZSI6WyJub3BfYXBpIiwib2ZmbGluZV9hY2Nlc3MiXSwiYW1yIjpbInB3ZCJdfQ.gRy9jW2MOvMBplzSLOoKPyYm-IZkDUd8MuuBYqUh7YJG6-64q5AOxrCi6lcrm_W5hxjU00_OeeOTTlIkfPvhqkwT1vRp7wn4CQQjTqFgkL17VXESnZjsxSkT3AyUim6f4ahn1IR8XxrgQF1cK7NHLAeXQnfJWdM6LwK_n5fuVLtorXov5ncT-2zFCbsj52-4ZvIS6EU1h8V7EkHydb53F2Cyu6bFa3QMzxW5ydBdb5HYXFS7bi_i-7vuDmSYcdSK5pYNjFMBRtd9l0aKxypzhmSRoa-bO2a2SYjc--AyMnpi3VXEQ1QKCcA9tjHSyvbDQbRGw2AThQUgSXLGK-ReOw";
    $.ajax({
        url: 'https://localhost:44349/Category',
        type: 'GET',
        //headers: { 'Authorization ': TokenTest },
        dataType: 'json',
        data: formData,
        success: function (data) {
           debugger;
           alert("success");
        },
        error: function (request, message, error) {
            debugger;
            alert("error");
            
        }
    });
}
