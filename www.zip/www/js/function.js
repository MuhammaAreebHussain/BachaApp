
 //  homefunctions
function gotoHome(){
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('header').style.display="block";
     document.getElementById('footer').style.display="block";
     document.getElementById('mainhomepagediv').style.display="block"
     var  abc = 10;
     fillHomePageShopByCat(abc);

}
//    homefunctionsend

 //  loginfunction
 function gotoLoginForm(){
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('mainloginpagediv').style.display="block"
 }
 // loginfunctionend

 //  registerfunction
     function gotoRegisterForm(){    
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('mainregisterpagediv').style.display="block"
 }
 // registerfunctionend

// register2function
 function gotoReg2(){
    emptydiv();
    clickanywhere();
    checkFields();
    checkNumber();
    Parentingemptydiv();
}

 // register2functionend

 // notificationpagefunction
  function gotoNotification(){
       emptydiv();
       clickanywhere();
       Parentingemptydiv();
       document.getElementById('header').style.display="block";
       document.getElementById('footer').style.display="block";
       document.getElementById('mainnotificationpagediv').style.display="block";
   }
 // notificationpagefunctionend

 // searchpagefunction
 function gotoSearch(){
     emptydiv();
     Parentingemptydiv();
     document.getElementById('footer').style.display="block";
     document.getElementById('mainsearchpagediv').style.display="block"
 }
 function gotoHomrFromSearch(){
     emptydiv();
     Parentingemptydiv();
     document.getElementById('header').style.display="block";
     document.getElementById('footer').style.display="block";
     document.getElementById('mainhomepagediv').style.display="block"
 }
 // searchpagefunctionend

 // brandsfunctionfunction
 function gotoBrands(){
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('header').style.display="block";
     document.getElementById('footer').style.display="block";
     document.getElementById('mainbrandspagediv').style.display="block"
 }
 // brandsfunctionfunction

 // offerpagefuncruion
 function gotoOffer(){
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('header').style.display="block";
     document.getElementById('footer').style.display="block";
     document.getElementById('mainofferpagediv').style.display="block";
 }
 // offerpagefuncruionend
  
 // shopcartfunction
 function gotoShopingCart(){
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('header').style.display="block";
     document.getElementById('footer').style.display="block";
     document.getElementById('mainshopingcartpagediv').style.display="block";
 }
 // shopcartfunctionend


 //  cartfunction
 function openCart(cartName) {
     var i;
     var x = document.getElementsByClassName("cart");
     for (i = 0; i < x.length; i++) {
         x[i].style.display = "none";  
     }
     document.getElementById(cartName).style.display = "block";  
     }

 // cartfunctionend

 // policyfunction
 function gotoPolicy(){
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('header').style.display="block";
     document.getElementById('footer').style.display="block";
     document.getElementById('mainpolicypagediv').style.display="block";
 }

 function gotoPayment(){
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('header').style.display="block";
     document.getElementById('footer').style.display="block";
     document.getElementById('mainpaymentpolicypagediv').style.display="block";
 }

 function gotoTerms(){
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('header').style.display="block";
     document.getElementById('footer').style.display="block";
     document.getElementById('maintermspolicypagediv').style.display="block";
 }
 function gotoPrivacy(){
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('header').style.display="block";
     document.getElementById('footer').style.display="block";
     document.getElementById('mainprivacypolicypagediv').style.display="block";
 }
 function gotoCancellation(){
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('header').style.display="block";
     document.getElementById('footer').style.display="block";
     document.getElementById('maincancellationpolicypagediv').style.display="block";
 }
 function gotoShiping(){
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('header').style.display="block";
     document.getElementById('footer').style.display="block";
     document.getElementById('mainshipingpolicypagediv').style.display="block";
 }
 function gotoReturn(){
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('header').style.display="block";
     document.getElementById('footer').style.display="block";
     document.getElementById('mainreturnpolicypagediv').style.display="block";
 }
 function gotoVaroom(){
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('header').style.display="block";
     document.getElementById('footer').style.display="block";
     document.getElementById('mainvaroompolicypagediv').style.display="block";
 }

 // policyfunctionend

 // giftpagefunction
 function gotoGift(){
     emptydiv();
     clickanywhere();
     Parentingemptydiv();
     document.getElementById('header').style.display="block";
     document.getElementById('footer').style.display="block";
     document.getElementById('maingiftpagediv').style.display="block";
 }
 // giftpagefunctionend

 
 // shortlistpagefunction
 function gotoShortList(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('mainshortlistpagediv').style.display="block";
    // var arr = [ 1, 2, 3, 4, 5 ];
    // var abc = arr.length;
    var  abc = 10;
    fillShortList(abc);
}
// shortlistpagefunctionend

 // recentlyviewedpagefunction
 function gotoRecentView(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('mainrecentlyviewedpagediv').style.display="block";
    var  abc = 10;
    fillRecentlyViewed(abc);
}
// recentlyviewedpagefunctionend

 // recentlyviewedpagefunction
 function gotoProduct(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('mainproductpagediv').style.display="block";
    var  abc = 10;
    fillProduct(abc);
}
function openProductGenderModal(){

    document.getElementById("productgenderModal").style.display = "block";
}
function closeProductGenderModal(){

    document.getElementById("productgenderModal").style.display = "none";
}

function openProductAgeModal(){

    document.getElementById("productageModal").style.display = "block";
}
function closeProductAgeModal(){

    document.getElementById("productageModal").style.display = "none";
}

function openProductSortModal(){

    document.getElementById("productsortModal").style.display = "block";
}
function closeProductSortModal(){

    document.getElementById("productsortModal").style.display = "none";
}
// productpagefunctionend

 // recentlyviewedpagefunction
 function gotoProductDetail(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('mainproductdetailpagediv').style.display="block";
    var  productdetail = 10;
    fillProductDetail(productdetail);
 }

    function openProductDetaiModal(){

        document.getElementById("myProductDetailModal").style.display = "block";
    }
    function closeProductDetailModal(){
    
        document.getElementById("myProductDetailModal").style.display = "none";
    }


// productpagefunctionend

 // prjectdetailpagefunction

// prjectdetailpagefunctionend


// slidershopbycatfrunctions
function gotoBabyBoyFashion(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('mainbabyboyfashionpagediv').style.display="block";
    var  abc = 10;
    fillSliderShopByCatBabyBoyFashionDropDown(abc);
    var  tillsix = 5;
    fillSliderShopByCatBabyBoyClothsDropDownTill6Months(tillsix);
    var  tillnine = 5;
    fillSliderShopByCatBabyBoyClothsDropDownTill9Months(tillnine);
    var  tilltwelve = 5;
    fillSliderShopByCatBabyBoyClothsDropDownTill12Months(tilltwelve);
    var  tillfifteen = 5;
    fillSliderShopByCatBabyBoyClothsDropDownTill15Months(tillfifteen);
    var  tilleighteen = 5;
    fillSliderShopByCatBabyBoyClothsDropDownTill18Months(tilleighteen);
    // footwear
    var  cat = 5;
    fillSliderShopByCatFootwearDropDownShopByCat(cat);
    var  age = 5;
    fillSliderShopByCatFootwearDropDownShopByAge(age);
    var  offer = 5;
    fillSliderShopByCatFootwearDropDownShopBySpecialOffer(offer);
    // brands
    var  brands = 5;
    fillSliderShopByCatPopularBrandsDropDown(brands);
    // images
    var  boutique = 3;
    fillSliderShopByCatBoutique(boutique);
    var  carter = 3;
    fillSliderShopByCatCarter(carter);
    var  summer = 3;
    fillSliderShopByCatSummer(summer);
    var  swimwear = 1;
    fillSliderShopByCatSwimwear(swimwear);
    var  daynight = 1;
    fillSliderShopByCatDayNight(daynight);
    var  acesummerlook = 2;
    fillSliderShopByCatAceSummerLook(acesummerlook);
    var  brandswelove = 3;
    fillSliderShopByCatBrandsWeLove(brandswelove);

    fillBabyBoySliderLoop(5);
}

function gotoBoyFashion(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('mainboyfashionpagediv').style.display="block";
    var  abc = 10;
    fillSliderShopByCatBoyFashionDropDown(abc);
    var  tillsix = 5;
    fillSliderShopByCatBoyClothsDropDownTill6Months(tillsix);
    var  tillnine = 5;
    fillSliderShopByCatBoyClothsDropDownTill9Months(tillnine);
    var  tilltwelve = 5;
    fillSliderShopByCatBoyClothsDropDownTill12Months(tilltwelve);
    var  tillfifteen = 5;
    fillSliderShopByCatBoyClothsDropDownTill15Months(tillfifteen);
    var  tilleighteen = 5;
    fillSliderShopByCatBoyClothsDropDownTill18Months(tilleighteen);
    // footwear
    var  cat = 5;
    fillSliderShopByCatFootwearDropDownShopByCat(cat);
    var  age = 5;
    fillSliderShopByCatFootwearDropDownShopByAge(age);
    var  offer = 5;
    fillSliderShopByCatFootwearDropDownShopBySpecialOffer(offer);
        // fashion
        var  fashion = 5;
        fillSliderShopByCatFashionAssecoriesDropDown(fashion);
    // brands
    var  brands = 5;
    fillSliderShopByCatPopularBrandsDropDown(brands);
    // images
    var  boyfashionboutique = 3;
    fillSliderShopByCatBoyFashionBoutique(boyfashionboutique);
    var  boyfashioncarter = 3;
    fillSliderShopByBoyFashionCatCarter(boyfashioncarter);
    var  boyfashionsummer = 3;
    fillSliderShopByBoyFashionCatSummer(boyfashionsummer);
    var  boyfashionswimwear = 1;
    fillSliderShopByBoyFashionCatSwimwear(boyfashionswimwear);
    var  boyfashiondaynight = 1;
    fillSliderShopByBoyFashionCatDayNight(boyfashiondaynight);
    var  boyfashionacesummerlook = 2;
    fillSliderShopByBoyFashionCatAceSummerLook(boyfashionacesummerlook);
    var  boyfashionbrandswelove = 3;
    fillSliderShopByBoyFashionCatBrandsWeLove(boyfashionbrandswelove);

    fillBoySliderLoop(5);
}

function gotoBabyGirlFashion(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('mainbabygirlfashionpagediv').style.display="block";
    var  babygirlabc = 10;
    fillSliderShopByCatBabyGirlFashionDropDown(babygirlabc);
    var  babygirltillsix = 5;
    fillSliderShopByCatBabyGirlClothsDropDownTill6Months(babygirltillsix);
    // var  babygirltillnine = 5;
    // fillSliderShopByCatBabyGirlClothsDropDownTill9Months(babygirltillnine);
    var  babygirltilltwelve = 5;
    fillSliderShopByCatBabyGirlClothsDropDownTill12Months(babygirltilltwelve);
    var  babygirltillfifteen = 5;
    fillSliderShopByCatBabyGirlClothsDropDownTill15Months(babygirltillfifteen);
    var  babygirltilleighteen = 5;
    fillSliderShopByCatBabyGirlClothsDropDownTill18Months(babygirltilleighteen);
    // footwear
    var  babygirlcat = 5;
    fillSliderShopByCatBabyGirlFashionFootwearDropDownShopByCat(babygirlcat);
    var  babygirlage = 5;
    fillSliderShopByCatBabyGirlFashionFootwearDropDownShopByAge(babygirlage);
    var  babygirloffer = 5;
    fillSliderShopByCatBabyGirlFashionFootwearDropDownShopBySpecialOffer(babygirloffer);
    // brands
    var  babygirlbrands = 5;
    fillSliderShopByCatBabyGirlFashionPopularBrandsDropDown(babygirlbrands);
    // images
    var  babygirlboutique = 3;
    fillSliderShopByCatBabyGirlFashionBoutique(babygirlboutique);
    var  babygirlcarter = 3;
    fillSliderShopByCatBabyGirlFashionCarter(babygirlcarter);
    var  babygirlsummer = 3;
    fillSliderShopByCatBabyGirlFashionSummer(babygirlsummer);
    var  babygirlswimwear = 1;
    fillSliderShopByCatBabyGirlFashionSwimwear(babygirlswimwear);
    var  babygirldaynight = 1;
    fillSliderShopByCatBabyGirlFashionDayNight(babygirldaynight);
    var  babygirlacesummerlook = 2;
    fillSliderShopByCatBabyGirlFashionAceSummerLook(babygirlacesummerlook);
    var  babygirlbrandswelove = 3;
    fillSliderShopByCatBabyGirlFashionBrandsWeLove(babygirlbrandswelove);

    fillBabyGirlSliderLoop(5);
}

function gotoGirlFashion(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('maingirlfashionpagediv').style.display="block";
    var  girlabc = 10;
    fillSliderShopByCatGirlFashionDropDown(girlabc);
    var  girltillsix = 5;
    fillSliderShopByCatGirlClothsDropDownTill6Months(girltillsix);
    var  girltillnine = 5;
    fillSliderShopByCatGirlClothsDropDownTill9Months(girltillnine);
    var  girltilltwelve = 5;
    fillSliderShopByCatGirlClothsDropDownTill12Months(girltilltwelve);
    var  girltillfifteen = 5;
    fillSliderShopByCatGirlClothsDropDownTill15Months(girltillfifteen);
    var  girltilleighteen = 5;
    fillSliderShopByCatGirlClothsDropDownTill18Months(girltilleighteen);
    // footwear
    var  girlcat = 5;
    fillSliderShopByCatGirlFootwearDropDownShopByCat(girlcat);
    var  girlage = 5;
    fillSliderShopByCatGirlFootwearDropDownShopByAge(girlage);
    var  girloffer = 5;
    fillSliderShopByCatGirlFootwearDropDownShopBySpecialOffer(girloffer);
        // fashion
        var  girlfashion = 5;
        fillSliderShopByCatGirlFashionAssecoriesDropDown(girlfashion);
    // brands
    var  girlbrands = 5;
    fillSliderShopByCatGirlPopularBrandsDropDown(girlbrands);
    // images
    var  girlfashionboutique = 3;
    fillSliderShopByCatGirlFashionBoutique(girlfashionboutique);
    var  girlfashioncarter = 3;
    fillSliderShopByGirlFashionCatCarter(girlfashioncarter);
    var  girlfashionsummer = 3;
    fillSliderShopByGirlFashionCatSummer(girlfashionsummer);
    var  girlfashionswimwear = 1;
    fillSliderShopByGirlFashionCatSwimwear(girlfashionswimwear);
    var  girlfashiondaynight = 1;
    fillSliderShopByGirlFashionCatDayNight(girlfashiondaynight);
    var  girlfashionacesummerlook = 2;
    fillSliderShopByGirlFashionCatAceSummerLook(girlfashionacesummerlook);
    var  girlfashionbrandswelove = 3;
    fillSliderShopByGirlFashionCatBrandsWeLove(girlfashionbrandswelove);

    fillGirlSliderLoop(5);
}

function gotoFootwear(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('mainfootwearpagediv').style.display="block";
    var  footweardropdown1 = 3;
    fillSliderShopByCatFootwearDropDown1(footweardropdown1);
    var  footweardropdown2 = 3;
    fillSliderShopByCatFootwearDropDown2(footweardropdown2);
    var  footweardropdown3 = 3;
    fillSliderShopByCatFootwearDropDown3(footweardropdown3);
    var  footweardropdown4 = 3;
    fillSliderShopByCatFootwearDropDown4(footweardropdown4);
    var  footwearbanners = 3;
    fillSliderShopByFootwearCatBanners(footwearbanners);
    var  footwearbrandsweadore = 3;
    fillSliderShopByFootwearBrandsWeAdore(footwearbrandsweadore);

    fillFootwearSliderLoop(4);
}

function gotoOutdoor(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('mainoutdoorpagediv').style.display="block";
    var  outdoordropdown1 = 5;
    fillSliderShopByCatOutdoorDropDown1(outdoordropdown1);
    var  outdoordropdown2 = 5;
    fillSliderShopByCatOutdoorDropDown2(outdoordropdown2);
    var  outdoordropdown3 = 5;
    fillSliderShopByCatOutdoorDropDown3(outdoordropdown3);
    var  outdoordropdown4 = 5;
    fillSliderShopByCatOutdoorDropDown4(outdoordropdown4);
    var  outdoordropdown5 = 5;
    fillSliderShopByCatOutdoorDropDown5(outdoordropdown5);
    var  outdoordropdown6 = 5;
    fillSliderShopByCatOutdoorDropDown6(outdoordropdown6);
    var  outdoorbtns = 5;
    fillSliderShopByCatOutdoorBtns(outdoorbtns);
    var  outdoorpoolaccessories = 5;
    fillSliderShopByOutdoorPoolAccessories(outdoorpoolaccessories);
    

    fillOutdoorSliderLoop(3);
}

function gotoCharacterShop(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('maincharactershoppagediv').style.display="block";
    var  charactershopdropdown1 = 5;
    fillSliderShopByCatCharacterShopDropDown1(charactershopdropdown1);
    var  charactershopdropdown2 = 5;
    fillSliderShopByCatCharacterShopDropDown2(charactershopdropdown2);
    var  charactershopdropdown3 = 5;
    fillSliderShopByCatCharacterShopDropDown3(charactershopdropdown3);
    var  charactershopdropdown4 = 5;
    fillSliderShopByCatCharacterShopDropDown4(charactershopdropdown4);
    var  charactershopdropdown5 = 5;
    fillSliderShopByCatCharacterShopDropDown5(charactershopdropdown5);
    var  charactershopdisneyshop = 1;
    fillSliderShopByCharacterShopDisneyShop(charactershopdisneyshop);
    var  charactershopsuperhero = 1;
    fillSliderShopByCharacterShopSuperHero(charactershopsuperhero);
    // var  charactershopprincesscharacter = 1;
    // fillSliderShopByCharacterShopPrincessCharacter(charactershopprincesscharacter);

    fillCharacterSliderLoop(4);
}

function gotoBooksSchool(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('mainbooksschoolpagediv').style.display="block";
    var  booksshopbycategory = 5;
    fillSliderShopByCatBooksDropDownShopByCategory(booksshopbycategory);
    var  schoolstationary = 5;
    fillSliderShopByCatSchoolDropDownStationary(schoolstationary);
    var  schoolwatterbottles = 5;
    fillSliderShopByCatSchoolDropDownWatterBottles(schoolwatterbottles);
    var  s = 2;
    fillSliderBooksschoolBtns(s);
    var  bookschookstudymaterail = 2;
    fillSliderShopByCatBookSchoolsStudyMaterial(bookschookstudymaterail);
    var  bookschooklunchtime = 2;
    fillSliderShopByCatBookSchoolsLunchTime(bookschooklunchtime);
    var  bookschookcolor = 2;
    fillSliderShopByCatBookSchoolsColor(bookschookcolor);


    fillBooksSliderLoop(4);
}


function gotoDiaper(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('maindiaperingpagediv').style.display="block";
    var  diapersize = 5;
    fillSliderShopByDiaperSizeDropDown(diapersize);
    var  diaperweight = 5;
    fillSliderShopByDiaperWeightDropDown(diaperweight);
    var  diaperbrands = 5;
    fillSliderShopByDiaperBrandsDropDown(diaperbrands);
    var  diapernappie = 5;
    fillSliderDiaperNappieDropDown(diapernappie);
    var  pottytraining = 5;
    fillSliderPottyTrainingDropDown(pottytraining);
    var  diaperbtn = 5;
    fillSliderDiaperBtns(diaperbtn);
    var  brandswelove = 6;
    fillSliderBrandsWeLove(brandswelove);
    var  pottytrainingimages = 6;
    fillSliderPottyTraining(pottytrainingimages);
    var  diaper = 2;
    Diaper(diaper);

    fillDiaperingSliderLoop(4);
}

function gotoFeedingNursing(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('mainfeedingandnursingoagediv').style.display="block";
    var  feednursingdropdown1 = 5;
    fillSliderFeedNursingDropDown1(feednursingdropdown1);
    var  feednursingdropdown2 = 5;
    fillSliderFeedNursingDropDown2(feednursingdropdown2);
    var  feednursingdropdown3 = 5;
    fillSliderFeedNursingDropDown3(feednursingdropdown3);
    var  feednursingdropdown4 = 5;
    fillSliderFeedNursingDropDown4(feednursingdropdown4);
    var  feednursingdropdown5 = 5;
    fillSliderFeedNursingDropDown5(feednursingdropdown5);
    var  feednursingdropdown6 = 5;
    fillSliderFeedNursingDropDown6(feednursingdropdown6);
    var  feednursingdropdown7 = 5;
    fillSliderFeedNursingDropDown7(feednursingdropdown7);
    var  feednursingdropdown8 = 5;
    fillSliderFeedNursingDropDown8(feednursingdropdown8);
    var  nursingfeedingimage1 = 2;
    fillSliderNursingFeedingImage1(nursingfeedingimage1);
    var  nursingfeedingimage2 = 2;
    fillSliderNursingFeedingImage2(nursingfeedingimage2);
    var  nursingfeedingimage3 = 2;
    fillSliderNursingFeedingImage3(nursingfeedingimage3);

    fillNursingSliderLoop(4);
}

function gotoBathSkincare(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('mainbathskincarepagediv').style.display="block";
    var  bathskindropdown1 = 5;
    fillSliderShopByCatBathSkinDropDown1(bathskindropdown1);
    var  bathskindropdown2 = 5;
    fillSliderShopByCatBathSkinDropDown2(bathskindropdown2);
    var  bathskindropdown3 = 5;
    fillSliderShopByCatBathSkinDropDown3(bathskindropdown3);
    var  bathskindropdown4 = 5;
    fillSliderShopByCatBathSkinDropDown4(bathskindropdown4);
    var  bathskindropdown5 = 5;
    fillSliderShopByCatBathSkinDropDown5(bathskindropdown5);
    var  bathskindropdown6 = 5;
    fillSliderShopByCatBathSkinDropDown6(bathskindropdown6);
    var  bathskinbtns = 3;
    fillSliderShopByCatBathSkinBtns(bathskinbtns);

    fillBathSliderLoop(4);
}

function gotoNursery(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('mainnurserypagediv').style.display="block";
    var  nursingdropdown1 = 5;
    fillSliderShopByCatNursingDropDown1(nursingdropdown1);
    var  nursingdropdown2 = 5;
    fillSliderShopByCatNursingDropDown2(nursingdropdown2);
    var  nursingdropdown3 = 5;
    fillSliderShopByCatNursingDropDown3(nursingdropdown3);
    var  nursingdropdown4 = 5;
    fillSliderShopByCatNursingDropDown4(nursingdropdown4);
    var  nursingdropdown5 = 5;
    fillSliderShopByCatNursingDropDown5(nursingdropdown5);
    var  nursingdropdown6 = 5;
    fillSliderShopByCatNursingDropDown6(nursingdropdown6);
    var  nursingdropdown7 = 5;
    fillSliderShopByCatNursingDropDown7(nursingdropdown7);
    var  nursingbtns = 3;
    fillSliderShopByCatNursingBtns(nursingbtns);
    var  nursingimages1 = 2;
    fillSliderNursingNursingImage1(nursingimages1);
    var  nursingimages2 = 2;
    fillSliderNursingNursingImage2(nursingimages2);


    fillNurserySliderLoop(4);
}

function gotoMom(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('moms').style.display="block";
    var  momsdropdown1 = 5;
    fillSliderShopByCatMomsDropDown1(momsdropdown1);
    var  momsdropdown2 = 5;
    fillSliderShopByCatMomsDropDown2(momsdropdown2);
    var  momsdropdown3 = 5;
    fillSliderShopByCatMomsDropDown3(momsdropdown3);
    var  momsdropdown4 = 5;
    fillSliderShopByCatMomsDropDown4(momsdropdown4);
    var  momsbtns = 3;
    fillSliderShopByCatMomsBtns(momsbtns);
    var  momsimages2 = 4;
    fillSliderNursingMomsImage2(momsimages2);

    fillMomSliderLoop(4);
}

function gotoHealth(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('health').style.display="block";
    var  healthdropdown1 = 5;
    fillSliderShopByCatHealthDropDown1(healthdropdown1);
    var  healthdropdown2 = 5;
    fillSliderShopByCatHealthDropDown2(healthdropdown2);
    var  healthdropdown3 = 5;
    fillSliderShopByCatHealthDropDown3(healthdropdown3);
    var  healthdropdown4 = 5;
    fillSliderShopByCatHealthDropDown4(healthdropdown4);
    var  healthdropdown5 = 5;
    fillSliderShopByCatHealthDropDown5(healthdropdown5);
    var  healthbtns = 4;
    fillSliderShopByCatHealthBtns(healthbtns);
    var  healthimages1 = 2;
    fillSliderNursingHealthImage1(healthimages1);
    

    fillHealthSliderLoop(4);
}

function gotoParty(){
    emptydiv();
    clickanywhere();
    Parentingemptydiv();
    document.getElementById('header').style.display="block";
    document.getElementById('footer').style.display="block";
    document.getElementById('party').style.display="block";
    var  partydropdown1 = 5;
    fillSliderShopByCatPartyDropDown1(partydropdown1);
    var  partydropdown2 = 5;
    fillSliderShopByCatPartyDropDown2(partydropdown3);
    var  partydropdown3 = 5;
    fillSliderShopByCatPartyDropDown3(partydropdown3);
    var  partybtns = 4;
    fillSliderShopByCatPartyBtns(partybtns);

    fillPartySliderLoop(4);

}

// slidershopbycatfrunctionsend

 // dropdowm
 var dropdown = document.getElementsByClassName("dropdown-btn");
 var i;

 for (i = 0; i < dropdown.length; i++) {
 dropdown[i].addEventListener("click", function() {
 this.classList.toggle("active");
 var dropdownContent = this.nextElementSibling;
 if (dropdownContent.style.display === "block") {
 dropdownContent.style.display = "none";
 } else {
 dropdownContent.style.display = "block";
 }
 });
 }
 // dropdowmend

// showpassfunction

 function ShowPassword() {
    var x = document.getElementById("showpass");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }

  function ShowConfirmPassword() {
    var x = document.getElementById("showconpass");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }

//   showpassfunctionend


// sidear 

var a = false;

 function openNav() {
    document.getElementById("mySidenav").style.width = "316px";
    a = true;
 }

 function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    a = false;
 }

function clickanywhere(){
     if(a === true){
    
         closeNav();
     }
}

// sidebarend


function openModal(){

        document.getElementById("myModal").style.display = "block";
}

function closeModal(){

    document.getElementById("myModal").style.display = "none";
}


// Shoping Function Ends


