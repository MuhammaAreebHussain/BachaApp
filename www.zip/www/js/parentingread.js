// slider
function fillParentingReadSliderLoop(parentingreadslidertestloop){
    
    var parentingreadslider = "";
    for(var a = 1; a <= parentingreadslidertestloop ; a++){
        parentingreadslider += '<div class="carousel-item">';
        parentingreadslider += '<img src="img/shopingportion/gifts/sliderimg'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        parentingreadslider += '</div>';                 
    }

    document.getElementById('fillParentingReadSliderLoopContent').innerHTML = parentingreadslider;
}
// sliderend


// gettingpregnantdetailpage
function fillParentingReadGettingPreCat(parentingreadgettingprecattestloop){
    
    var parentingreadgettingprecat = "";
    for(var a = 1; a <= parentingreadgettingprecattestloop ; a++){     
        parentingreadgettingprecat+= '<p style="margin-left: 5%;">Fertility Getting Pregnant</p>';
        parentingreadgettingprecat+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadgettingprecat+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadgettingprecat+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadGettingPreCatContent').innerHTML = parentingreadgettingprecat;
}

// gettingpregnant1detailpage
function fillParentingReadGettingPreCat1(parentingreadgettingprecat1testloop){
    
    var parentingreadgettingprecat1 = "";
    for(var a = 1; a <= parentingreadgettingprecat1testloop ; a++){     
        parentingreadgettingprecat1+= '<p style="margin-left: 5%;">Fertility Getting Pregnant</p>';
        parentingreadgettingprecat1+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadgettingprecat1+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadgettingprecat1+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadGettingPreCat1Content').innerHTML = parentingreadgettingprecat1;
}

// gettingpregnant2detailpage
function fillParentingReadGettingPreCat2(parentingreadgettingprecat2testloop){
    
    var parentingreadgettingprecat2 = "";
    for(var a = 1; a <= parentingreadgettingprecat2testloop ; a++){     
        parentingreadgettingprecat2+= '<p style="margin-left: 5%;">Fertility Getting Pregnant</p>';
        parentingreadgettingprecat2+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadgettingprecat2+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadgettingprecat2+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadGettingPreCat2Content').innerHTML = parentingreadgettingprecat2;
}

// gettingpregnant3detailpage
function fillParentingReadGettingPreCat3(parentingreadgettingprecat3testloop){
    
    var parentingreadgettingprecat3 = "";
    for(var a = 1; a <= parentingreadgettingprecat3testloop ; a++){     
        parentingreadgettingprecat3+= '<p style="margin-left: 5%;">Fertility Getting Pregnant</p>';
        parentingreadgettingprecat3+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadgettingprecat3+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadgettingprecat3+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadGettingPreCat3Content').innerHTML = parentingreadgettingprecat3;
}

// gettingpregnant4detailpage
function fillParentingReadGettingPreCat4(parentingreadgettingprecat4testloop){
    
    var parentingreadgettingprecat4 = "";
    for(var a = 1; a <= parentingreadgettingprecat4testloop ; a++){     
        parentingreadgettingprecat4+= '<p style="margin-left: 5%;">Fertility Getting Pregnant</p>';
        parentingreadgettingprecat4+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadgettingprecat4+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadgettingprecat4+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadGettingPreCat4Content').innerHTML = parentingreadgettingprecat4;
}

// pregnancydetailpage
function fillParentingReadPregnancyCat(parentingreadpregnancycattestloop){
    
    var parentingreadpregnancycat = "";
    for(var a = 1; a <= parentingreadpregnancycattestloop ; a++){
        parentingreadpregnancycat+= '<img src="img/parenting/getting preganant/readpregnancy/img1.jpg" width="100%">';     
        parentingreadpregnancycat+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadpregnancycat+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadpregnancycat+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadpregnancycat+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadPregnancyCatContent').innerHTML = parentingreadpregnancycat;
}

function fillParentingReadPregnancyCat1(parentingreadpregnancycat1testloop){
    
    var parentingreadpregnancycat1 = "";
    for(var a = 1; a <= parentingreadpregnancycat1testloop ; a++){
        parentingreadpregnancycat1+= '<img src="img/parenting/getting preganant/readpregnancy/img1.jpg" width="100%">';     
        parentingreadpregnancycat1+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadpregnancycat1+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadpregnancycat1+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadpregnancycat1+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadPregnancyCat1Content').innerHTML = parentingreadpregnancycat1;
}

function fillParentingReadPregnancyCat2(parentingreadpregnancycat2testloop){
    
    var parentingreadpregnancycat2 = "";
    for(var a = 1; a <= parentingreadpregnancycat2testloop ; a++){
        parentingreadpregnancycat2+= '<img src="img/parenting/getting preganant/readpregnancy/img1.jpg" width="100%">';     
        parentingreadpregnancycat2+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadpregnancycat2+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadpregnancycat2+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadpregnancycat2+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadPregnancyCat2Content').innerHTML = parentingreadpregnancycat2;
}

function fillParentingReadPregnancyCat3(parentingreadpregnancycat3testloop){
    
    var parentingreadpregnancycat3 = "";
    for(var a = 1; a <= parentingreadpregnancycat3testloop ; a++){
        parentingreadpregnancycat3+= '<img src="img/parenting/getting preganant/readpregnancy/img1.jpg" width="100%">';     
        parentingreadpregnancycat3+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadpregnancycat3+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadpregnancycat3+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadpregnancycat3+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadPregnancyCat3Content').innerHTML = parentingreadpregnancycat3;
}

function fillParentingReadPregnancyCat4(parentingreadpregnancycat4testloop){
    
    var parentingreadpregnancycat4 = "";
    for(var a = 1; a <= parentingreadpregnancycat4testloop ; a++){
        parentingreadpregnancycat4+= '<img src="img/parenting/getting preganant/readpregnancy/img1.jpg" width="100%">';     
        parentingreadpregnancycat4+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadpregnancycat4+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadpregnancycat4+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadpregnancycat4+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadPregnancyCat4Content').innerHTML = parentingreadpregnancycat4;
}

function fillParentingReadPregnancyCat5(parentingreadpregnancycat5testloop){
    
    var parentingreadpregnancycat5 = "";
    for(var a = 1; a <= parentingreadpregnancycat5testloop ; a++){
        parentingreadpregnancycat5+= '<img src="img/parenting/getting preganant/readpregnancy/img1.jpg" width="100%">';     
        parentingreadpregnancycat5+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadpregnancycat5+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadpregnancycat5+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadpregnancycat5+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadPregnancyCat5Content').innerHTML = parentingreadpregnancycat5;
}

function fillParentingReadPregnancyCat6(parentingreadpregnancycat6testloop){
    
    var parentingreadpregnancycat6 = "";
    for(var a = 1; a <= parentingreadpregnancycat6testloop ; a++){
        parentingreadpregnancycat6+= '<img src="img/parenting/getting preganant/readpregnancy/img1.jpg" width="100%">';     
        parentingreadpregnancycat6+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadpregnancycat6+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadpregnancycat6+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadpregnancycat6+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadPregnancyCat6Content').innerHTML = parentingreadpregnancycat6;
}

function fillParentingReadPregnancyCat7(parentingreadpregnancycat7testloop){
    
    var parentingreadpregnancycat7 = "";
    for(var a = 1; a <= parentingreadpregnancycat6testloop ; a++){
        parentingreadpregnancycat7+= '<img src="img/parenting/getting preganant/readpregnancy/img1.jpg" width="100%">';     
        parentingreadpregnancycat7+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadpregnancycat7+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadpregnancycat7+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadpregnancycat7+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadPregnancyCat7Content').innerHTML = parentingreadpregnancycat7;
}
// gettingpregnantdetailpageend

// Babydetailpage
function fillParentingReadBabyCat(parentingreadbabycattestloop){
    
    var parentingreadbabycat = "";
    for(var a = 1; a <= parentingreadbabycattestloop ; a++){
        parentingreadbabycat+= '<img src="img/parenting/getting preganant/readbaby/img1.jpg" width="100%">';     
        parentingreadbabycat+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadbabycat+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadbabycat+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadbabycat+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadBabyCatContent').innerHTML = parentingreadbabycat;
}

function fillParentingReadBaby1Cat(parentingreadbabycat1testloop){
    
    var parentingreadbabycat1 = "";
    for(var a = 1; a <= parentingreadbabycat1testloop ; a++){
        parentingreadbabycat1+= '<img src="img/parenting/getting preganant/readbaby/img1.jpg" width="100%">';     
        parentingreadbabycat1+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadbabycat1+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadbabycat1+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadbabycat1+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadBaby1CatContent').innerHTML = parentingreadbabycat1;
}

function fillParentingReadBaby2Cat(parentingreadbabycat2testloop){
    
    var parentingreadbabycat2 = "";
    for(var a = 1; a <= parentingreadbabycat2testloop ; a++){
        parentingreadbabycat2+= '<img src="img/parenting/getting preganant/readbaby/img1.jpg" width="100%">';     
        parentingreadbabycat2+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadbabycat2+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadbabycat2+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadbabycat2+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadBaby2CatContent').innerHTML = parentingreadbabycat2;
}

function fillParentingReadBaby3Cat(parentingreadbabycat3testloop){
    
    var parentingreadbabycat3 = "";
    for(var a = 1; a <= parentingreadbabycat3testloop ; a++){
        parentingreadbabycat3+= '<img src="img/parenting/getting preganant/readbaby/img1.jpg" width="100%">';     
        parentingreadbabycat3+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadbabycat3+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadbabycat3+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadbabycat3+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadBaby3CatContent').innerHTML = parentingreadbabycat3;
}

function fillParentingReadBaby4Cat(parentingreadbabycat4testloop){
    
    var parentingreadbabycat4 = "";
    for(var a = 1; a <= parentingreadbabycat4testloop ; a++){
        parentingreadbabycat4+= '<img src="img/parenting/getting preganant/readbaby/img1.jpg" width="100%">';     
        parentingreadbabycat4+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadbabycat4+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadbabycat4+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadbabycat4+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadBaby4CatContent').innerHTML = parentingreadbabycat4;
}

function fillParentingReadBaby5Cat(parentingreadbabycat5testloop){
    
    var parentingreadbabycat5 = "";
    for(var a = 1; a <= parentingreadbabycat5testloop ; a++){
        parentingreadbabycat5+= '<img src="img/parenting/getting preganant/readbaby/img1.jpg" width="100%">';     
        parentingreadbabycat5+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadbabycat5+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadbabycat5+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadbabycat5+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadBaby5CatContent').innerHTML = parentingreadbabycat5;
}

function fillParentingReadBaby6Cat(parentingreadbabycat6testloop){
    
    var parentingreadbabycat6 = "";
    for(var a = 1; a <= parentingreadbabycat6testloop ; a++){
        parentingreadbabycat6+= '<img src="img/parenting/getting preganant/readbaby/img1.jpg" width="100%">';     
        parentingreadbabycat6+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadbabycat6+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadbabycat6+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadbabycat6+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadBaby6CatContent').innerHTML = parentingreadbabycat6;
}

function fillParentingReadBaby7Cat(parentingreadbabycat7testloop){
    
    var parentingreadbabycat7 = "";
    for(var a = 1; a <= parentingreadbabycat7testloop ; a++){
        parentingreadbabycat7+= '<img src="img/parenting/getting preganant/readbaby/img1.jpg" width="100%">';     
        parentingreadbabycat7+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadbabycat7+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadbabycat7+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadbabycat7+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadBaby7CatContent').innerHTML = parentingreadbabycat7;
}

function fillParentingReadBaby8Cat(parentingreadbaby8cattestloop){
    
    var parentingreadbabycat8 = "";
    for(var a = 1; a <= parentingreadbaby8cattestloop ; a++){
        parentingreadbabycat8+= '<img src="img/parenting/getting preganant/readbaby/img1.jpg" width="100%">';     
        parentingreadbabycat8+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadbabycat8+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadbabycat8+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadbabycat8+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadBaby8CatContent').innerHTML = parentingreadbabycat8;
}
// gettingpregnantdetailpageend

// Toddlerdetailpage
function fillParentingReadToddlerCat(parentingreadtoddlercattestloop){
    var parentingreadtoddlercat = "";
    for(var a = 1; a <= parentingreadtoddlercattestloop ; a++){
        parentingreadtoddlercat+= '<img src="img/parenting/getting preganant/readtoddler/img1.jpg" width="100%">';     
        parentingreadtoddlercat+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadtoddlercat+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadtoddlercat+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadtoddlercat+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadToddlerCatContent').innerHTML = parentingreadtoddlercat;
}

function fillParentingReadToddler2Cat(parentingreadtoddler2cattestloop){
    var parentingreadtoddler2cat = "";
    for(var a = 1; a <= parentingreadtoddler2cattestloop ; a++){
        parentingreadtoddler2cat+= '<img src="img/parenting/getting preganant/readtoddler/img1.jpg" width="100%">';     
        parentingreadtoddler2cat+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadtoddler2cat+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadtoddler2cat+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadtoddler2cat+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadToddler2CatContent').innerHTML = parentingreadtoddler2cat;
}

function fillParentingReadToddler3Cat(parentingreadtoddler3cattestloop){
    var parentingreadtoddler3cat = "";
    for(var a = 1; a <= parentingreadtoddler3cattestloop ; a++){
        parentingreadtoddler3cat+= '<img src="img/parenting/getting preganant/readtoddler/img1.jpg" width="100%">';     
        parentingreadtoddler3cat+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadtoddler3cat+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadtoddler3cat+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadtoddler3cat+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadToddler3CatContent').innerHTML = parentingreadtoddler3cat;
}

function fillParentingReadToddler4Cat(parentingreadtoddler4cattestloop){
    var parentingreadtoddler4cat = "";
    for(var a = 1; a <= parentingreadtoddler4cattestloop ; a++){
        parentingreadtoddler4cat+= '<img src="img/parenting/getting preganant/readtoddler/img1.jpg" width="100%">';     
        parentingreadtoddler4cat+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadtoddler4cat+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadtoddler4cat+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadtoddler4cat+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadToddler4CatContent').innerHTML = parentingreadtoddler4cat;
}

function fillParentingReadToddler5Cat(parentingreadtoddler5cattestloop){
    var parentingreadtoddler5cat = "";
    for(var a = 1; a <= parentingreadtoddler5cattestloop ; a++){
        parentingreadtoddler5cat+= '<img src="img/parenting/getting preganant/readtoddler/img1.jpg" width="100%">';     
        parentingreadtoddler5cat+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadtoddler5cat+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadtoddler5cat+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadtoddler5cat+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadToddler5CatContent').innerHTML = parentingreadtoddler5cat;
}
// toddlerdetailpageend

// preschoolerdetailpage
function fillParentingReadPreschoolerCat(parentingreadpreschoolercattestloop){
    var parentingreadpreschoolercat = "";
    for(var a = 1; a <= parentingreadpreschoolercattestloop ; a++){
        parentingreadpreschoolercat+= '<img src="img/parenting/getting preganant/preschooler/img1.jpg" width="100%">';     
        parentingreadpreschoolercat+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadpreschoolercat+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadpreschoolercat+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadpreschoolercat+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadPreschoolerCatContent').innerHTML = parentingreadpreschoolercat;
}
// toddlerdetailpageend

// bigkiddetailpage
function fillParentingReadBigKidCat(parentingreadbigkidcattestloop){
    var parentingreadbigkidcat = "";
    for(var a = 1; a <= parentingreadbigkidcattestloop ; a++){
        parentingreadbigkidcat+= '<img src="img/parenting/getting preganant/preschooler/img1.jpg" width="100%">';     
        parentingreadbigkidcat+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadbigkidcat+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadbigkidcat+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadbigkidcat+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadBigKidCatContent').innerHTML = parentingreadbigkidcat;
}
// toddlerdetailpageend

// magazinedetailpage
function fillParentingReadMagazineCat(parentingreadmagazinecattestloop){
    var parentingreadmagazinecat = "";
    for(var a = 1; a <= parentingreadmagazinecattestloop ; a++){
        parentingreadmagazinecat+= '<img src="img/parenting/getting preganant/readmagazine/img1.jpg" width="100%">';     
        parentingreadmagazinecat+= '<p style="margin-left: 5%; margin-top:5%;">Pregnancy Perental Care</p>';
        parentingreadmagazinecat+= '<h4 style="margin-left: 5%; margin-top: -3%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>';
        parentingreadmagazinecat+= '<p style="margin-left: 5%;">Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingreadmagazinecat+= '<p style="margin-left: 5%; margin-bottom: 4%; margin-top: -2%; font-size: 12px;">August 29,2020</p>';            
    }

    document.getElementById('fillParentingReadMagazineCatContent').innerHTML = parentingreadmagazinecat;
}
// toddlerdetailpageend