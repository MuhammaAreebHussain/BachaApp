// breastend
function fillParentingBreastFeedingTrackerILoop(parentingbreastfeedingitestloop){
    
    var parentingbreastfeedingi = "";
    for(var a = 1; a <= parentingbreastfeedingitestloop ; a++){
        parentinghomeslider += '<div class="carousel-item">';
        parentinghomeslider += '<img src="img/shopingportion/gifts/sliderimg'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        parentinghomeslider += '</div>';  
        parentingbreastfeedingi+= '<div style="border: 2px soldi; width: 100%; background-color: white;">';
        parentingbreastfeedingi+= '<p style="font-weight: bold; font-size: 22px;"> How To Breast Feed A Baby</p>';
        parentingbreastfeedingi+= '<div style="text-align: center; margin-bottom: 3%;">';
        parentingbreastfeedingi+= '<img src="img/parenting/getting preganant/breasttracker/img7.jpg" width="30%">';
        parentingbreastfeedingi+= '</div>';
        parentingbreastfeedingi+= '<p style="font-size: 14px; margin-left: 5%;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>';
        parentingbreastfeedingi+= '<a style="text-decoration: underline; color: #007bff; margin-left: 5%;">Read More</a>';
        parentingbreastfeedingi += '<div style="border: 1px solid; width: 100%; margin-top: 5%;     border-left: none; border-right: none; border-bottom: none;">';
        parentingbreastfeedingi+= '<div class="container">';
        parentingbreastfeedingi+= '<div class="row">';
        parentingbreastfeedingi+= '<div class="col-6">';
        parentingbreastfeedingi+= '<div class="row">';
        parentingbreastfeedingi+= '<div class="col-4 icon" style="font-size: 20px;">';
        parentingbreastfeedingi+= '<i class="fas fa-thumbs-up"></i>';
        parentingbreastfeedingi+= '</div>';
        parentingbreastfeedingi+= '<div class="col-8" style="font-size: 20px; margin-left: -15%;">';
        parentingbreastfeedingi+= '<p>72 Likes</p>';
        parentingbreastfeedingi+= '</div>';
        parentingbreastfeedingi+= '</div>';
        parentingbreastfeedingi+= '</div>';
        parentingbreastfeedingi+= '<div class="col-6" style="font-size: 25px;">';
        parentingbreastfeedingi+= '<div class="row">';

        parentingbreastfeedingi+= '<a style="margin-left: 50%; color:  #4267B2;"><i class="fab fa-facebook-f"></i></a>';
        parentingbreastfeedingi+= '<a style="margin-left: 30%; color: #25D366;"><i class="fab fa-whatsapp"></i></a>';
        parentingbreastfeedingi+= '</div>';
        parentingbreastfeedingi+= '</div>';
        parentingbreastfeedingi+= '</div>';
        parentingbreastfeedingi+= '</div>';
        parentingbreastfeedingi+= '</div>';
        parentingbreastfeedingi+= '</div>';               
    }

    document.getElementById('fillParentingBreastFeedingTrackerILoopContent').innerHTML = parentingbreastfeedingi;
}
// breastend