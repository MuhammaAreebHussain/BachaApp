// exploretools
function fillParentingToolsExploreTools(exploretools1testloop){
    
    var exploretools1 = "";
    for(var a = 1; a <= exploretools1testloop ; a++){    
        exploretools1+= '<div class="col-4">';
        exploretools1+= '<img src="img/parenting/home/exploretools/parentingtool/img2.jpg" style="opacity:0.4; width: 100%; border-radius: 8px;">';
        exploretools1+= '<div>';
        exploretools1+= '<p style="text-align: center; color: gray;">Vaccination Tracker</p>';
        exploretools1+= '</div>';
        exploretools1+= '</div>';      
    }

    document.getElementById('fillParentingToolsExploreToolsContent').innerHTML = exploretools1;
}
// babygrowth

// exploretools
function fillPregnancyToolsExploreTools(exploretools2testloop){
    
    var exploretools2 = "";
    for(var a = 1; a <= exploretools2testloop ; a++){    
        exploretools2+= '<div class="col-4">';
        exploretools2+= '<img src="img/parenting/home/exploretools/parentingtool/img2.jpg" style="opacity:0.4; width: 100%; border-radius: 8px;">';
        exploretools2+= '<div>';
        exploretools2+= '<p style="text-align: center; color: gray;">Baby Kick Counter</p>';
        exploretools2+= '</div>';
        exploretools2+= '</div>';      
    }

    document.getElementById('fillPregnancyToolsExploreToolsContent').innerHTML = exploretools2;
}
// babygrowth

// exploretools
function fillOtherToolsExploreTools(exploretools3testloop){
    
    var exploretools3 = "";
    for(var a = 1; a <= exploretools3testloop ; a++){    
        exploretools3+= '<div class="col-4">';
        exploretools3+= '<img src="img/parenting/home/exploretools/parentingtool/img2.jpg" style="opacity:0.4; width: 100%; border-radius: 8px;">';
        exploretools3+= '<div>';
        exploretools3+= '<p style="text-align: center; color: gray;">Period & Ovulation Calculator</p>';
        exploretools3+= '</div>';
        exploretools3+= '</div>';      
    }

    document.getElementById('fillOtherToolsExploreToolsContent').innerHTML = exploretools3;
}
// babygrowth