function checkForm() {
    debugger;
    showloader();
    checkrememberMe();
    //----- authenticate call
    var inputEmail = document.getElementById("txtInputEmail").value;
    var inputPassword = document.getElementById("txtInputPassword").value;

    if (inputEmail == "" || inputPassword == "") {
        document.getElementById('invalidID').innerHTML = 'Please enter the required information';

    }
    else {
        var formData = {
            username: inputEmail,
            password: inputPassword
        };
        $.ajax({
            url: 'http://nash.pk:994/api/NashUser/NashUserSession',
            type: 'POST',
            dataType: 'json',
            data: formData,
            success: function (data) {
                debugger;
                var value = data.data;
                CompanyId = value.companyId;
                setLocalStorage("CompanyIdFromLogin", arrayLocalStorageSignIn(CompanyId));
                goToHomePage();
                hideloader();
            // alert("success");
            },
            error: function (request, message, error) {
                debugger;
                 console.log(error);
                 hideloader();
                 document.getElementById('invalidID').innerHTML = "Email Id or password don't match";
                // document.getElementById('emailpasserror').style.display="block";
            }
        });

    }
}