//var testLoop = 10;
function fillHomePageShopByCat(testLoop){
    var homepageshopbycatcontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < testLoop ; a++){
        homepageshopbycatcontentd += '<div class="col-6">';
        homepageshopbycatcontentd += '<div style="margin-top:5%; border: 2px solid; width: 100%; border-radius: 5px;">';
        homepageshopbycatcontentd += '<div style="border: none; height: 25px; background-color: #ff7043;">';
        homepageshopbycatcontentd += '<p style="text-align: center; font-weight: 500;">Baby Girl Fashion</p>';
        homepageshopbycatcontentd += '</div>';
        homepageshopbycatcontentd += '<div>';
        homepageshopbycatcontentd += '<img src="img/home/shopingportion/babygirlmaindivimg.jpg" style="width: 100%;">';
        homepageshopbycatcontentd += '</div>';
        homepageshopbycatcontentd += '</div>';
        homepageshopbycatcontentd += '</div>';
    }

    document.getElementById('fillHomePageShopByCatContent').innerHTML = homepageshopbycatcontentd;
}     

//var testLoop = 10;
function fillHomePageSlider(slidertestLoop){
    var homepageslidercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < slidertestLoop ; a++){
            homepageslidercontentd += '<img src="img/home/sliderone/img.jpeg" class="d-block w-100" alt="..." style=" height: 250px;">';
    }

    document.getElementById('fillHomePageSliderContent').innerHTML = homepageslidercontentd;
}     

//var carterLoop = 10;
function fillHomePageCarter(homecarterLoop){
    
    var homecartercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < homecarterLoop ; a++){
            homecartercontentd += '<img src="img/home/carters/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillHomePageCarterContent').innerHTML = homecartercontentd;

}

//var summerLoop = 10;
function fillHomePageSummer(homesummerLoop){
    
    var homesummercontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < homesummerLoop ; a++){
            homesummercontentd += '<img src="img/home/summerarivial/img1.jpg" style="width: 100%; margin-top:5%;">';
    }

    document.getElementById('fillHomePageSummerContent').innerHTML = homesummercontentd;

}

//var brandsweloveLoop = 10;
function fillHomePageBrandsWeLove(homebrandsweloveLoop){
    
    var homebrandswelovecontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < homebrandsweloveLoop ; a++){
            homebrandswelovecontentd += '<img src="img/home/brandimages/img3.jpg" style="width: 100%; margin-top:5%;">';
            homebrandswelovecontentd += '<p style="font-weight: bold; font-size: 20px; text-align: center; text-decoration: underline;">Shop Now</p>';
    }

    document.getElementById('fillHomePageBrandsWeLoveContent').innerHTML = homebrandswelovecontentd;

}

//var brandsweloveLoop = 10;
function fillHomePageSportsEdition(homesportsLoop){
    
    var homesportscontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < homesportsLoop ; a++){
            homesportscontentd += '<img src="img/home/sports/playingsports/cycling.jpg" style="width: 100%; margin-top:5%;">';
           
    }

    document.getElementById('fillHomePageSportsEditionContent').innerHTML = homesportscontentd;

}

//var brandsweloveLoop = 10;
function fillHomePageImages(homeimagesLoop){
    
    var homeimagescontentd = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < homeimagesLoop ; a++){
            homeimagescontentd += '<img src="img/home/arts/img1.jpg" style="width: 100%; margin-top:5%;">';
           
    }

    document.getElementById('fillHomePageImagesContent').innerHTML = homeimagescontentd;

}

// imagesend
    
// slider
function fillHomeSliderLoop(homeslidertestloop){
    
    var homepageslider = "";
    for(var a = 1; a <= homeslidertestloop ; a++){
        homepageslider += '<div class="carousel-item">';
        homepageslider += '<img src="img/home/sliderone/img'+a+'.jpeg" class="d-block w-100" alt="..." style=" height: 250px;">';
        homepageslider += '</div>';                 
    }

    document.getElementById('fillHomeSliderLoopContent').innerHTML = homepageslider;
}
// sliderend

// slider2
function fillHomeSlider2Loop(homeslider2testloop){
    
    var homepageslider2 = "";
    for(var a = 1; a <= homeslider2testloop ; a++){
        homepageslider2 += '<div class="carousel-item">';
        homepageslider2 += '<img src="img/home/thirdslider/img'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 310px;">';
        homepageslider2 += '</div>';                 
    }

    document.getElementById('fillHomeSlider2LoopContent').innerHTML = homepageslider2;
}
// sliderend
