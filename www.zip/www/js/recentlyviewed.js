


//var testLoop = 10;
function fillRecentlyViewed(testLoop){
    var recentlyviewedcontent = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < testLoop ; a++){
            recentlyviewedcontent += '<div class="col-6">';
            recentlyviewedcontent += '<div style="margin-top:5%; border: 1px solid white; width: 100%; background-color: white;">';
            recentlyviewedcontent += '<div style="padding-top: 8%;">';
            recentlyviewedcontent += '<img src="img/shortlist-wishlist/demoimg.jpg" style="width: 100%;">';
            recentlyviewedcontent += '</div>';
            recentlyviewedcontent += '<div>';
            recentlyviewedcontent += '<p style="font-size: 12px;">Carters Helicopter UFO Slub Jersey Tee - Blue</p>';
            recentlyviewedcontent += '</div>';
            recentlyviewedcontent += '<div>';
            recentlyviewedcontent += '<div class="container">';
            recentlyviewedcontent += '<div class="row">';
            recentlyviewedcontent += '<div style="display:contents;" class="col-6">';
            recentlyviewedcontent += '<p style="font-weight: bolder;">Rs: 3000</p>';
            recentlyviewedcontent += '</div>';
            recentlyviewedcontent += '<div style="text-align: end; color:red;" class="col-6">';
            recentlyviewedcontent += '<i class="fas fa-heart"></i>';
            recentlyviewedcontent += '</div>';
            recentlyviewedcontent += '</div>';
            recentlyviewedcontent += '</div>';
            recentlyviewedcontent += '</div>';
            recentlyviewedcontent += '<div style="margin-bottom: 15%;" class="container">';
            recentlyviewedcontent += '<div class="row">';
            recentlyviewedcontent += '<div class="col-8">';
            recentlyviewedcontent += '<div>';
            recentlyviewedcontent += '<button onclick="openModal()" style="width: 140%; background-color: #ff7043; color: white; font-size:12px;">Add Cart</button>';
            recentlyviewedcontent += '</div>';
            recentlyviewedcontent += '</div>';
            recentlyviewedcontent += '<div class="col-4">';
            recentlyviewedcontent += '<div style="text-align: end;">';
            recentlyviewedcontent += '<i class="fas fa-trash"></i>';
            recentlyviewedcontent += '</div>';
            recentlyviewedcontent += '</div>';
            recentlyviewedcontent += '</div>';
            recentlyviewedcontent += '</div>';
            recentlyviewedcontent += '</div>';
            recentlyviewedcontent += '</div>';
}
document.getElementById('fillContentRecentlyViewed').innerHTML = recentlyviewedcontent;
}