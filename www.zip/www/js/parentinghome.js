// slider
function fillParentingHomeSliderLoop(parentinghomeslidertestloop){
    
    var parentinghomeslider = "";
    for(var a = 1; a <= parentinghomeslidertestloop ; a++){
        parentinghomeslider += '<div class="carousel-item">';
        parentinghomeslider += '<img src="img/shopingportion/gifts/sliderimg'+a+'.jpg" class="d-block w-100" alt="..." style=" height: 250px;">';
        parentinghomeslider += '</div>';                 
    }

    document.getElementById('fillParentingHomeSliderLoopContent').innerHTML = parentinghomeslider;
}
// sliderend


