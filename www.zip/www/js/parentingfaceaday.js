// faceaday
function fillParentingFaceADay(faceadaytestloop){
    
    var faceaday = "";
    for(var a = 1; a <= faceadaytestloop ; a++){
        faceaday+= '<div class="col-6">';
        faceaday+= '<div style="margin-top:5%; border: 1px solid palevioletred; width: 100%; background-color: palevioletred;">';
        faceaday+= '<div style=" border: 1px solid palevioletred; width: 80%; background-color: white; height: 120px; margin-left: 9%; margin-top: 10%;">';
        faceaday+= '<i style="padding: 30%; font-size: 30px; padding-left: 40%;" class="fas fa-camera"></i>';
        faceaday+= '<p style="margin-top: -25%; text-align: center;">Add Photo</p>';
        faceaday+= '</div>';
        faceaday+= '<p style="color: white; font-weight: 500; margin-top: 5%; font-size: 12px;">1 November,2020</p>';
        faceaday+= '</div>';
        faceaday+= '</div>';             
    }

    document.getElementById('fillParentingFaceADayContent').innerHTML = faceaday;
}
// babygrowth