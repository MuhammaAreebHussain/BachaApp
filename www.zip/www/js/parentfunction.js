function gotoParenting(){
    emptydiv();
    Parentingemptydiv();
    parenrclickanywhere();
    document.getElementById('parentingheader').style.display="block";
    document.getElementById('parentingfooter').style.display="block";
    document.getElementById('mainparentinghomepagediv').style.display="block";
    fillParentingHomeSliderLoop(4);
    fillParentingReadSliderLoop(4);
}



// Read Category
// Gertingpreganantdetailfunctions
function gotoGettingPregnant(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maingettingpregnantpagediv').style.display="block";
  fillParentingReadGettingPreCat(10);
}
function gotoRead(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maingettingpregnantpagediv').style.display="none";
  document.getElementById('mainparentinghomepagediv').style.display="block";
}

function gotoGettingPregnantPart1(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maingettingpre1pagediv').style.display="block";
  fillParentingReadGettingPreCat1(10);
}

function gotoGettingPregnantPart2(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maingettingpre2pagediv').style.display="block";
  fillParentingReadGettingPreCat2(10);
}

function gotoGettingPregnantPart3(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maingettingpre3pagediv').style.display="block";
  fillParentingReadGettingPreCat3(10);
}

function gotoGettingPregnantPart4(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maingettingpre4pagediv').style.display="block";
  fillParentingReadGettingPreCat4(10);
}
// Gertingpreganantdetailfunctionsend

// Gertingpreganantdetailfunctions
function gotoPregnancy(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainpregnancypagediv').style.display="block";
  fillParentingReadPregnancyCat(10);
}
function gotoRead(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maingettingpregnantpagediv').style.display="none";
  document.getElementById('mainparentinghomepagediv').style.display="block";
}

function gotoPregnancy1(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainpregnancy1pagediv').style.display="block";
  fillParentingReadPregnancyCat1(10);
}

function gotoPregnancy2(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainpregnancy2pagediv').style.display="block";
  fillParentingReadPregnancyCat2(10);
}

function gotoPregnancy3(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainpregnancy3pagediv').style.display="block";
  fillParentingReadPregnancyCat3(10);
}

function gotoPregnancy4(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainpregnancy4pagediv').style.display="block";
  fillParentingReadPregnancyCat4(10);
}

function gotoPregnancy5(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainpregnancy5pagediv').style.display="block";
  fillParentingReadPregnancyCat5(10);
}

function gotoPregnancy6(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainpregnancy6pagediv').style.display="block";
  fillParentingReadPregnancyCat6(10);
}

function gotoPregnancy7(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainpregnancy7pagediv').style.display="block";
  fillParentingReadPregnancyCat7(10);
}
// Gertingpreganantdetailfunctionsend

// Babydetailfunctions
function gotoBaby(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainbabypagediv').style.display="block";
  fillParentingReadBabyCat(10);
}

function gotoBaby1(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainbaby1pagediv').style.display="block";
  fillParentingReadBaby1Cat(10);
}

function gotoBaby2(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainbaby2pagediv').style.display="block";
  fillParentingReadBaby2Cat(10);
}

function gotoBaby3(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainbaby3pagediv').style.display="block";
  fillParentingReadBaby3Cat(10);
}

function gotoBaby4(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainbaby4pagediv').style.display="block";
  fillParentingReadBaby4Cat(10);
}

function gotoBaby5(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainbaby5pagediv').style.display="block";
  fillParentingReadBaby5Cat(10);
}

function gotoBaby6(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainbaby6pagediv').style.display="block";
  fillParentingReadBaby6Cat(10);
}

function gotoBaby7(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainbaby7pagediv').style.display="block";
  fillParentingReadBaby7Cat(10);
}

function gotoBaby8(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainbaby8pagediv').style.display="block";
  fillParentingReadBaby8Cat(10);
}
function gotoRead(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maingettingpregnantpagediv').style.display="none";
  document.getElementById('mainparentinghomepagediv').style.display="block";
}
// Gertingpreganantdetailfunctionsend

// toddlerdetailfunctions
function gotoToddler(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maintoddlerpagediv').style.display="block";
  fillParentingReadToddlerCat(10);
}


function gotoToddler2(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maintoddler2pagediv').style.display="block";
  fillParentingReadToddler2Cat(10);
}

function gotoToddler3(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maintoddler3pagediv').style.display="block";
  fillParentingReadToddler3Cat(10);
}

function gotoToddler4(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maintoddler4pagediv').style.display="block";
  fillParentingReadToddler4Cat(10);
}

function gotoToddler5(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maintoddler5pagediv').style.display="block";
  fillParentingReadToddler5Cat(10);
}
function gotoRead(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maingettingpregnantpagediv').style.display="none";
  document.getElementById('mainparentinghomepagediv').style.display="block";
}
// Gertingpreganantdetailfunctionsend

// toddlerdetailfunctions
function gotoPreschooler(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainpreschoolerpagediv').style.display="block";
  fillParentingReadPreschoolerCat(10);
}
function gotoRead(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maingettingpregnantpagediv').style.display="none";
  document.getElementById('mainparentinghomepagediv').style.display="block";
}
// Gertingpreganantdetailfunctionsend

// bigkiddetailfunctions
function gotoBigKid(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainbigkidpagediv').style.display="block";
  fillParentingReadBigKidCat(10);
}
function gotoRead(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maingettingpregnantpagediv').style.display="none";
  document.getElementById('mainparentinghomepagediv').style.display="block";
}
// Gertingpreganantdetailfunctionsend

// magazinedetailfunctions
function gotoMagazine(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainmagazinepagediv').style.display="block";
  fillParentingReadMagazineCat(10);
}
function gotoRead(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('maingettingpregnantpagediv').style.display="none";
  document.getElementById('mainparentinghomepagediv').style.display="block";
}
// Gertingpreganantdetailfunctionsend

// Parenting Tool Categorie
// dietplan function
function gotoDietPlan(){
    emptydiv();
    Parentingemptydiv();
    parenrclickanywhere();
    document.getElementById('parentingheader').style.display="block";
    document.getElementById('parentingfooter').style.display="block";
    document.getElementById('maindietplanpagediv').style.display="block";
  }
  function gotoRead(){
    emptydiv();
    Parentingemptydiv();
    parenrclickanywhere();
    document.getElementById('parentingheader').style.display="block";
    document.getElementById('parentingfooter').style.display="block";
    document.getElementById('mainparentinghomepagediv').style.display="block";
  }
  
  // dietplan function
function gotoBreastFeeding(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainbreastfeedingpagediv').style.display="block";
}
function gotoRead(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainparentinghomepagediv').style.display="block";
} 

  // babygrowth function
  function gotoBabyGrowth(){
    emptydiv();
    Parentingemptydiv();
    parenrclickanywhere();
    document.getElementById('parentingheader').style.display="block";
    document.getElementById('parentingfooter').style.display="block";
    document.getElementById('mainbabygrowthpagediv').style.display="block";
    fillParentingBabyGrowthMonth1(2);
    fillParentingBabyGrowthMonth2(2);
    fillParentingBabyGrowthMonth3(2);
    fillParentingBabyGrowthMonth4(2);
    fillParentingBabyGrowthMonth5(2);
    fillParentingBabyGrowthMonth6(2);
    fillParentingBabyGrowthMonth7(2);
    fillParentingBabyGrowthMonth8(2);
     fillParentingBabyGrowthMonth9(2);
    fillParentingBabyGrowthMonth10(2);
    fillParentingBabyGrowthMonth11(2);
    fillParentingBabyGrowthMonth12(2);
    fillParentingBabyGrowthMonth13(2);
    fillParentingBabyGrowthMonth14(2);
    fillParentingBabyGrowthMonth15(2);
    fillParentingBabyGrowthMonth16(2);
    fillParentingBabyGrowthMonth17(2);
    fillParentingBabyGrowthMonth18(2);
    fillParentingBabyGrowthMonth19(2);
    fillParentingBabyGrowthMonth20(2);
    fillParentingBabyGrowthMonth21(2);
    fillParentingBabyGrowthMonth22(2);
    fillParentingBabyGrowthMonth23(2);
    fillParentingBabyGrowthMonth24(2);
    
  }
  function gotoRead(){
    emptydiv();
    Parentingemptydiv();
    parenrclickanywhere();
    document.getElementById('parentingheader').style.display="block";
    document.getElementById('parentingfooter').style.display="block";
    document.getElementById('mainparentinghomepagediv').style.display="block";
  } 

    // face a day function
    function gotoFaceADay(){
      emptydiv();
      Parentingemptydiv();
      parenrclickanywhere();
      document.getElementById('parentingheader').style.display="block";
      document.getElementById('parentingfooter').style.display="block";
      document.getElementById('mainfaceadaypagediv').style.display="block";     
      fillParentingFaceADay(10); 
    }
    function gotoRead(){
      emptydiv();
      Parentingemptydiv();
      parenrclickanywhere();
      document.getElementById('parentingheader').style.display="block";
      document.getElementById('parentingfooter').style.display="block";
      document.getElementById('mainparentinghomepagediv').style.display="block";
    }
    
    
    // dietplan function
function gotoPregnancyDietPlan(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainpregnancydietplanpagediv').style.display="block";
}
function gotoRead(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainparentinghomepagediv').style.display="block";
}

// exploretool
function gotoExploreTools(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainexploretoolpagediv').style.display="block";
  fillParentingToolsExploreTools(6);
  fillPregnancyToolsExploreTools(6);
  fillOtherToolsExploreTools(1);
}
// function gotoRead(){
//   emptydiv();
//   Parentingemptydiv();
//   parenrclickanywhere();
//   document.getElementById('parentingheader').style.display="block";
//   document.getElementById('parentingfooter').style.display="block";
//   document.getElementById('mainparentinghomepagediv').style.display="block";
 
// }
// parentingsidear 

var b = false;

 function openParentingNav() {
    document.getElementById("parentingSidenav").style.width = "316px";
    b = true;
 }

 function closeParentingNav() {
    document.getElementById("parentingSidenav").style.width = "0";
    b = false;
 }

function parenrclickanywhere(){
     if(b === true){
    
      closeParentingNav();
     }
}

// parentingsidebarend

function gotoPeriodCalculator(){
  emptydiv();
  Parentingemptydiv();
  clickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainperiodcalculatorpagediv').style.display="block";
}

// Preganacy Tool Care Pages
function gotoBabyKickPage(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainbabykickstartpagediv').style.display="block";
  fillParentingBabyKickTrackerP3(5);
}
function gotoRead(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainparentinghomepagediv').style.display="block";
 
}


function gotoDueDateCalPage(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainduedatecalpagediv').style.display="block";
}
function gotoRead(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainparentinghomepagediv').style.display="block";
 
}

function gotoMyBumpie(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainmybumpiepagediv').style.display="block";
}

function gotoMomDiet(){
  emptydiv();
  Parentingemptydiv();
  parenrclickanywhere();
  document.getElementById('parentingheader').style.display="block";
  document.getElementById('parentingfooter').style.display="block";
  document.getElementById('mainmomdietplanpagediv').style.display="block";
}
// Preganacy Tool Care Pages Start
function openCity(cityName) {
    var i;
    var x = document.getElementsByClassName("city");
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";  
    }
    document.getElementById(cityName).style.display = "block";  
  }



  function openCity(cityName) {
    var i;
    var x = document.getElementsByClassName("city");
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";  
    }
    document.getElementById(cityName).style.display = "block";
    fillParentingMemories(5);  
  }