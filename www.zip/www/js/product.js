


//var testLoop = 10;
function fillProduct(producttestLoop){
    var productcontent = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < producttestLoop ; a++){
            productcontent += '<div onclick="gotoProductDetail()" class="col-6">';
            productcontent += '<div style="margin-top:5%; border: 1px solid white; width: 100%; background-color: white;">';
            productcontent += '<div style="padding-top: 8%;">';
            productcontent += '<img src="img/shortlist-wishlist/demoimg.jpg" style="width: 100%;">';
            productcontent += '</div>';
            productcontent += '<div>';
            productcontent += '<p style="font-size: 12px;">Carters Helicopter UFO Slub Jersey Tee - Blue</p>';
            productcontent += '</div>';
            productcontent += '<div>';
            productcontent += '<div class="container">';
            productcontent += '<div class="row">';
            productcontent += '<div style="display:contents;" class="col-6">';
            productcontent += '<p style="font-weight: bolder;">Rs: 3000</p>';
            productcontent += '</div>';
            productcontent += '<div style="text-align: end;" class="col-6">';
            productcontent += '<i class="far fa-heart"></i>';
            productcontent += '</div>';
            productcontent += '</div>';
            productcontent += '</div>';
            productcontent += '</div>';
            productcontent += '<div style="margin-bottom: 15%;" class="container">';
            productcontent += '<div class="row">';
            productcontent += '<div class="col-8">';
            productcontent += '<div>';
            productcontent += '<button onclick="openModal()" style="width: 140%; background-color: #ff7043; color: white; font-size:12px;">Add Cart</button>';
            productcontent += '</div>';
            productcontent += '</div>';
            productcontent += '<div class="col-4">';
            productcontent += '<div style="text-align: end;">';
            productcontent += '<i class="fas fa-trash"></i>';
            productcontent += '</div>';
            productcontent += '</div>';
            productcontent += '</div>';
            productcontent += '</div>';
            productcontent += '</div>';
            productcontent += '</div>';
}
document.getElementById('fillContentProduct').innerHTML = productcontent;
}





//var testLoop = 10;
function fillProductDetail(productdetailtestLoop){
    var productdetailcontent = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < productdetailtestLoop ; a++){
            productdetailcontent += '<div class="col-6">';
            productdetailcontent += '<div style="margin-top:5%; border: 1px solid white; width: 100%; background-color: white;">';
            productdetailcontent += '<div style="padding-top: 8%;">';
            productdetailcontent += '<img src="img/shortlist-wishlist/demoimg.jpg" style="width: 100%;">';
            productdetailcontent += '</div>';
            productdetailcontent += '<div>';
            productdetailcontent += '<p style="font-size: 12px;">Carters Helicopter UFO Slub Jersey Tee - Blue</p>';
            productdetailcontent += '<p style="font-weight: bolder;">Rs: 3000</p>';
            productdetailcontent += '</div>';
            productdetailcontent += '</div>';
            productdetailcontent += '</div>';
            productdetailcontent += '</div>';
            productdetailcontent += '</div>';
}
document.getElementById('fillProductDetailContent').innerHTML = productdetailcontent;
}