// exploretools
function fillParentingMemories(parentmemoriestestloop){
    
    var parentmemories = "";
    for(var a = 1; a <= parentmemoriestestloop ; a++){          
        parentmemories+= '<div style="margin-top:8%; border: 1px solid white; width: 100%; background-color: white; box-shadow: 17px 3px 10px 0px darkgrey;">';
        parentmemories+= '<p style="font-weight: 500; font-size: 20px; margin-left: 5%;">Bertile</p>';
        parentmemories+= '<p style="margin-left: 5%; margin-top: -5%; font-size: 12px; color: gray;">Mom of a 1 yr 7 m old bAby</p>';
        parentmemories+= '<p style="font-size: 20px; font-weight: 500; margin-left: 5%; margin-top: -1%">#fcwalloffame</p>';
        parentmemories+= '<div>';
        parentmemories+= '<img src="img/parenting/memoris/img1.jpg" style="width: 100%;">';
        parentmemories+= '</div>';
        parentmemories+= '<div class="icon" style="margin-left: 5%; font-size: 25px;">';
        parentmemories+= '<i class="far fa-thumbs-up"></i>';
        parentmemories+= '</div>';
        parentmemories+= '</div>';
    }

    document.getElementById('fillParentingMemoriesContent').innerHTML = parentmemories;
}
// babygrowth