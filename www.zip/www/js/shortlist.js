


//var testLoop = 10;
function fillShortList(testLoop){
    var shortlistcontent = "";
    // $.each(testLoop, function(index,value){
        for(var a = 0; a < testLoop ; a++){
            shortlistcontent += '<div class="col-6">';
            shortlistcontent += '<div style="margin-top:5%; border: 1px solid white; width: 100%; background-color: white;">';
            shortlistcontent += '<div style="padding-top: 8%;">';
            shortlistcontent += '<img src="img/shortlist-wishlist/demoimg.jpg" style="width: 100%;">';
            shortlistcontent += '</div>';
            shortlistcontent += '<div>';
            shortlistcontent += '<p style="font-size: 12px;">Carters Helicopter UFO Slub Jersey Tee - Blue</p>';
            shortlistcontent += '<p style="font-weight: bolder;">Rs: 3000</p>';
            shortlistcontent += '</div>';
            shortlistcontent += '<div style="margin-bottom: 15%;" class="container">';
            shortlistcontent += '<div class="row">';
            shortlistcontent += '<div class="col-8">';
            shortlistcontent += '<div>';
            shortlistcontent += '<button onclick="openModal()" style="font-size:12px; width: 140%; background-color: #ff7043; color: white;">Add Cart</button>';
            shortlistcontent += '</div>';
            shortlistcontent += '</div>';
            shortlistcontent += '<div class="col-4">';
            shortlistcontent += '<div style="text-align: end;">';
            shortlistcontent += '<i class="fas fa-trash"></i>';
            shortlistcontent += '</div>';
            shortlistcontent += '</div>';
            shortlistcontent += '</div>';
            shortlistcontent += '</div>';
            shortlistcontent += '</div>';
            shortlistcontent += '</div>';
}
document.getElementById('fillContentShortList').innerHTML = shortlistcontent;
}